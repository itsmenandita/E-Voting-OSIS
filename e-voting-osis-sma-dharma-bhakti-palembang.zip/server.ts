import express from 'express';
import { createServer } from 'http';
import { WebSocketServer, WebSocket } from 'ws';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { Candidate, ElectionSettings, VoterToken, VoteAuditLog } from './src/types/election.js';
import { INITIAL_CANDIDATES, INITIAL_SETTINGS, INITIAL_TOKENS } from './src/data/initialData.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface ElectionStore {
  settings: ElectionSettings;
  candidates: Candidate[];
  tokens: VoterToken[];
  auditLogs: VoteAuditLog[];
  lastUpdated: number;
}

const DATA_DIR = path.resolve(process.cwd(), 'data');
const DATA_FILE = path.join(DATA_DIR, 'election_store.json');

// Ensure data folder exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Load or initialize store
function loadStore(): ElectionStore {
  try {
    if (fs.existsSync(DATA_FILE)) {
      const content = fs.readFileSync(DATA_FILE, 'utf-8');
      const parsed = JSON.parse(content);
      return {
        settings: parsed.settings || INITIAL_SETTINGS,
        candidates: parsed.candidates || INITIAL_CANDIDATES,
        tokens: parsed.tokens || INITIAL_TOKENS,
        auditLogs: parsed.auditLogs || [],
        lastUpdated: parsed.lastUpdated || Date.now(),
      };
    }
  } catch (err) {
    console.error('Error reading election_store.json, resetting to initial data:', err);
  }

  const initialStore: ElectionStore = {
    settings: INITIAL_SETTINGS,
    candidates: INITIAL_CANDIDATES,
    tokens: INITIAL_TOKENS,
    auditLogs: [],
    lastUpdated: Date.now(),
  };

  saveStore(initialStore);
  return initialStore;
}

function saveStore(store: ElectionStore): void {
  try {
    store.lastUpdated = Date.now();
    fs.writeFileSync(DATA_FILE, JSON.stringify(store, null, 2), 'utf-8');
  } catch (err) {
    console.error('Error writing to election_store.json:', err);
  }
}

let state: ElectionStore = loadStore();

const app = express();
const server = createServer(app);
const wss = new WebSocketServer({ server });

app.use(express.json({ limit: '15mb' }));

// Broadcast helper for all connected WebSocket clients across all browsers
function broadcast(type: string, data: any) {
  const payload = JSON.stringify({ type, data, timestamp: Date.now() });
  for (const client of wss.clients) {
    if (client.readyState === WebSocket.OPEN) {
      try {
        client.send(payload);
      } catch (err) {
        console.error('Error broadcasting to client:', err);
      }
    }
  }
}

// WebSocket Connection handling
wss.on('connection', (ws) => {
  // Send current authoritative state on connection
  ws.send(JSON.stringify({ type: 'INIT', data: state, timestamp: Date.now() }));

  ws.on('message', (message) => {
    try {
      const parsed = JSON.parse(message.toString());
      if (parsed.type === 'PING') {
        ws.send(JSON.stringify({ type: 'PONG' }));
      }
    } catch {
      // ignore
    }
  });
});

// REST API Endpoints
app.get('/api/election/state', (req, res) => {
  res.json({
    success: true,
    data: state,
  });
});

// Realtime vote endpoint
app.post('/api/election/vote', (req, res) => {
  const { tokenString, candidateNumber } = req.body;

  if (!tokenString || !candidateNumber) {
    return res.status(400).json({ success: false, error: 'Data pemilihan tidak lengkap.' });
  }

  if (state.settings.status === 'paused') {
    return res.status(403).json({ success: false, error: 'Pemilihan sedang dijeda sementara oleh Panitia KPU OSIS.' });
  }
  if (state.settings.status === 'closed') {
    return res.status(403).json({ success: false, error: 'Pemungutan suara telah resmi ditutup.' });
  }

  const clean = String(tokenString).trim().toUpperCase();
  const foundIndex = state.tokens.findIndex(
    (t) => t.token.toUpperCase() === clean || t.id.toUpperCase() === clean
  );

  if (foundIndex === -1) {
    return res.status(404).json({
      success: false,
      error: 'Token tidak ditemukan dalam DPT terdaftar! Pastikan Anda memasukkan kode token yang benar dari panitia.',
    });
  }

  const voter = state.tokens[foundIndex];
  if (voter.isUsed) {
    const usedTime = voter.usedAt
      ? new Date(voter.usedAt).toLocaleTimeString('id-ID', {
          hour: '2-digit',
          minute: '2-digit',
          second: '2-digit',
        })
      : 'sebelumnya';
    return res.status(409).json({
      success: false,
      error: `Token ini SUDAH DIGUNAKAN oleh ${voter.studentName} (${voter.gradeClass}) pada pukul ${usedTime} WIB. Akses terkunci secara otomatis untuk mencegah suara ganda.`,
    });
  }

  const nowIso = new Date().toISOString();
  const receiptCode = `DBP-${Math.random().toString(36).substring(2, 6).toUpperCase()}-${Date.now().toString().slice(-4)}`;

  const updatedVoter: VoterToken = {
    ...voter,
    isUsed: true,
    usedAt: nowIso,
    votedCandidateId: String(candidateNumber),
    receiptId: receiptCode,
  };

  state.tokens[foundIndex] = updatedVoter;

  const newLog: VoteAuditLog = {
    id: `audit-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
    timestamp: nowIso,
    gradeClass: voter.gradeClass,
    candidateNumber: String(candidateNumber),
    receiptCode,
  };
  state.auditLogs.unshift(newLog);

  saveStore(state);
  broadcast('SYNC', state);

  res.json({
    success: true,
    receiptCode,
    voter: updatedVoter,
  });
});

// Update Settings
app.put('/api/election/settings', (req, res) => {
  const newSettings = req.body;
  if (!newSettings || typeof newSettings !== 'object') {
    return res.status(400).json({ success: false, error: 'Invalid settings payload' });
  }
  state.settings = { ...state.settings, ...newSettings };
  saveStore(state);
  broadcast('SYNC', state);
  res.json({ success: true, data: state.settings });
});

// Update Candidates
app.put('/api/election/candidates', (req, res) => {
  const { candidates } = req.body;
  if (!Array.isArray(candidates)) {
    return res.status(400).json({ success: false, error: 'Candidates must be an array' });
  }
  state.candidates = candidates;
  saveStore(state);
  broadcast('SYNC', state);
  res.json({ success: true, data: state.candidates });
});

// Save Tokens
app.put('/api/election/tokens', (req, res) => {
  const { tokens } = req.body;
  if (!Array.isArray(tokens)) {
    return res.status(400).json({ success: false, error: 'Tokens must be an array' });
  }
  state.tokens = tokens;
  saveStore(state);
  broadcast('SYNC', state);
  res.json({ success: true, data: state.tokens });
});

// Import Voters from Excel / list
app.post('/api/election/tokens/import', (req, res) => {
  const { items } = req.body;
  if (!Array.isArray(items)) {
    return res.status(400).json({ success: false, error: 'Items must be an array' });
  }

  const existingTokens = new Set(state.tokens.map((t) => t.token.toUpperCase()));
  const newItems: VoterToken[] = [];
  let duplicateCount = 0;

  items.forEach((item: any, index: number) => {
    if (!item.studentName || !item.studentName.trim()) return;

    let code = item.token ? String(item.token).trim().toUpperCase() : '';
    if (!code) {
      do {
        code = `DBP-${Math.floor(1000 + Math.random() * 9000)}`;
      } while (existingTokens.has(code));
    }

    if (existingTokens.has(code)) {
      duplicateCount++;
      do {
        code = `DBP-${Math.floor(1000 + Math.random() * 9000)}`;
      } while (existingTokens.has(code));
    }

    existingTokens.add(code);
    newItems.push({
      id: `tok-imp-${Date.now()}-${index}-${Math.random().toString(36).substr(2, 4)}`,
      token: code,
      studentName: item.studentName.trim(),
      gradeClass: item.gradeClass?.trim() || 'X-1',
      nisn: item.nisn?.trim() || `008${Math.floor(1000000 + Math.random() * 9000000)}`,
      isUsed: false,
    });
  });

  state.tokens = [...state.tokens, ...newItems];
  saveStore(state);
  broadcast('SYNC', state);

  res.json({
    success: true,
    addedCount: newItems.length,
    duplicateCount,
    totalDpt: state.tokens.length,
  });
});

// Delete Token
app.delete('/api/election/tokens/:id', (req, res) => {
  const { id } = req.params;
  state.tokens = state.tokens.filter((t) => t.id !== id);
  saveStore(state);
  broadcast('SYNC', state);
  res.json({ success: true });
});

// Reset Votes Only
app.post('/api/election/reset-votes', (req, res) => {
  state.tokens = state.tokens.map((t) => ({
    ...t,
    isUsed: false,
    usedAt: undefined,
    votedCandidateId: undefined,
    receiptId: undefined,
  }));
  state.auditLogs = [];
  saveStore(state);
  broadcast('SYNC', state);
  res.json({ success: true });
});

// Factory Reset
app.post('/api/election/reset-factory', (req, res) => {
  state = {
    settings: INITIAL_SETTINGS,
    candidates: INITIAL_CANDIDATES,
    tokens: INITIAL_TOKENS,
    auditLogs: [],
    lastUpdated: Date.now(),
  };
  saveStore(state);
  broadcast('SYNC', state);
  res.json({ success: true });
});

// Setup Vite middleware in dev or static files in production
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  const PORT = process.env.PORT || 3000;
  server.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`E-Voting Realtime Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});

/**
 * Sound effects utility for E-Voting system using Web Audio API
 * Runs reliably in modern browsers without external audio file dependencies.
 */

export const soundService = {
  playVoteSuccess() {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const now = ctx.currentTime;

      // Master gain
      const masterGain = ctx.createGain();
      masterGain.gain.setValueAtTime(0.2, now);
      masterGain.connect(ctx.destination);

      // Play 3 melodic ascending chime notes (C5 -> E5 -> G5 -> C6)
      const notes = [
        { freq: 523.25, time: 0.0, dur: 0.25 }, // C5
        { freq: 659.25, time: 0.12, dur: 0.25 }, // E5
        { freq: 783.99, time: 0.24, dur: 0.35 }, // G5
        { freq: 1046.5, time: 0.36, dur: 0.6 }, // C6
      ];

      notes.forEach(({ freq, time, dur }) => {
        const osc = ctx.createOscillator();
        const noteGain = ctx.createGain();

        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, now + time);

        noteGain.gain.setValueAtTime(0.001, now + time);
        noteGain.gain.exponentialRampToValueAtTime(0.3, now + time + 0.04);
        noteGain.gain.exponentialRampToValueAtTime(0.0001, now + time + dur);

        osc.connect(noteGain);
        noteGain.connect(masterGain);

        osc.start(now + time);
        osc.stop(now + time + dur);
      });

      // Optional Indonesian spoken feedback if supported
      if ('speechSynthesis' in window) {
        try {
          const utterance = new SpeechSynthesisUtterance('Suara sah tercatat');
          utterance.lang = 'id-ID';
          utterance.rate = 1.05;
          utterance.pitch = 1.0;
          setTimeout(() => {
            window.speechSynthesis.speak(utterance);
          }, 350);
        } catch {
          // ignore speech error
        }
      }
    } catch {
      // Audio might be blocked by browser policy until interaction
    }
  },

  playCoblosClick() {
    try {
      const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
      if (!AudioCtx) return;
      const ctx = new AudioCtx();
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      osc.frequency.setValueAtTime(800, now);
      osc.frequency.exponentialRampToValueAtTime(400, now + 0.08);

      gain.gain.setValueAtTime(0.15, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.08);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.08);
    } catch {
      // ignore
    }
  },
};

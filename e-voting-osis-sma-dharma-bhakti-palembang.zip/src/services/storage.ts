import {
  Candidate,
  ElectionSettings,
  ElectionStats,
  VoteAuditLog,
  VoterToken,
} from '../types/election';
import {
  INITIAL_CANDIDATES,
  INITIAL_SETTINGS,
  INITIAL_TOKENS,
} from '../data/initialData';

const STORAGE_KEYS = {
  TOKENS: 'dbp_osis_voter_tokens_v1',
  CANDIDATES: 'dbp_osis_candidates_v1',
  SETTINGS: 'dbp_osis_settings_v1',
  AUDIT_LOGS: 'dbp_osis_audit_logs_v1',
  LAST_SYNC: 'dbp_osis_last_sync_v1',
};

const SYNC_EVENT_NAME = 'dbp_osis_storage_sync';

// In-memory cache for ultra-fast, synchronous React renders
let cachedSettings: ElectionSettings = INITIAL_SETTINGS;
let cachedCandidates: Candidate[] = INITIAL_CANDIDATES;
let cachedTokens: VoterToken[] = INITIAL_TOKENS;
let cachedAuditLogs: VoteAuditLog[] = [];
let isInitialized = false;

// Initialize cache from localStorage
function initLocalCache() {
  if (isInitialized) return;
  try {
    const s = localStorage.getItem(STORAGE_KEYS.SETTINGS);
    if (s) cachedSettings = { ...INITIAL_SETTINGS, ...JSON.parse(s) };

    const c = localStorage.getItem(STORAGE_KEYS.CANDIDATES);
    if (c) {
      const parsed = JSON.parse(c);
      if (Array.isArray(parsed) && parsed.length > 0) cachedCandidates = parsed;
    }

    const t = localStorage.getItem(STORAGE_KEYS.TOKENS);
    if (t) {
      const parsed = JSON.parse(t);
      if (Array.isArray(parsed)) cachedTokens = parsed;
    }

    const a = localStorage.getItem(STORAGE_KEYS.AUDIT_LOGS);
    if (a) {
      const parsed = JSON.parse(a);
      if (Array.isArray(parsed)) cachedAuditLogs = parsed;
    }
  } catch (err) {
    console.warn('Error reading from localStorage cache:', err);
  }
  isInitialized = true;
}

initLocalCache();

// Apply remote authoritative state received from server
function applyServerState(serverData: {
  settings?: ElectionSettings;
  candidates?: Candidate[];
  tokens?: VoterToken[];
  auditLogs?: VoteAuditLog[];
}) {
  let hasChanged = false;

  if (serverData.settings) {
    cachedSettings = { ...INITIAL_SETTINGS, ...serverData.settings };
    try {
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(cachedSettings));
    } catch {}
    hasChanged = true;
  }

  if (Array.isArray(serverData.candidates) && serverData.candidates.length > 0) {
    cachedCandidates = serverData.candidates;
    try {
      localStorage.setItem(STORAGE_KEYS.CANDIDATES, JSON.stringify(cachedCandidates));
    } catch {}
    hasChanged = true;
  }

  if (Array.isArray(serverData.tokens)) {
    cachedTokens = serverData.tokens;
    try {
      localStorage.setItem(STORAGE_KEYS.TOKENS, JSON.stringify(cachedTokens));
    } catch {}
    hasChanged = true;
  }

  if (Array.isArray(serverData.auditLogs)) {
    cachedAuditLogs = serverData.auditLogs;
    try {
      localStorage.setItem(STORAGE_KEYS.AUDIT_LOGS, JSON.stringify(cachedAuditLogs));
    } catch {}
    hasChanged = true;
  }

  if (hasChanged) {
    storageService.broadcastChange();
  }
}

// REALTIME WEBSOCKET CLIENT
let socket: WebSocket | null = null;
let reconnectTimeout: any = null;
let isSocketConnected = false;

function setupRealtimeSocket() {
  if (typeof window === 'undefined') return;

  try {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}`;

    socket = new WebSocket(wsUrl);

    socket.onopen = () => {
      isSocketConnected = true;
    };

    socket.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data);
        if (message.type === 'INIT' || message.type === 'SYNC') {
          if (message.data) {
            applyServerState(message.data);
          }
        }
      } catch (err) {
        console.warn('Error parsing incoming WS message:', err);
      }
    };

    socket.onclose = () => {
      isSocketConnected = false;
      retrySocket();
    };

    socket.onerror = () => {
      isSocketConnected = false;
      socket?.close();
    };
  } catch (err) {
    console.warn('WebSocket connection error, will retry:', err);
    retrySocket();
  }
}

function retrySocket() {
  if (reconnectTimeout) return;
  reconnectTimeout = setTimeout(() => {
    reconnectTimeout = null;
    setupRealtimeSocket();
  }, 2500);
}

// Initial full sync with server via REST
async function fetchFullStateFromServer() {
  try {
    const res = await fetch('/api/election/state');
    if (res.ok) {
      const json = await res.json();
      if (json.success && json.data) {
        applyServerState(json.data);
      }
    }
  } catch (err) {
    console.warn('Failed initial REST sync with server:', err);
  }
}

// Start WebSocket and REST initial sync
if (typeof window !== 'undefined') {
  setupRealtimeSocket();
  fetchFullStateFromServer();

  // Heartbeat polling fallback (every 3 seconds) to guarantee 100% synchronization
  setInterval(() => {
    fetchFullStateFromServer();
  }, 3000);
}

export const storageService = {
  getSettings(): ElectionSettings {
    initLocalCache();
    return cachedSettings;
  },

  saveSettings(settings: ElectionSettings): void {
    cachedSettings = settings;
    try {
      localStorage.setItem(STORAGE_KEYS.SETTINGS, JSON.stringify(settings));
    } catch {}
    this.broadcastChange();

    // Push to server
    fetch('/api/election/settings', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(settings),
    }).catch((err) => console.warn('Failed to sync settings with server:', err));
  },

  getCandidates(): Candidate[] {
    initLocalCache();
    return cachedCandidates;
  },

  saveCandidates(candidates: Candidate[]): void {
    cachedCandidates = candidates;
    try {
      localStorage.setItem(STORAGE_KEYS.CANDIDATES, JSON.stringify(candidates));
    } catch {}
    this.broadcastChange();

    // Push to server
    fetch('/api/election/candidates', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ candidates }),
    }).catch((err) => console.warn('Failed to sync candidates with server:', err));
  },

  addCandidate(newCandidate: Candidate): void {
    const candidates = [...this.getCandidates(), newCandidate];
    this.saveCandidates(candidates);
  },

  deleteCandidate(candidateId: string): void {
    const candidates = this.getCandidates().filter((c) => c.id !== candidateId);
    this.saveCandidates(candidates);
  },

  updateCandidateDetails(updatedCandidate: Candidate): void {
    const candidates = this.getCandidates().map((c) =>
      c.id === updatedCandidate.id ? updatedCandidate : c
    );
    this.saveCandidates(candidates);
  },

  updateCandidatePhoto(candidateId: string, photoUrl: string): void {
    const candidates = this.getCandidates().map((c) =>
      c.id === candidateId ? { ...c, photoUrl } : c
    );
    this.saveCandidates(candidates);
  },

  getTokens(): VoterToken[] {
    initLocalCache();
    return cachedTokens;
  },

  saveTokens(tokens: VoterToken[]): void {
    cachedTokens = tokens;
    try {
      localStorage.setItem(STORAGE_KEYS.TOKENS, JSON.stringify(tokens));
    } catch {}
    this.broadcastChange();

    // Push to server
    fetch('/api/election/tokens', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ tokens }),
    }).catch((err) => console.warn('Failed to sync tokens with server:', err));
  },

  getAuditLogs(): VoteAuditLog[] {
    initLocalCache();
    return cachedAuditLogs;
  },

  saveAuditLogs(logs: VoteAuditLog[]): void {
    cachedAuditLogs = logs;
    try {
      localStorage.setItem(STORAGE_KEYS.AUDIT_LOGS, JSON.stringify(logs));
    } catch {}
  },

  verifyToken(rawToken: string): {
    valid: boolean;
    voter?: VoterToken;
    errorType?: 'not_found' | 'already_used' | 'election_inactive';
    errorMessage?: string;
  } {
    const settings = this.getSettings();
    if (settings.status === 'paused') {
      return {
        valid: false,
        errorType: 'election_inactive',
        errorMessage: 'Pemilihan sedang dijeda sementara oleh Panitia KPU OSIS.',
      };
    }
    if (settings.status === 'closed') {
      return {
        valid: false,
        errorType: 'election_inactive',
        errorMessage: 'Pemungutan suara telah resmi ditutup.',
      };
    }

    const clean = rawToken.trim().toUpperCase();
    if (!clean) {
      return {
        valid: false,
        errorType: 'not_found',
        errorMessage: 'Silakan masukkan token pemilihan terlebih dahulu.',
      };
    }

    const tokens = this.getTokens();
    const found = tokens.find(
      (t) => t.token.toUpperCase() === clean || t.id.toUpperCase() === clean
    );

    if (!found) {
      return {
        valid: false,
        errorType: 'not_found',
        errorMessage:
          'Token tidak ditemukan dalam DPT terdaftar! Pastikan Anda memasukkan kode token yang benar dari panitia.',
      };
    }

    if (found.isUsed) {
      const usedTime = found.usedAt
        ? new Date(found.usedAt).toLocaleTimeString('id-ID', {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
          })
        : 'sebelumnya';

      return {
        valid: false,
        voter: found,
        errorType: 'already_used',
        errorMessage: `Token ini SUDAH DIGUNAKAN oleh ${found.studentName} (${found.gradeClass}) pada pukul ${usedTime} WIB. Akses terkunci secara otomatis untuk mencegah suara ganda.`,
      };
    }

    return {
      valid: true,
      voter: found,
    };
  },

  castVote(
    tokenString: string,
    candidateNumber: string
  ): { success: boolean; receiptCode: string; voter: VoterToken; error?: string } {
    const verification = this.verifyToken(tokenString);
    if (!verification.valid || !verification.voter) {
      return {
        success: false,
        receiptCode: '',
        voter: verification.voter || ({} as VoterToken),
        error: verification.errorMessage || 'Token tidak valid.',
      };
    }

    const voter = verification.voter;
    const nowIso = new Date().toISOString();
    const receiptCode = `DBP-${Math.random().toString(36).substring(2, 6).toUpperCase()}-${Date.now().toString().slice(-4)}`;

    const updatedVoter: VoterToken = {
      ...voter,
      isUsed: true,
      usedAt: nowIso,
      votedCandidateId: candidateNumber,
      receiptId: receiptCode,
    };

    // Optimistic local update
    const tokens = this.getTokens();
    const updatedTokens = tokens.map((t) => (t.id === voter.id ? updatedVoter : t));
    cachedTokens = updatedTokens;
    try {
      localStorage.setItem(STORAGE_KEYS.TOKENS, JSON.stringify(updatedTokens));
    } catch {}

    const auditLogs = this.getAuditLogs();
    const newLog: VoteAuditLog = {
      id: `audit-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`,
      timestamp: nowIso,
      gradeClass: voter.gradeClass,
      candidateNumber,
      receiptCode,
    };
    cachedAuditLogs = [newLog, ...auditLogs];
    try {
      localStorage.setItem(STORAGE_KEYS.AUDIT_LOGS, JSON.stringify(cachedAuditLogs));
    } catch {}

    this.broadcastChange();

    // Asynchronously push to authoritative server which will broadcast to ALL connected browsers/devices
    fetch('/api/election/vote', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ tokenString, candidateNumber }),
    })
      .then((res) => res.json())
      .then((json) => {
        if (json.success && json.voter) {
          // If server assigned receipt or timestamp, ensure local matches
          this.broadcastChange();
        }
      })
      .catch((err) => {
        console.warn('Network error casting vote to server:', err);
      });

    return {
      success: true,
      receiptCode,
      voter: updatedVoter,
    };
  },

  getStats(): ElectionStats {
    const tokens = this.getTokens();
    const totalDpt = tokens.length;
    const usedTokens = tokens.filter((t) => t.isUsed);
    const totalVoted = usedTokens.length;
    const totalPending = totalDpt - totalVoted;
    const participationPercentage =
      totalDpt > 0 ? Math.round((totalVoted / totalDpt) * 1000) / 10 : 0;

    const candidates = this.getCandidates();
    const candidateCounts: Record<string, number> = {};
    candidates.forEach((c) => {
      candidateCounts[c.number] = 0;
    });

    usedTokens.forEach((t) => {
      if (t.votedCandidateId && candidateCounts[t.votedCandidateId] !== undefined) {
        candidateCounts[t.votedCandidateId]++;
      }
    });

    return {
      totalDpt,
      totalVoted,
      totalPending,
      participationPercentage,
      candidateCounts,
    };
  },

  addSingleVoter(voter: Omit<VoterToken, 'id' | 'isUsed'>): VoterToken {
    const tokens = this.getTokens();
    const newVoter: VoterToken = {
      ...voter,
      id: `tok-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      isUsed: false,
    };
    tokens.push(newVoter);
    this.saveTokens(tokens);
    return newVoter;
  },

  importVotersFromList(
    items: Array<{
      studentName: string;
      gradeClass: string;
      nisn?: string;
      token?: string;
    }>
  ): { addedCount: number; duplicateCount: number } {
    const existing = this.getTokens();
    const existingTokens = new Set(existing.map((t) => t.token.toUpperCase()));
    const newItems: VoterToken[] = [];
    let duplicateCount = 0;

    items.forEach((item, index) => {
      if (!item.studentName || !item.studentName.trim()) return;

      let code = item.token ? item.token.trim().toUpperCase() : '';
      if (!code) {
        do {
          code = `DBP-${Math.floor(1000 + Math.random() * 9000)}`;
        } while (existingTokens.has(code));
      }

      if (existingTokens.has(code)) {
        duplicateCount++;
        do {
          code = `DBP-${Math.floor(1000 + Math.random() * 9000)}`;
        } while (existingTokens.has(code));
      }

      existingTokens.add(code);
      newItems.push({
        id: `tok-imp-${Date.now()}-${index}-${Math.random().toString(36).substr(2, 4)}`,
        token: code,
        studentName: item.studentName.trim(),
        gradeClass: item.gradeClass?.trim() || 'X-1',
        nisn: item.nisn?.trim() || `008${Math.floor(1000000 + Math.random() * 9000000)}`,
        isUsed: false,
      });
    });

    const merged = [...existing, ...newItems];
    cachedTokens = merged;
    try {
      localStorage.setItem(STORAGE_KEYS.TOKENS, JSON.stringify(merged));
    } catch {}
    this.broadcastChange();

    // Push to server for realtime broadcast across devices
    fetch('/api/election/tokens/import', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ items }),
    }).catch((err) => console.warn('Failed to sync import with server:', err));

    return { addedCount: newItems.length, duplicateCount };
  },

  exportTokensToCsv(customTokens?: VoterToken[], customFilename?: string): void {
    const tokens = customTokens || this.getTokens();
    const headers = ['Nomor Token', 'Nama Siswa', 'Kelas', 'NISN', 'Status Memilih', 'Waktu Memilih', 'ID Transaksi'];
    const rows = tokens.map((t) => [
      `"${t.token}"`,
      `"${t.studentName}"`,
      `"${t.gradeClass}"`,
      `"${t.nisn}"`,
      `"${t.isUsed ? 'SUDAH MEMILIH' : 'BELUM MEMILIH'}"`,
      `"${t.usedAt ? new Date(t.usedAt).toLocaleString('id-ID') : '-'}"`,
      `"${t.receiptId || '-'}"`,
    ]);

    const csvContent = '\uFEFF' + [headers.join(','), ...rows.map((e) => e.join(','))].join('\r\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute(
      'download',
      customFilename || `DPT_TOKEN_PEMILU_OSIS_${new Date().toISOString().slice(0, 10)}.csv`
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  },

  deleteToken(id: string): void {
    const tokens = this.getTokens().filter((t) => t.id !== id);
    cachedTokens = tokens;
    try {
      localStorage.setItem(STORAGE_KEYS.TOKENS, JSON.stringify(tokens));
    } catch {}
    this.broadcastChange();

    fetch(`/api/election/tokens/${id}`, {
      method: 'DELETE',
    }).catch((err) => console.warn('Failed to delete token on server:', err));
  },

  clearAllTokens(): void {
    this.saveTokens([]);
    this.saveAuditLogs([]);
    this.broadcastChange();
  },

  resetVotesOnly(): void {
    const tokens = this.getTokens().map((t) => ({
      ...t,
      isUsed: false,
      usedAt: undefined,
      votedCandidateId: undefined,
      receiptId: undefined,
    }));
    cachedTokens = tokens;
    cachedAuditLogs = [];
    try {
      localStorage.setItem(STORAGE_KEYS.TOKENS, JSON.stringify(tokens));
      localStorage.setItem(STORAGE_KEYS.AUDIT_LOGS, JSON.stringify([]));
    } catch {}
    this.broadcastChange();

    fetch('/api/election/reset-votes', { method: 'POST' }).catch((err) =>
      console.warn('Failed to reset votes on server:', err)
    );
  },

  resetAllToFactory(): void {
    cachedSettings = INITIAL_SETTINGS;
    cachedCandidates = INITIAL_CANDIDATES;
    cachedTokens = INITIAL_TOKENS;
    cachedAuditLogs = [];
    try {
      localStorage.removeItem(STORAGE_KEYS.TOKENS);
      localStorage.removeItem(STORAGE_KEYS.CANDIDATES);
      localStorage.removeItem(STORAGE_KEYS.SETTINGS);
      localStorage.removeItem(STORAGE_KEYS.AUDIT_LOGS);
    } catch {}
    this.broadcastChange();

    fetch('/api/election/reset-factory', { method: 'POST' }).catch((err) =>
      console.warn('Failed to reset factory on server:', err)
    );
  },

  broadcastChange(): void {
    try {
      window.dispatchEvent(new CustomEvent(SYNC_EVENT_NAME));
    } catch {
      // ignore
    }
  },

  subscribe(callback: () => void): () => void {
    const handler = () => callback();
    window.addEventListener(SYNC_EVENT_NAME, handler);
    window.addEventListener('storage', handler);
    return () => {
      window.removeEventListener(SYNC_EVENT_NAME, handler);
      window.removeEventListener('storage', handler);
    };
  },
};

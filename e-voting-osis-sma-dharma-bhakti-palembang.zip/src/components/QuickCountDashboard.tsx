import React, { useEffect, useState } from 'react';
import { Candidate, ElectionStats, VoteAuditLog } from '../types/election';
import { storageService } from '../services/storage';
import { OSIS_LOGO } from '../data/initialData';
import { BeritaAcaraModal } from './BeritaAcaraModal';
import {
  BarChart3,
  Users,
  CheckCircle2,
  Clock,
  TrendingUp,
  Award,
  Maximize2,
  ShieldCheck,
  Vote,
  ArrowLeft,
  FileText,
} from 'lucide-react';

interface QuickCountDashboardProps {
  candidates: Candidate[];
  onBackToBooth: () => void;
  onOpenProjector: () => void;
}

export const QuickCountDashboard: React.FC<QuickCountDashboardProps> = ({
  candidates,
  onBackToBooth,
  onOpenProjector,
}) => {
  const [stats, setStats] = useState<ElectionStats>(storageService.getStats());
  const [auditLogs, setAuditLogs] = useState<VoteAuditLog[]>(storageService.getAuditLogs());
  const [lastUpdated, setLastUpdated] = useState<Date>(new Date());
  const [isPulsing, setIsPulsing] = useState(false);
  const [isBeritaAcaraOpen, setIsBeritaAcaraOpen] = useState(false);

  const settings = storageService.getSettings();

  // Auto sync when votes happen
  useEffect(() => {
    const refreshData = () => {
      setStats(storageService.getStats());
      setAuditLogs(storageService.getAuditLogs());
      setLastUpdated(new Date());
      setIsPulsing(true);
      setTimeout(() => setIsPulsing(false), 800);
    };

    refreshData();
    const unsubscribe = storageService.subscribe(refreshData);
    return () => unsubscribe();
  }, []);

  const totalVotes = stats.totalVoted;
  const sortedCandidates = [...candidates].sort((a, b) => {
    const countA = stats.candidateCounts[a.number] || 0;
    const countB = stats.candidateCounts[b.number] || 0;
    return countB - countA;
  });

  const getPercent = (count: number) => {
    if (totalVotes === 0) return 0;
    return Math.round((count / totalVotes) * 1000) / 10;
  };

  // Find max votes for scaling bar heights nicely
  const maxVotes = Math.max(...candidates.map((c) => stats.candidateCounts[c.number] || 0), 1);

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-4 sm:p-6 lg:p-8 space-y-6">
      {/* Top Navigation & Header */}
      <header className="max-w-7xl mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <button
            onClick={onBackToBooth}
            className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white transition-colors flex items-center gap-1.5 text-xs font-bold cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Kembali ke Bilik</span>
          </button>
          <img
            src={OSIS_LOGO}
            alt="Logo OSIS"
            className="w-12 h-12 object-contain drop-shadow"
          />
          <div>
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[11px] font-extrabold uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                <span className={`w-2 h-2 rounded-full bg-emerald-400 ${isPulsing ? 'animate-ping' : 'animate-pulse'}`} />
                REAL-TIME QUICK COUNT AKTIF
              </span>
              <span className="text-xs text-slate-400 hidden sm:inline">
                Update Otomatis Instan
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight mt-1">
              Dasbor Transparansi Pemilihan Ketua OSIS
            </h1>
            <p className="text-xs text-amber-300 font-semibold">
              {settings.schoolName} &bull; {settings.electionPeriod}
            </p>
          </div>
        </div>

        <div className="flex flex-wrap items-center gap-3 self-stretch md:self-auto justify-between md:justify-end">
          <button
            onClick={() => setIsBeritaAcaraOpen(true)}
            className="px-4 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs shadow-lg flex items-center gap-2 cursor-pointer transition-all active:scale-95"
          >
            <FileText className="w-4 h-4" />
            <span>Berita Acara Resmi</span>
          </button>

          <button
            onClick={onOpenProjector}
            className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-black text-xs shadow-lg flex items-center gap-2 cursor-pointer transition-all active:scale-95"
          >
            <Maximize2 className="w-4 h-4" />
            <span>Layar Proyektor (Big Screen)</span>
          </button>
        </div>
      </header>

      {/* 4 Stat Metric Cards */}
      <section className="max-w-7xl mx-auto grid grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Total DPT */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg relative overflow-hidden">
          <div className="flex items-center justify-between text-slate-400 text-xs font-bold uppercase tracking-wider mb-2">
            <span>Daftar Pemilih (DPT)</span>
            <Users className="w-5 h-5 text-blue-400" />
          </div>
          <div className="text-3xl sm:text-4xl font-black text-white font-mono">
            {stats.totalDpt}
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Total siswa terdaftar resmi
          </p>
        </div>

        {/* Total Suara Masuk */}
        <div className="bg-slate-900/90 border-2 border-emerald-500/40 rounded-2xl p-5 shadow-lg relative overflow-hidden">
          <div className="flex items-center justify-between text-emerald-400 text-xs font-bold uppercase tracking-wider mb-2">
            <span>Suara Masuk (Sah)</span>
            <CheckCircle2 className="w-5 h-5 text-emerald-400" />
          </div>
          <div className="text-3xl sm:text-4xl font-black text-emerald-300 font-mono flex items-baseline gap-2">
            <span>{stats.totalVoted}</span>
            <span className="text-xs font-normal text-slate-400">suara</span>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Tercatat tanpa suara ganda
          </p>
        </div>

        {/* Persentase Partisipasi */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg relative overflow-hidden">
          <div className="flex items-center justify-between text-amber-400 text-xs font-bold uppercase tracking-wider mb-2">
            <span>Partisipasi Pemilih</span>
            <TrendingUp className="w-5 h-5 text-amber-400" />
          </div>
          <div className="text-3xl sm:text-4xl font-black text-amber-300 font-mono">
            {stats.participationPercentage}%
          </div>
          <div className="w-full bg-slate-800 h-2 rounded-full mt-2 overflow-hidden">
            <div
              className="bg-gradient-to-r from-amber-500 to-emerald-400 h-full transition-all duration-700 rounded-full"
              style={{ width: `${Math.min(100, stats.participationPercentage)}%` }}
            />
          </div>
        </div>

        {/* Sisa Belum Memilih */}
        <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-lg relative overflow-hidden">
          <div className="flex items-center justify-between text-slate-400 text-xs font-bold uppercase tracking-wider mb-2">
            <span>Belum Memilih</span>
            <Clock className="w-5 h-5 text-slate-400" />
          </div>
          <div className="text-3xl sm:text-4xl font-black text-slate-300 font-mono">
            {stats.totalPending}
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Menunggu giliran di bilik
          </p>
        </div>
      </section>

      {/* Main Section: Visual Vertical & Horizontal Bar Charts */}
      <main className="max-w-7xl mx-auto grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Visual Bar Charts (8 Cols) */}
        <div className="lg:col-span-8 space-y-6">
          {/* VERTICAL BAR CHART (Tiang Grafik Batang Suara & Foto Muka Penuh) */}
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-6">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-slate-800 pb-4">
              <div>
                <h2 className="text-lg font-black text-white flex items-center gap-2">
                  <BarChart3 className="w-5 h-5 text-amber-400" />
                  Grafik Batang Perolehan Suara (Live Bar Chart)
                </h2>
                <p className="text-xs text-slate-400">
                  Tinggi tiang grafik bergeser secara dinamis dan instan setiap ada penambahan suara
                </p>
              </div>

              {totalVotes > 0 && (
                <div className="px-3 py-1 rounded-xl bg-slate-800 text-xs text-slate-300 border border-slate-700">
                  Pemimpin Sementara:{' '}
                  <strong className="text-amber-400 font-bold">
                    Paslon {sortedCandidates[0].number} ({getPercent(stats.candidateCounts[sortedCandidates[0].number])}%)
                  </strong>
                </div>
              )}
            </div>

            {/* Vertical Bar Chart Pillars */}
            <div className="pt-8 pb-4">
              <div
                className="grid gap-3 sm:gap-6 items-end min-h-[320px] px-2 sm:px-6 border-b-2 border-slate-700/80"
                style={{
                  gridTemplateColumns: `repeat(${candidates.length}, minmax(0, 1fr))`,
                }}
              >
                {candidates.map((candidate, idx) => {
                  const count = stats.candidateCounts[candidate.number] || 0;
                  const percent = getPercent(count);
                  const isLeader = totalVotes > 0 && sortedCandidates[0].id === candidate.id;

                  // Height calculation (at least 15% so bar is visible, max 100%)
                  const barHeightPercent =
                    totalVotes === 0 ? 15 : Math.max(18, Math.round((count / maxVotes) * 90));

                  const PALETTES = [
                    { bar: 'from-blue-600 to-sky-400 border-blue-400/60', badge: 'bg-blue-600 text-white' },
                    { bar: 'from-amber-600 to-yellow-400 border-amber-400/60', badge: 'bg-amber-500 text-slate-950 font-black' },
                    { bar: 'from-emerald-600 to-teal-400 border-emerald-400/60', badge: 'bg-emerald-600 text-white' },
                    { bar: 'from-purple-600 to-fuchsia-400 border-purple-400/60', badge: 'bg-purple-600 text-white' },
                    { bar: 'from-rose-600 to-pink-400 border-rose-400/60', badge: 'bg-rose-600 text-white' },
                    { bar: 'from-teal-600 to-cyan-400 border-teal-400/60', badge: 'bg-teal-600 text-white' },
                  ];

                  const pal = PALETTES[idx % PALETTES.length];
                  const barColor = pal.bar;
                  const badgeColor = pal.badge;


                  return (
                    <div
                      key={candidate.id}
                      className="flex flex-col items-center justify-end h-full group"
                    >
                      {/* Percent & Vote Count floating on top of bar */}
                      <div className="mb-2 text-center space-y-0.5">
                        {isLeader && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-400 text-slate-950 shadow mb-1">
                            <Award className="w-3 h-3" /> Unggul
                          </span>
                        )}
                        <div className="text-xl sm:text-2xl font-black font-mono text-white">
                          {percent}%
                        </div>
                        <div className="text-xs font-mono font-bold text-amber-400 bg-slate-950/90 px-2 py-0.5 rounded-md border border-slate-800">
                          {count} Suara
                        </div>
                      </div>

                      {/* The Vertical Bar Pillar */}
                      <div className="w-full max-w-[90px] flex items-end justify-center">
                        <div
                          className={`w-full rounded-t-2xl bg-gradient-to-t ${barColor} border-t-2 border-x-2 shadow-2xl transition-all duration-700 ease-out flex items-center justify-center p-2 relative overflow-hidden`}
                          style={{ height: `${barHeightPercent * 2.4}px` }}
                        >
                          <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity" />
                        </div>
                      </div>

                      {/* Number Badge at the base */}
                      <div
                        className={`w-10 h-10 sm:w-12 sm:h-12 rounded-xl ${badgeColor} flex items-center justify-center font-black text-lg sm:text-xl shadow-lg -mt-3 z-10 border-2 border-slate-900`}
                      >
                        {candidate.number}
                      </div>

                      {/* Candidate Name below base */}
                      <div className="mt-2 text-center">
                        <h4 className="text-xs sm:text-sm font-black text-white truncate max-w-[110px] sm:max-w-[150px]">
                          {candidate.title.replace('PASLON 01 - ', '').replace('PASLON 02 - ', '').replace('PASLON 03 - ', '')}
                        </h4>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* CANDIDATE PROFILES WITH FULL FACE PHOTOS (Muka terlihat utuh) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 pt-2">

              {candidates.map((c) => {
                const count = stats.candidateCounts[c.number] || 0;
                const percent = getPercent(count);
                const rank = sortedCandidates.findIndex((item) => item.id === c.id) + 1;

                return (
                  <div
                    key={c.id}
                    className="bg-slate-950 border border-slate-800 rounded-2xl p-4 flex flex-col justify-between space-y-3"
                  >
                    <div>
                      <div className="flex items-center justify-between mb-2">
                        <span className="w-7 h-7 rounded-lg bg-amber-400 text-slate-950 font-black font-mono flex items-center justify-center text-xs">
                          {c.number}
                        </span>
                        <span className="text-[11px] font-bold px-2 py-0.5 rounded-full bg-slate-800 text-slate-300">
                          Peringkat #{rank}
                        </span>
                      </div>

                      {/* Full Face Candidate Photo: using object-cover with object-top and aspect-[3/4] to ensure faces are 100% visible */}
                      <div className="relative aspect-[3/4] w-full rounded-xl overflow-hidden border-2 border-slate-700 bg-slate-900 mb-2.5 shadow-md">
                        <img
                          src={c.photoUrl}
                          alt={c.title}
                          className="w-full h-full object-cover object-top"
                        />
                        <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-slate-950 via-slate-950/80 to-transparent p-2 text-center">
                          <p className="text-[11px] font-bold text-white truncate">
                            {c.leaderName}
                          </p>
                          <p className="text-[10px] text-slate-300 truncate">
                            & {c.coLeaderName}
                          </p>
                        </div>
                      </div>
                    </div>

                    <div className="bg-slate-900/90 p-2.5 rounded-xl border border-slate-800 text-center">
                      <div className="text-xl font-black font-mono text-white">
                        {percent}%
                      </div>
                      <div className="text-xs font-semibold text-amber-400 font-mono">
                        {count} Suara Masuk
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column: Live Audit Feed & Transparency (4 Cols) */}
        <div className="lg:col-span-4 space-y-6">
          <div className="bg-slate-900/90 border border-slate-800 rounded-3xl p-6 shadow-xl space-y-4">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-5 h-5 text-emerald-400" />
                <h3 className="text-sm font-extrabold text-white">
                  Log Transparansi Suara Masuk
                </h3>
              </div>
              <span className="text-[10px] text-slate-400 uppercase font-mono">
                Anonim & Sah
              </span>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              Pilihan siswa dirahasiakan (Asas Luber Jurdil). Sistem mencatat tanda bukti transaksi sah dan waktu masuk untuk keperluan transparansi audit.
            </p>

            {/* Audit List */}
            <div className="space-y-2.5 max-h-[500px] overflow-y-auto pr-1">
              {auditLogs.length > 0 ? (
                auditLogs.slice(0, 15).map((log) => {
                  const date = new Date(log.timestamp);
                  const timeStr = date.toLocaleTimeString('id-ID', {
                    hour: '2-digit',
                    minute: '2-digit',
                    second: '2-digit',
                  });

                  return (
                    <div
                      key={log.id}
                      className="p-3 rounded-xl bg-slate-950/70 border border-slate-800/80 text-xs space-y-1 hover:border-slate-700 transition-colors"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-bold text-emerald-400 flex items-center gap-1.5">
                          <CheckCircle2 className="w-3.5 h-3.5" /> Suara Masuk Sah
                        </span>
                        <span className="font-mono text-[10px] text-slate-400">
                          {timeStr} WIB
                        </span>
                      </div>
                      <div className="flex items-center justify-between text-slate-300 text-[11px]">
                        <span>Asal Rombel: <strong className="text-white">{log.gradeClass}</strong></span>
                        <span className="font-mono text-slate-400">ID: {log.receiptCode.slice(-8)}</span>
                      </div>
                    </div>
                  );
                })
              ) : (
                <div className="py-12 text-center text-xs text-slate-500 space-y-2">
                  <Vote className="w-8 h-8 text-slate-600 mx-auto" />
                  <p>Belum ada suara yang masuk.</p>
                  <p className="text-[11px]">Silakan masukkan token di bilik suara untuk memulai.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </main>

      {/* Official Berita Acara Modal */}
      <BeritaAcaraModal
        isOpen={isBeritaAcaraOpen}
        onClose={() => setIsBeritaAcaraOpen(false)}
        settings={settings}
        stats={stats}
        candidates={candidates}
      />

      {/* Footer: TIM IT SMA DB */}
      <footer className="max-w-7xl mx-auto w-full text-center py-4 border-t border-slate-800">
        <p className="text-xs font-bold text-slate-400 tracking-wider uppercase">
          TIM IT SMA DB
        </p>
      </footer>
    </div>
  );
};

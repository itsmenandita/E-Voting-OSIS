import React, { useState } from 'react';
import { Candidate, VoterToken } from '../types/election';
import { CandidateModal } from './CandidateModal';
import { soundService } from '../services/sound';
import {
  Vote,
  Info,
  Shield,
  UserCheck,
  Check,
  AlertTriangle,
  Sparkles,
  ArrowLeft,
  ChevronRight,
} from 'lucide-react';

interface VotingBoothProps {
  voter: VoterToken;
  candidates: Candidate[];
  onVoteCast: (candidateNumber: string) => void;
  onCancelVote: () => void;
}

const CANDIDATE_PALETTES = [
  {
    badge: 'bg-blue-600 border-blue-400 text-white',
    border: 'hover:border-blue-500/70 focus-within:border-blue-500',
    button: 'bg-blue-600 hover:bg-blue-500 shadow-blue-600/30 text-white font-bold',
  },
  {
    badge: 'bg-amber-500 border-amber-300 text-slate-950',
    border: 'hover:border-amber-500/70 focus-within:border-amber-500',
    button: 'bg-amber-500 hover:bg-amber-400 shadow-amber-500/30 text-slate-950 font-black',
  },
  {
    badge: 'bg-emerald-600 border-emerald-400 text-white',
    border: 'hover:border-emerald-500/70 focus-within:border-emerald-500',
    button: 'bg-emerald-600 hover:bg-emerald-500 shadow-emerald-600/30 text-white font-bold',
  },
  {
    badge: 'bg-purple-600 border-purple-400 text-white',
    border: 'hover:border-purple-500/70 focus-within:border-purple-500',
    button: 'bg-purple-600 hover:bg-purple-500 shadow-purple-600/30 text-white font-bold',
  },
  {
    badge: 'bg-rose-600 border-rose-400 text-white',
    border: 'hover:border-rose-500/70 focus-within:border-rose-500',
    button: 'bg-rose-600 hover:bg-rose-500 shadow-rose-600/30 text-white font-bold',
  },
  {
    badge: 'bg-teal-600 border-teal-400 text-white',
    border: 'hover:border-teal-500/70 focus-within:border-teal-500',
    button: 'bg-teal-600 hover:bg-teal-500 shadow-teal-600/30 text-white font-bold',
  },
];

export const VotingBooth: React.FC<VotingBoothProps> = ({
  voter,
  candidates,
  onVoteCast,
  onCancelVote,
}) => {
  const [selectedCandidate, setSelectedCandidate] = useState<Candidate | null>(null);
  const [modalCandidate, setModalCandidate] = useState<Candidate | null>(null);
  const [isConfirming, setIsConfirming] = useState(false);
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSelectToVote = (candidate: Candidate) => {
    soundService.playCoblosClick();
    setSelectedCandidate(candidate);
    setIsConfirming(true);
  };

  const handleConfirmSubmit = () => {
    if (!selectedCandidate) return;
    setIsSubmitting(true);
    setTimeout(() => {
      onVoteCast(selectedCandidate.number);
    }, 400);
  };

  const gridClass =
    candidates.length === 2
      ? 'grid-cols-1 md:grid-cols-2 max-w-4xl mx-auto'
      : candidates.length === 4
      ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-4'
      : 'grid-cols-1 md:grid-cols-2 lg:grid-cols-3';

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between p-4 sm:p-6 lg:p-8">
      {/* Voter Status Banner */}
      <div className="max-w-7xl mx-auto w-full mb-6">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 shadow-xl flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3 w-full md:w-auto">
            <button
              onClick={onCancelVote}
              className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors flex items-center gap-1 text-xs font-semibold"
              title="Keluar dari bilik"
            >
              <ArrowLeft className="w-4 h-4" />
              <span className="hidden sm:inline">Kembali</span>
            </button>
            <div className="w-10 h-10 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 flex items-center justify-center shrink-0">
              <UserCheck className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="text-xs uppercase tracking-wider font-bold text-emerald-400">
                  Pemilih Terverifikasi
                </span>
                <span className="text-xs bg-slate-800 px-2 py-0.5 rounded text-slate-300 font-mono">
                  Token: {voter.token}
                </span>
              </div>
              <h2 className="text-base sm:text-lg font-bold text-white">
                {voter.studentName}{' '}
                <span className="text-slate-400 font-normal">({voter.gradeClass})</span>
              </h2>
            </div>
          </div>

          <div className="flex items-center gap-3 text-xs bg-slate-950/70 px-4 py-2.5 rounded-xl border border-slate-800 text-slate-300 w-full md:w-auto justify-between md:justify-end">
            <span className="flex items-center gap-1.5 text-amber-400 font-semibold">
              <Shield className="w-4 h-4" />
              Hak Pilih: 1 Suara Sah
            </span>
            <span className="text-slate-400">
              Akses akan terkunci otomatis setelah memilih
            </span>
          </div>
        </div>

        {/* Bilik Instruction */}
        <div className="text-center mt-6 mb-4 space-y-1">
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight uppercase">
            SURAT SUARA PEMILIHAN KETUA & WAKIL KETUA OSIS
          </h1>
          <p className="text-sm text-slate-400">
            SMA DHARMA BHAKTI PALEMBANG &bull; PERIODE 2026/2027
          </p>
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-500/10 text-indigo-300 border border-indigo-500/20 text-xs font-medium mt-2">
            <Vote className="w-3.5 h-3.5 text-indigo-400" />
            Tentukan pilihan Anda secara cermat. Tekan tombol "COBLOS" pada salah satu pasangan calon.
          </div>
        </div>
      </div>

      {/* CANDIDATE CARDS - DYNAMIC GRID */}
      <main className="max-w-7xl mx-auto w-full my-auto py-2">
        <div className={`grid ${gridClass} gap-6 lg:gap-8 items-stretch`}>
          {candidates.map((candidate, idx) => {
            const palette = CANDIDATE_PALETTES[idx % CANDIDATE_PALETTES.length];
            const badgeBgColor = palette.badge;
            const borderHighlight = palette.border;
            const coblosBtnStyle = palette.button;


            return (
              <div
                key={candidate.id}
                className={`relative bg-slate-900/90 rounded-3xl border-2 border-slate-800 transition-all duration-300 hover:shadow-2xl flex flex-col justify-between overflow-hidden group ${borderHighlight}`}
              >
                {/* Large Candidate Number Header */}
                <div className="p-4 sm:p-5 pb-3 flex items-center justify-between border-b border-slate-800/80 bg-slate-950/40">
                  <div className="flex items-center gap-3">
                    <div
                      className={`w-14 h-14 rounded-2xl ${badgeBgColor} border-2 flex items-center justify-center font-black text-2xl sm:text-3xl shadow-lg shrink-0`}
                    >
                      {candidate.number}
                    </div>
                    <div>
                      <span className="text-[11px] font-bold tracking-wider text-slate-400 uppercase">
                        PASLON NOMOR
                      </span>
                      <h3 className="text-lg font-black text-white group-hover:text-amber-300 transition-colors">
                        {candidate.title}
                      </h3>
                    </div>
                  </div>
                  <span className="text-xs px-2.5 py-1 rounded-full bg-slate-800 text-slate-300 font-semibold border border-slate-700">
                    Kandidat #{candidate.number}
                  </span>
                </div>

                {/* Candidate Photo */}
                <div className="relative px-4 pt-4">
                  <div className="relative aspect-[3/4] w-full rounded-2xl overflow-hidden border-2 border-slate-700/80 bg-slate-950 shadow-inner group-hover:border-slate-500 transition-colors">
                    <img
                      src={candidate.photoUrl}
                      alt={`Foto Paslon ${candidate.number} - ${candidate.title}`}
                      className="w-full h-full object-cover object-top group-hover:scale-102 transition-transform duration-500"
                    />

                    {/* Gradient Overlay for candidate names */}
                    <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-slate-950 via-slate-950/80 to-transparent p-4 pt-12 flex flex-col justify-end">
                      <div className="text-xs text-amber-300 font-bold uppercase tracking-wider">
                        Calon Ketua & Wakil Ketua:
                      </div>
                      <div className="text-sm font-extrabold text-white">
                        {candidate.leaderName}
                      </div>
                      <div className="text-xs font-semibold text-slate-300">
                        & {candidate.coLeaderName}
                      </div>
                    </div>
                  </div>
                </div>

                {/* Brief Info & Slogan */}
                <div className="p-5 space-y-4 flex-1 flex flex-col justify-between">
                  {/* Slogan pill */}
                  <div className="bg-slate-950/80 p-3 rounded-xl border border-slate-800 text-xs italic text-slate-300 min-h-[58px] flex items-center">
                    "{candidate.tagline}"
                  </div>

                  {/* Highlights programs */}
                  <div className="space-y-1.5">
                    <span className="text-[11px] font-bold uppercase tracking-wider text-slate-400">
                      Program Kerja Unggulan:
                    </span>
                    <div className="space-y-1">
                      {candidate.programs.slice(0, 3).map((p, idx) => (
                        <div
                          key={idx}
                          className="flex items-center gap-2 text-xs text-slate-300 font-medium truncate"
                        >
                          <span className="w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0" />
                          <span className="truncate">{p.title}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="pt-2 space-y-2.5">
                    <button
                      onClick={() => setModalCandidate(candidate)}
                      className="w-full py-2.5 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-bold text-slate-200 transition-colors flex items-center justify-center gap-1.5 border border-slate-700"
                    >
                      <Info className="w-4 h-4 text-amber-400" />
                      <span>Pelajari Visi, Misi & Proker</span>
                      <ChevronRight className="w-3.5 h-3.5 text-slate-400" />
                    </button>

                    <button
                      onClick={() => handleSelectToVote(candidate)}
                      className={`w-full py-3.5 px-4 rounded-xl font-black text-sm tracking-wide shadow-lg transition-all active:scale-97 flex items-center justify-center gap-2 cursor-pointer ${coblosBtnStyle}`}
                    >
                      <Vote className="w-5 h-5" />
                      <span>COBLOS PASLON {candidate.number}</span>
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </main>

      {/* Confirmation Modal */}
      {isConfirming && selectedCandidate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-md animate-fade-in">
          <div
            className="w-full max-w-lg bg-slate-900 border-2 border-slate-700 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6 text-center animate-scale-up"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="w-16 h-16 rounded-full bg-amber-400/20 text-amber-400 border border-amber-400/30 flex items-center justify-center mx-auto">
              <Vote className="w-8 h-8" />
            </div>

            <div className="space-y-2">
              <h3 className="text-2xl font-black text-white">
                Konfirmasi Pilihan Suara Anda
              </h3>
              <p className="text-sm text-slate-300">
                Pastikan pilihan Anda sudah benar sebelum mengirimkan suara ke kotak suara digital.
              </p>
            </div>

            {/* Candidate Card Preview */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 flex items-center gap-4 text-left">
              <div className="w-16 h-20 rounded-xl overflow-hidden border border-slate-700 shrink-0">
                <img
                  src={selectedCandidate.photoUrl}
                  alt={selectedCandidate.title}
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="space-y-1">
                <div className="inline-block px-2 py-0.5 rounded text-[11px] font-bold bg-amber-400 text-slate-950">
                  PASLON {selectedCandidate.number}
                </div>
                <h4 className="text-lg font-black text-white">
                  {selectedCandidate.title}
                </h4>
                <p className="text-xs text-slate-400">
                  {selectedCandidate.leaderName} &bull; {selectedCandidate.coLeaderName}
                </p>
              </div>
            </div>

            {/* Critical Warning */}
            <div className="p-3.5 rounded-xl bg-rose-950/60 border border-rose-600/40 text-left text-xs text-rose-200 flex items-start gap-2.5">
              <AlertTriangle className="w-4 h-4 text-rose-400 shrink-0 mt-0.5" />
              <div>
                <strong>Peringatan Akses:</strong> Pilihan bersifat <strong>final</strong> dan tidak dapat diubah lagi. Akses token atas nama <strong>{voter.studentName}</strong> akan langsung terkunci permanen untuk mencegah suara ganda.
              </div>
            </div>

            {/* Actions */}
            <div className="grid grid-cols-2 gap-3 pt-2">
              <button
                type="button"
                onClick={() => setIsConfirming(false)}
                disabled={isSubmitting}
                className="py-3 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-sm transition-colors cursor-pointer"
              >
                Kembali Cek
              </button>
              <button
                type="button"
                onClick={handleConfirmSubmit}
                disabled={isSubmitting}
                className="py-3 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-sm shadow-lg hover:shadow-emerald-500/25 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-50"
              >
                {isSubmitting ? (
                  <span>Menyimpan Suara...</span>
                ) : (
                  <>
                    <Check className="w-5 h-5" />
                    <span>Ya, Coblos Sekarang!</span>
                  </>
                )}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Candidate Full Modal */}
      <CandidateModal
        candidate={modalCandidate}
        isOpen={!!modalCandidate}
        onClose={() => setModalCandidate(null)}
        onSelectCandidate={(c) => {
          setSelectedCandidate(c);
          setIsConfirming(true);
        }}
      />

      {/* Footer: TIM IT SMA DB */}
      <footer className="max-w-7xl mx-auto w-full text-center py-3 border-t border-slate-800/80 mt-6">
        <p className="text-xs font-bold text-slate-400 tracking-wider uppercase">
          TIM IT SMA DB
        </p>
      </footer>
    </div>
  );
};

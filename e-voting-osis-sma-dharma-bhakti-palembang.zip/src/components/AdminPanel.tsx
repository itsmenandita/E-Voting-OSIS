import React, { useState, useRef } from 'react';
import * as XLSX from 'xlsx';
import jsPDF from 'jspdf';
import { Candidate, ElectionSettings, VoterToken } from '../types/election';
import { storageService } from '../services/storage';
import { OSIS_LOGO } from '../data/initialData';
import { BeritaAcaraModal } from './BeritaAcaraModal';
import { notificationService } from '../services/notification';
import {
  Users,
  Plus,
  Trash2,
  RefreshCw,
  Printer,
  CheckCircle2,
  Lock,
  Unlock,
  AlertTriangle,
  ArrowLeft,
  Search,
  Sparkles,
  Settings,
  Edit3,
  Save,
  Calendar,
  Download,
  UserCheck,
  X,
  FileDown,
  Filter,
  FileSpreadsheet,
  Upload,
} from 'lucide-react';

interface AdminPanelProps {
  candidates: Candidate[];
  onBackToBooth: () => void;
  onCandidatesUpdated: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({
  candidates,
  onBackToBooth,
  onCandidatesUpdated,
}) => {
  const [settings, setSettings] = useState<ElectionSettings>(storageService.getSettings());
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [pinInput, setPinInput] = useState('');
  const [pinError, setPinError] = useState(false);

  // Tab switch: 'tokens' | 'candidates' | 'settings'
  const [activeTab, setActiveTab] = useState<'tokens' | 'candidates' | 'settings'>('tokens');

  // Tokens state
  const [tokens, setTokens] = useState<VoterToken[]>(storageService.getTokens());
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'unused' | 'used'>('all');
  const [classFilter, setClassFilter] = useState<string>('all');

  // Single Add form
  const [newStudentName, setNewStudentName] = useState('');
  const [newGradeClass, setNewGradeClass] = useState('X-1');
  const [newNisn, setNewNisn] = useState('');
  const [newTokenCode, setNewTokenCode] = useState('');

  // Excel / CSV Import Modal State
  const [isExcelModalOpen, setIsExcelModalOpen] = useState(false);
  const [excelParsedData, setExcelParsedData] = useState<
    Array<{ studentName: string; gradeClass: string; nisn: string; token: string }>
  >([]);
  const [excelFileName, setExcelFileName] = useState('');
  const [pasteExcelText, setPasteExcelText] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Print Slip Modal & Filters (Per Kelas & Sesuai yang Belum Memilih)
  const [isPrintSlipOpen, setIsPrintSlipOpen] = useState(false);
  const [slipClassFilter, setSlipClassFilter] = useState<string>('all');
  const [slipStatusFilter, setSlipStatusFilter] = useState<'all' | 'unused' | 'used'>('unused');
  const [isGeneratingPdfSlips, setIsGeneratingPdfSlips] = useState(false);

  // Berita Acara Modal
  const [isBeritaAcaraOpen, setIsBeritaAcaraOpen] = useState(false);

  // Candidate Editing & Adding State
  const [editingCandidate, setEditingCandidate] = useState<Candidate | null>(null);
  const [isAddingCandidate, setIsAddingCandidate] = useState(false);
  const [newCandidateNumber, setNewCandidateNumber] = useState('');
  const [newCandidateTitle, setNewCandidateTitle] = useState('');
  const [newCandidateLeader, setNewCandidateLeader] = useState('');
  const [newCandidateCoLeader, setNewCandidateCoLeader] = useState('');
  const [newCandidateTagline, setNewCandidateTagline] = useState('');
  const [newCandidateVision, setNewCandidateVision] = useState('');
  const [newCandidateMissions, setNewCandidateMissions] = useState<string[]>(['']);
  const [newCandidatePrograms, setNewCandidatePrograms] = useState<Array<{ title: string; description: string }>>([
    { title: '', description: '' },
  ]);
  const [newCandidateSlogans, setNewCandidateSlogans] = useState<string[]>(['']);
  const [newCandidatePhotoUrl, setNewCandidatePhotoUrl] = useState('');
  const [newCandidateColor, setNewCandidateColor] = useState('purple');

  // Settings form state (NIP removed as requested)
  const [editSchoolName, setEditSchoolName] = useState(settings.schoolName);
  const [editSchoolAddress, setEditSchoolAddress] = useState(
    settings.schoolAddress || 'Jl. Mayor Zen Lr. Iwari No. 50 RT. 34'
  );
  const [editPeriod, setEditPeriod] = useState(settings.electionPeriod);
  const [editPin, setEditPin] = useState(settings.adminPin);
  const [editPrincipal, setEditPrincipal] = useState(
    settings.principalName || 'Dra. Hj. Nuraini, M.Pd.'
  );
  const [editPembina, setEditPembina] = useState(settings.pembinaName || 'Ahmad Syukri, S.Pd.');

  // New period wizard modal
  const [isNewPeriodModalOpen, setIsNewPeriodModalOpen] = useState(false);
  const [newPeriodYear, setNewPeriodYear] = useState('Periode 2027/2028');

  // Unique list of classes for the filter dropdown
  const defaultClasses = [
    'X-1',
    'X-2',
    'X-3',
    'XI MIPA 1',
    'XI MIPA 2',
    'XI IPS 1',
    'XI IPS 2',
    'XII MIPA 1',
    'XII MIPA 2',
    'XII IPS 1',
    'XII IPS 2',
  ];
  const dynamicClasses = Array.from(new Set(tokens.map((t) => t.gradeClass))).filter(Boolean);
  const allAvailableClasses = Array.from(new Set([...defaultClasses, ...dynamicClasses])).sort();

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    if (
      pinInput.trim() === settings.adminPin ||
      pinInput.trim() === 'adminosis' ||
      pinInput.trim() === 'admin'
    ) {
      setIsAuthenticated(true);
      setPinError(false);
      notificationService.notify(
        'Login Berhasil',
        'Selamat datang di Pusat Kendali Pemilihan OSIS.',
        'info'
      );
    } else {
      setPinError(true);
    }
  };

  const refreshTokens = () => {
    setTokens(storageService.getTokens());
  };

  const handleAddVoter = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newStudentName.trim()) return;

    const token =
      newTokenCode.trim() || `DBP-${Math.floor(1000 + Math.random() * 9000)}`;
    const nisn =
      newNisn.trim() || `008${Math.floor(1000000 + Math.random() * 9000000)}`;

    storageService.addSingleVoter({
      token: token.toUpperCase(),
      studentName: newStudentName.trim(),
      nisn,
      gradeClass: newGradeClass,
    });

    notificationService.notify(
      'Data Siswa Berhasil Ditambahkan',
      `${newStudentName.trim()} (${newGradeClass}) dengan token ${token.toUpperCase()} telah terdaftar.`,
      'success'
    );

    setNewStudentName('');
    setNewNisn('');
    setNewTokenCode('');
    refreshTokens();
  };

  const handleDeleteToken = (id: string, studentName: string) => {
    if (confirm(`Hapus data ${studentName} dari DPT?`)) {
      storageService.deleteToken(id);
      refreshTokens();
      notificationService.notify(
        'Data Siswa Dihapus',
        `Data pemilih ${studentName} telah dihapus dari DPT.`,
        'warning'
      );
    }
  };

  const handleToggleUnlock = (token: VoterToken) => {
    if (
      confirm(
        `Buka kembali akses untuk ${token.studentName}? Siswa ini akan diizinkan memilih ulang.`
      )
    ) {
      const allTokens = storageService.getTokens();
      const updated = allTokens.map((t) =>
        t.id === token.id
          ? {
              ...t,
              isUsed: false,
              usedAt: undefined,
              votedCandidateId: undefined,
              receiptId: undefined,
            }
          : t
      );
      storageService.saveTokens(updated);
      refreshTokens();
      notificationService.notify(
        'Akses Token Dibuka',
        `Token untuk ${token.studentName} berhasil dibuka kembali.`,
        'info'
      );
    }
  };

  // EXCEL / CSV FILE HANDLER
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setExcelFileName(file.name);
    const reader = new FileReader();

    reader.onload = (evt) => {
      try {
        const bstr = evt.target?.result;
        const wb = XLSX.read(bstr, { type: 'binary' });
        const wsname = wb.SheetNames[0];
        const ws = wb.Sheets[wsname];
        const rawJson: any[] = XLSX.utils.sheet_to_json(ws, { defval: '' });

        const mapped = rawJson.map((row: any) => {
          const keys = Object.keys(row);
          const findKey = (sub: string) =>
            keys.find((k) => k.toLowerCase().includes(sub.toLowerCase()));

          const nameKey = findKey('nama') || findKey('name') || findKey('siswa') || keys[0];
          const classKey = findKey('kelas') || findKey('grade') || findKey('class') || findKey('rombel') || keys[1];
          const nisnKey = findKey('nisn') || findKey('nis') || keys[2];
          const tokenKey = findKey('token') || findKey('kode') || findKey('pin') || keys[3];

          return {
            studentName: String(row[nameKey] || '').trim(),
            gradeClass: String(row[classKey] || 'X-1').trim(),
            nisn: String(row[nisnKey] || '').trim(),
            token: String(row[tokenKey] || '').trim().toUpperCase(),
          };
        }).filter((item) => item.studentName.length > 0);

        setExcelParsedData(mapped);
        notificationService.notify(
          'File Excel Terbaca',
          `Terdeteksi ${mapped.length} data siswa dari file ${file.name}.`,
          'info'
        );
      } catch (err) {
        alert('Gagal membaca file Excel. Pastikan format file adalah .xlsx atau .csv');
      }
    };

    reader.readAsBinaryString(file);
  };

  // PASTE EXCEL ROWS HANDLER
  const handleParsePastedExcel = () => {
    if (!pasteExcelText.trim()) return;

    const lines = pasteExcelText.trim().split('\n');
    const parsed = lines
      .map((line) => {
        const parts = line.split('\t').map((p) => p.trim());
        if (parts.length >= 1 && parts[0]) {
          return {
            studentName: parts[0] || '',
            gradeClass: parts[1] || 'X-1',
            nisn: parts[2] || '',
            token: parts[3] ? parts[3].toUpperCase() : '',
          };
        }
        return null;
      })
      .filter((item): item is { studentName: string; gradeClass: string; nisn: string; token: string } => item !== null && item.studentName.length > 0);

    setExcelParsedData(parsed);
    notificationService.notify(
      'Teks Excel Diproses',
      `Terdeteksi ${parsed.length} data siswa dari teks salinan.`,
      'info'
    );
  };

  const handleConfirmImport = () => {
    if (excelParsedData.length === 0) return;

    const res = storageService.importVotersFromList(excelParsedData);
    refreshTokens();
    setIsExcelModalOpen(false);
    setExcelParsedData([]);
    setExcelFileName('');
    setPasteExcelText('');
    notificationService.notify(
      'Impor Siswa Berhasil',
      `Sebanyak ${res.addedCount} siswa baru berhasil dimasukkan ke dalam DPT.`,
      'success'
    );
  };

  const handleDownloadExcelTemplate = () => {
    const templateData = [
      { 'Nama Siswa': 'Contoh: Ahmad Rizky', 'Kelas': 'X-1', 'NISN': '0081234567', 'Token (Opsional)': '' },
      { 'Nama Siswa': 'Contoh: Siti Nurhaliza', 'Kelas': 'X-2', 'NISN': '0087654321', 'Token (Opsional)': '' },
    ];
    const ws = XLSX.utils.json_to_sheet(templateData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Template DPT');
    XLSX.writeFile(wb, 'Format_Impor_DPT_Siswa_SMA_Dharma_Bhakti.xlsx');
    notificationService.notify('Template Diunduh', 'File format template Excel telah tersimpan.', 'info');
  };

  // Filtered Slips for Printing / Downloading PDF (Per Kelas & Sesuai Belum Memilih)
  const slipsToPrint = tokens.filter((t) => {
    const matchesClass = slipClassFilter === 'all' || t.gradeClass === slipClassFilter;
    const matchesStatus =
      slipStatusFilter === 'all' ||
      (slipStatusFilter === 'unused' && !t.isUsed) ||
      (slipStatusFilter === 'used' && t.isUsed);
    return matchesClass && matchesStatus;
  });

  // PDF DOWNLOAD FOR TOKEN SLIPS (Supports per-class and per-status filters)
  const handleDownloadSlipsPdf = (customList?: VoterToken[]) => {
    const targetList = customList || slipsToPrint;
    if (targetList.length === 0) {
      alert('Tidak ada data siswa untuk kriteria filter ini.');
      return;
    }

    setIsGeneratingPdfSlips(true);
    try {
      const pdf = new jsPDF('p', 'mm', 'a4');
      const pageWidth = pdf.internal.pageSize.getWidth();

      const cardWidth = 85;
      const cardHeight = 50;
      const marginX = (pageWidth - cardWidth * 2) / 3;
      const marginY = 15;
      const gapY = 6;

      let currentX = marginX;
      let currentY = marginY;
      let col = 0;
      let row = 0;

      targetList.forEach((t, index) => {
        if (index > 0 && index % 10 === 0) {
          pdf.addPage();
          col = 0;
          row = 0;
        }

        currentX = marginX + col * (cardWidth + marginX);
        currentY = marginY + row * (cardHeight + gapY);

        // Dashed border for cutting
        pdf.setDrawColor(180, 180, 180);
        pdf.setLineDashPattern([2, 2], 0);
        pdf.roundedRect(currentX, currentY, cardWidth, cardHeight, 3, 3);
        pdf.setLineDashPattern([], 0);

        // Header
        pdf.setFont('helvetica', 'bold');
        pdf.setFontSize(7.5);
        pdf.setTextColor(15, 23, 42);
        pdf.text(settings.schoolName.toUpperCase(), currentX + cardWidth / 2, currentY + 7, {
          align: 'center',
        });

        pdf.setFont('helvetica', 'normal');
        pdf.setFontSize(6.5);
        pdf.setTextColor(80, 80, 80);
        pdf.text('KARTU TOKEN PEMILIH OSIS', currentX + cardWidth / 2, currentY + 11, {
          align: 'center',
        });

        pdf.setDrawColor(220, 220, 220);
        pdf.line(currentX + 6, currentY + 13, currentX + cardWidth - 6, currentY + 13);

        // Student Info
        pdf.setFont('helvetica', 'bold');
        pdf.setFontSize(9);
        pdf.setTextColor(10, 10, 10);
        const nameLines = pdf.splitTextToSize(t.studentName, cardWidth - 12);
        pdf.text(nameLines[0], currentX + cardWidth / 2, currentY + 19, { align: 'center' });

        pdf.setFont('helvetica', 'normal');
        pdf.setFontSize(7.5);
        pdf.setTextColor(70, 70, 70);
        pdf.text(
          `Kelas: ${t.gradeClass}  |  NISN: ${t.nisn}`,
          currentX + cardWidth / 2,
          currentY + 24,
          { align: 'center' }
        );

        // Token Box
        pdf.setFillColor(15, 23, 42);
        pdf.roundedRect(currentX + 12, currentY + 28, cardWidth - 24, 11, 2, 2, 'F');
        pdf.setFont('courier', 'bold');
        pdf.setFontSize(13);
        pdf.setTextColor(251, 191, 36);
        pdf.text(t.token, currentX + cardWidth / 2, currentY + 35.5, { align: 'center' });

        // Footer note
        pdf.setFont('helvetica', 'italic');
        pdf.setFontSize(6);
        pdf.setTextColor(100, 100, 100);
        pdf.text(
          'Gunakan di Bilik Suara • Rahasia & Hanya 1x Coblos',
          currentX + cardWidth / 2,
          currentY + 44,
          { align: 'center' }
        );

        col++;
        if (col >= 2) {
          col = 0;
          row++;
        }
      });

      const classLabel = slipClassFilter === 'all' ? 'SEMUA_KELAS' : slipClassFilter.replace(/\s+/g, '_');
      const statusLabel = slipStatusFilter === 'unused' ? 'BELUM_MEMILIH' : slipStatusFilter === 'used' ? 'SUDAH_MEMILIH' : 'SEMUA';
      const filename = `KARTU_TOKEN_${classLabel}_${statusLabel}.pdf`;

      pdf.save(filename);
      notificationService.notify(
        'Slip Token Berhasil Diunduh (PDF)',
        `File ${filename} berisi ${targetList.length} kartu token siap dicetak.`,
        'success'
      );
    } catch (err) {
      console.error(err);
      alert('Gagal menghasilkan file PDF slip.');
    } finally {
      setIsGeneratingPdfSlips(false);
    }
  };

  // Filtered Tokens logic for DPT Table (Search + Status + Class Filter)
  const filteredTokens = tokens.filter((t) => {
    const matchesSearch =
      t.studentName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.token.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.gradeClass.toLowerCase().includes(searchQuery.toLowerCase()) ||
      t.nisn.includes(searchQuery);

    const matchesStatus =
      statusFilter === 'all' ||
      (statusFilter === 'unused' && !t.isUsed) ||
      (statusFilter === 'used' && t.isUsed);

    const matchesClass = classFilter === 'all' || t.gradeClass === classFilter;

    return matchesSearch && matchesStatus && matchesClass;
  });

  // Candidate Management Handlers (Dynamic Add, Edit, Delete, Photo)
  const openAddCandidateModal = () => {
    const nextNum = String(candidates.length + 1).padStart(2, '0');
    setNewCandidateNumber(nextNum);
    setNewCandidateTitle(`PASLON ${nextNum} - KARYA BERSAMA`);
    setNewCandidateLeader('');
    setNewCandidateCoLeader('');
    setNewCandidateTagline('Bersama membangun sekolah yang lebih maju, aktif, dan berprestasi.');
    setNewCandidateVision('Mewujudkan OSIS yang aspiratif, kolaboratif, dan berdampak positif bagi seluruh siswa.');
    setNewCandidateMissions([
      'Meningkatkan kebersamaan dan kekeluargaan antarsiswa.',
      'Menampung dan memperjuangkan aspirasi seluruh siswa secara transparan.',
    ]);
    setNewCandidatePrograms([
      { title: 'Program Aksi Siswa', description: 'Kegiatan pengembangan bakat, minat, dan kepemimpinan siswa.' },
    ]);
    setNewCandidateSlogans(['Satu Tekad, Satu Tujuan, Menuju Perubahan Bersama']);
    setNewCandidatePhotoUrl('/assets/aistudio/logo_osis_sma_0abdbba0.png');
    setNewCandidateColor('purple');
    setIsAddingCandidate(true);
  };

  const handlePhotoUploadForEditing = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      if (result && editingCandidate) {
        setEditingCandidate({ ...editingCandidate, photoUrl: result });
        notificationService.notify('Foto Dimuat', 'Foto kandidat berhasil diunggah.', 'info');
      }
    };
    reader.readAsDataURL(file);
  };

  const handlePhotoUploadForNew = (file: File) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      if (result) {
        setNewCandidatePhotoUrl(result);
        notificationService.notify('Foto Dimuat', 'Foto kandidat baru berhasil diunggah.', 'info');
      }
    };
    reader.readAsDataURL(file);
  };

  const handleCreateCandidate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCandidateLeader.trim()) {
      alert('Nama Calon Ketua wajib diisi.');
      return;
    }

    const colorConfig = {
      primary: newCandidateColor,
      bgLight: `bg-${newCandidateColor}-50/80 dark:bg-${newCandidateColor}-950/20`,
      badgeBg: `bg-${newCandidateColor}-600`,
      border: `border-${newCandidateColor}-500`,
      accent:
        newCandidateColor === 'purple'
          ? '#9333ea'
          : newCandidateColor === 'rose'
          ? '#e11d48'
          : newCandidateColor === 'teal'
          ? '#0d9488'
          : '#2563eb',
    };

    const newCandidate: Candidate = {
      id: `paslon-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
      number: newCandidateNumber.trim() || String(candidates.length + 1).padStart(2, '0'),
      title: newCandidateTitle.trim() || `PASLON ${newCandidateNumber}`,
      leaderName: newCandidateLeader.trim(),
      coLeaderName: newCandidateCoLeader.trim(),
      tagline: newCandidateTagline.trim(),
      vision: newCandidateVision.trim(),
      mission: newCandidateMissions.filter((m) => m.trim().length > 0),
      programs: newCandidatePrograms.filter((p) => p.title.trim().length > 0),
      slogans: newCandidateSlogans.filter((s) => s.trim().length > 0),
      photoUrl: newCandidatePhotoUrl.trim() || '/assets/aistudio/logo_osis_sma_0abdbba0.png',
      color: colorConfig,
    };

    storageService.addCandidate(newCandidate);
    onCandidatesUpdated();
    setIsAddingCandidate(false);
    notificationService.notify(
      'Kandidat Berhasil Ditambahkan',
      `Paslon ${newCandidate.number} (${newCandidate.title}) telah terdaftar dalam sistem pemilihan.`,
      'success'
    );
  };

  const handleDeleteCandidate = (candidate: Candidate) => {
    if (candidates.length <= 1) {
      alert('Tidak dapat menghapus! Minimal harus ada 1 pasangan calon dalam sistem.');
      return;
    }

    if (
      confirm(
        `Apakah Anda yakin ingin menghapus ${candidate.title} (${candidate.leaderName} & ${candidate.coLeaderName})?\n\nPerolehan suara yang terkait kandidat ini akan otomatis disesuaikan.`
      )
    ) {
      storageService.deleteCandidate(candidate.id);
      onCandidatesUpdated();
      notificationService.notify(
        'Kandidat Berhasil Dihapus',
        `Paslon ${candidate.number} (${candidate.title}) telah dihapus dari sistem.`,
        'warning'
      );
    }
  };

  const handleSaveCandidate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!editingCandidate) return;
    storageService.updateCandidateDetails(editingCandidate);
    notificationService.notify(
      'Data Paslon Berhasil Diperbarui',
      `Profil Paslon ${editingCandidate.number} (${editingCandidate.title}) tersimpan.`,
      'success'
    );
    setEditingCandidate(null);
    onCandidatesUpdated();
  };


  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    const updated: ElectionSettings = {
      ...settings,
      schoolName: editSchoolName,
      schoolAddress: editSchoolAddress,
      electionPeriod: editPeriod,
      adminPin: editPin.trim() || settings.adminPin,
      principalName: editPrincipal,
      pembinaName: editPembina,
    };
    storageService.saveSettings(updated);
    setSettings(updated);
    notificationService.notify(
      'Pengaturan Berhasil Disimpan',
      'Identitas sekolah, periode, dan pejabat penandatangan berhasil diperbarui.',
      'success'
    );
  };

  const handleStartNewYear = () => {
    if (!newPeriodYear.trim()) return;
    if (
      confirm(
        `Apakah Anda yakin ingin memulai ${newPeriodYear}? Seluruh suara lama akan direset agar siap untuk pemilu tahun ajaran berikutnya.`
      )
    ) {
      const updated: ElectionSettings = {
        ...settings,
        electionPeriod: newPeriodYear,
        status: 'active',
      };
      storageService.saveSettings(updated);
      setSettings(updated);
      setEditPeriod(newPeriodYear);
      storageService.resetVotesOnly();
      refreshTokens();
      setIsNewPeriodModalOpen(false);
      notificationService.notify(
        'Periode Pemilihan Baru Dimulai',
        `Sistem telah siap digunakan untuk ${newPeriodYear}.`,
        'success'
      );
    }
  };

  const handleResetVotes = () => {
    if (
      confirm(
        'PERINGATAN: Anda yakin ingin mengosongkan semua perolehan suara? Semua status token akan dikembalikan ke status "Belum Memilih".'
      )
    ) {
      storageService.resetVotesOnly();
      refreshTokens();
      notificationService.notify(
        'Perolehan Suara Direset',
        'Semua suara telah dikosongkan untuk pemungutan suara ulang.',
        'warning'
      );
    }
  };

  const handleFactoryReset = () => {
    if (
      confirm(
        'PERINGATAN KERAS: Reset pabrik akan menghapus semua perubahan, DPT kustom, dan mengembalikan data awal bawaan.'
      )
    ) {
      storageService.resetAllToFactory();
      refreshTokens();
      onCandidatesUpdated();
      notificationService.notify(
        'Sistem Direset ke Default',
        'Seluruh pengaturan dan data awal telah dipulihkan.',
        'warning'
      );
    }
  };

  // LOGIN SCREEN
  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4">
        <div className="w-full max-w-md bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 space-y-6 shadow-2xl">
          <div className="text-center space-y-3">
            <button
              onClick={onBackToBooth}
              className="inline-flex items-center gap-1.5 text-xs text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              <ArrowLeft className="w-4 h-4" /> Kembali ke Bilik Suara
            </button>
            <div className="flex justify-center">
              <img
                src={OSIS_LOGO}
                alt="Logo OSIS"
                className="w-16 h-16 object-contain drop-shadow"
              />
            </div>
            <h2 className="text-xl font-black text-white">Panel Panitia & Pengawas</h2>
            <p className="text-xs text-slate-400">
              Masukkan PIN Admin untuk mengelola DPT, kandidat, dan laporan pemilihan.
            </p>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <input
                type="password"
                value={pinInput}
                onChange={(e) => {
                  setPinInput(e.target.value);
                  setPinError(false);
                }}
                placeholder="Masukkan PIN Admin"
                className="w-full bg-slate-950 border border-slate-700 focus:border-amber-400 rounded-xl py-3 px-4 text-center font-mono text-lg text-white placeholder:text-slate-600"
                autoFocus
              />
              {pinError && (
                <p className="text-xs text-rose-400 mt-2 font-semibold text-center">
                  PIN salah! Silakan coba lagi.
                </p>
              )}
            </div>

            <button
              type="submit"
              className="w-full py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-sm transition-colors cursor-pointer shadow-lg"
            >
              Masuk ke Panel Panitia
            </button>
          </form>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 p-4 sm:p-6 lg:p-8 space-y-6">
      {/* Top Header */}
      <header className="max-w-7xl mx-auto flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <button
            onClick={onBackToBooth}
            className="p-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white transition-colors flex items-center gap-1.5 text-xs font-bold cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Ke Bilik Suara</span>
          </button>
          <img
            src={OSIS_LOGO}
            alt="Logo OSIS"
            className="w-10 h-10 object-contain hidden sm:block"
          />
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-amber-400 text-slate-950 uppercase">
                PANITIA / ADMIN
              </span>
              <span className="text-xs text-slate-400">
                {settings.schoolName} &bull; {settings.electionPeriod}
              </span>
            </div>
            <h1 className="text-lg sm:text-2xl font-black text-white">
              Pusat Kendali Pemilihan & DPT
            </h1>
          </div>
        </div>

        {/* Tab Switcher: Tokens | Kandidat | Settings */}
        <div className="flex items-center gap-2 bg-slate-900 p-1.5 rounded-2xl border border-slate-800">
          <button
            onClick={() => setActiveTab('tokens')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'tokens'
                ? 'bg-amber-500 text-slate-950'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Users className="w-4 h-4" />
            <span>DPT & Token ({tokens.length})</span>
          </button>
          <button
            onClick={() => setActiveTab('candidates')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'candidates'
                ? 'bg-amber-500 text-slate-950'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <UserCheck className="w-4 h-4" />
            <span>Kandidat</span>
          </button>
          <button
            onClick={() => setActiveTab('settings')}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-colors flex items-center gap-1.5 cursor-pointer ${
              activeTab === 'settings'
                ? 'bg-amber-500 text-slate-950'
                : 'text-slate-400 hover:text-white'
            }`}
          >
            <Settings className="w-4 h-4" />
            <span>Pengaturan Tahunan & Reset</span>
          </button>
        </div>
      </header>

      {/* TAB 1: TOKENS & DPT */}
      {activeTab === 'tokens' && (
        <main className="max-w-7xl mx-auto space-y-6">
          {/* Quick Stats + Actions Banner */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl">
              <span className="text-xs text-slate-400 uppercase font-bold">Total DPT</span>
              <div className="text-2xl font-black text-white font-mono">{tokens.length} Siswa</div>
            </div>
            <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl">
              <span className="text-xs text-slate-400 uppercase font-bold">Sudah Memilih</span>
              <div className="text-2xl font-black text-emerald-400 font-mono">
                {tokens.filter((t) => t.isUsed).length} Siswa
              </div>
            </div>
            <div className="bg-slate-900 border border-slate-800 p-4 rounded-2xl">
              <span className="text-xs text-slate-400 uppercase font-bold">Belum Memilih</span>
              <div className="text-2xl font-black text-amber-400 font-mono">
                {tokens.filter((t) => !t.isUsed).length} Siswa
              </div>
            </div>

            {/* Quick Action Buttons: Excel Import, Slip Token PDF, Export CSV */}
            <div className="bg-slate-900 border border-slate-800 p-3 rounded-2xl flex flex-col justify-center gap-2">
              <button
                onClick={() => {
                  setExcelParsedData([]);
                  setExcelFileName('');
                  setPasteExcelText('');
                  setIsExcelModalOpen(true);
                }}
                className="w-full py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow"
                title="Impor ratusan siswa sekaligus dari file Excel atau Spreadsheet"
              >
                <FileSpreadsheet className="w-4 h-4" />
                <span>Impor Siswa Sekaligus (Excel)</span>
              </button>

              <button
                onClick={() => setIsPrintSlipOpen(true)}
                className="w-full py-1.5 px-3 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors cursor-pointer shadow"
                title="Cetak atau unduh kartu slip token per kelas / yang belum memilih"
              >
                <Printer className="w-3.5 h-3.5" />
                <span>Slip Token (Per Kelas / Belum Memilih)</span>
              </button>
            </div>
          </div>

          {/* Form Tambah Siswa Tunggal & Info Ringkas */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            <div className="lg:col-span-7 bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-black text-white flex items-center gap-2">
                  <Plus className="w-4 h-4 text-emerald-400" />
                  Daftarkan Siswa & Token Baru (Manual)
                </h3>
                <button
                  type="button"
                  onClick={() => setIsExcelModalOpen(true)}
                  className="text-emerald-400 hover:text-emerald-300 font-bold text-xs flex items-center gap-1 cursor-pointer"
                >
                  <FileSpreadsheet className="w-3.5 h-3.5" /> Atau Impor Excel
                </button>
              </div>

              <form onSubmit={handleAddVoter} className="space-y-3 text-xs">
                <div>
                  <label className="block text-slate-400 font-bold mb-1">
                    Nama Lengkap Siswa
                  </label>
                  <input
                    type="text"
                    required
                    value={newStudentName}
                    onChange={(e) => setNewStudentName(e.target.value)}
                    placeholder="Contoh: Muhammad Farhan Pratama"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl py-2 px-3 text-white focus:border-emerald-400"
                  />
                </div>
                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-400 font-bold mb-1">Kelas</label>
                    <select
                      value={newGradeClass}
                      onChange={(e) => setNewGradeClass(e.target.value)}
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl py-2 px-3 text-white"
                    >
                      {allAvailableClasses.map((cls) => (
                        <option key={cls} value={cls}>
                          {cls}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-slate-400 font-bold mb-1">
                      NISN (Opsional)
                    </label>
                    <input
                      type="text"
                      value={newNisn}
                      onChange={(e) => setNewNisn(e.target.value)}
                      placeholder="008129..."
                      className="w-full bg-slate-950 border border-slate-700 rounded-xl py-2 px-3 text-white font-mono"
                    />
                  </div>
                </div>
                <div>
                  <label className="block text-slate-400 font-bold mb-1">
                    Kode Token Khusus (Kosongkan jika ingin dibuat otomatis)
                  </label>
                  <input
                    type="text"
                    value={newTokenCode}
                    onChange={(e) => setNewTokenCode(e.target.value.toUpperCase())}
                    placeholder="Contoh: DBP-9921"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl py-2 px-3 text-white font-mono uppercase"
                  />
                </div>
                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-colors cursor-pointer shadow"
                >
                  Simpan & Daftarkan Siswa ke DPT
                </button>
              </form>
            </div>

            {/* Rekapitulasi Partisipasi Per Kelas */}
            <div className="lg:col-span-5 bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-3 flex flex-col justify-between">
              <div>
                <h3 className="text-sm font-black text-white flex items-center gap-2">
                  <Filter className="w-4 h-4 text-amber-400" />
                  Statistik Suara per Rombel / Kelas
                </h3>
                <p className="text-xs text-slate-400 leading-relaxed mt-1">
                  Pantau kehadiran siswa per kelas atau klik untuk langsung mencetak token kelas tertentu.
                </p>

                <div className="mt-3 max-h-48 overflow-y-auto space-y-1.5 pr-1">
                  {allAvailableClasses
                    .filter((cls) => tokens.some((t) => t.gradeClass === cls))
                    .map((cls) => {
                      const classTokens = tokens.filter((t) => t.gradeClass === cls);
                      const usedCount = classTokens.filter((t) => t.isUsed).length;
                      const unusedCount = classTokens.length - usedCount;
                      const percent =
                        classTokens.length > 0
                          ? Math.round((usedCount / classTokens.length) * 100)
                          : 0;
                      return (
                        <div
                          key={cls}
                          onClick={() => setClassFilter(cls)}
                          className={`p-2 rounded-xl border text-xs flex items-center justify-between cursor-pointer transition-colors ${
                            classFilter === cls
                              ? 'bg-amber-500/20 border-amber-400 text-white'
                              : 'bg-slate-950 border-slate-800 hover:border-slate-700 text-slate-300'
                          }`}
                        >
                          <div>
                            <span className="font-bold">{cls}</span>
                            <span className="text-[10px] text-amber-400 ml-2 font-mono">
                              ({unusedCount} belum)
                            </span>
                          </div>
                          <div className="flex items-center gap-2 font-mono text-[11px]">
                            <span>
                              {usedCount}/{classTokens.length} Suara
                            </span>
                            <span className="text-emerald-400 font-bold">({percent}%)</span>
                          </div>
                        </div>
                      );
                    })}
                </div>
              </div>

              <div className="flex gap-2">
                {classFilter !== 'all' && (
                  <button
                    onClick={() => setClassFilter('all')}
                    className="flex-1 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-400 text-xs font-bold transition-colors cursor-pointer"
                  >
                    Tampilkan Semua Kelas
                  </button>
                )}
                <button
                  onClick={() => {
                    setSlipClassFilter(classFilter);
                    setSlipStatusFilter('unused');
                    setIsPrintSlipOpen(true);
                  }}
                  className="flex-1 py-1.5 rounded-lg bg-indigo-600/80 hover:bg-indigo-600 text-white text-xs font-bold transition-colors cursor-pointer flex items-center justify-center gap-1"
                >
                  <Printer className="w-3.5 h-3.5" />
                  <span>Cetak Token Kelas Ini</span>
                </button>
              </div>
            </div>
          </div>

          {/* DPT Table with Class Filter, Status Filter & Search */}
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-5 space-y-4">
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div>
                <h3 className="text-sm font-black text-white">
                  Daftar Pemilih Tetap (DPT) & Status Token
                </h3>
                <p className="text-[11px] text-slate-400">
                  Menampilkan {filteredTokens.length} dari {tokens.length} siswa terdaftar
                  {classFilter !== 'all' && ` (Filter: ${classFilter})`}
                  {statusFilter === 'unused' && ' • Hanya Belum Memilih'}
                  {statusFilter === 'used' && ' • Hanya Sudah Memilih'}
                </p>
              </div>

              {/* Filters & Actions */}
              <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
                <div className="relative flex-1 sm:w-44">
                  <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Cari nama / token..."
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl py-1.5 pl-9 pr-3 text-xs text-white"
                  />
                </div>

                {/* FILTER PER KELAS */}
                <select
                  value={classFilter}
                  onChange={(e) => setClassFilter(e.target.value)}
                  className="bg-slate-950 border border-slate-700 rounded-xl py-1.5 px-3 text-xs text-amber-400 font-bold cursor-pointer"
                  title="Filter pemilih berdasarkan kelas"
                >
                  <option value="all">Semua Kelas</option>
                  {allAvailableClasses.map((cls) => (
                    <option key={cls} value={cls}>
                      Kelas {cls}
                    </option>
                  ))}
                </select>

                {/* FILTER PER STATUS */}
                <select
                  value={statusFilter}
                  onChange={(e) => setStatusFilter(e.target.value as any)}
                  className="bg-slate-950 border border-slate-700 rounded-xl py-1.5 px-3 text-xs text-white cursor-pointer"
                >
                  <option value="all">Semua Status</option>
                  <option value="unused">Belum Memilih</option>
                  <option value="used">Sudah Memilih</option>
                </select>

                {/* UNDUH CSV SESUAI FILTER */}
                <button
                  onClick={() => {
                    const filename = `DPT_SISWA_${classFilter === 'all' ? 'SEMUA_KELAS' : classFilter.replace(/\s+/g, '_')}_${statusFilter}.csv`;
                    storageService.exportTokensToCsv(filteredTokens, filename);
                    notificationService.notify(
                      'Unduh Data DPT Berhasil',
                      `Sebanyak ${filteredTokens.length} data pemilih telah diunduh (${filename}).`,
                      'info'
                    );
                  }}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-amber-400 font-bold text-xs flex items-center gap-1 border border-slate-700 cursor-pointer"
                  title="Unduh data siswa yang tampil saat ini ke CSV / Excel"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Unduh CSV ({filteredTokens.length})</span>
                </button>
              </div>
            </div>

            {/* Table */}
            <div className="overflow-x-auto rounded-xl border border-slate-800">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-950 text-slate-400 uppercase text-[10px] tracking-wider border-b border-slate-800">
                  <tr>
                    <th className="py-3 px-4">Token</th>
                    <th className="py-3 px-4">Nama Siswa</th>
                    <th className="py-3 px-4">Kelas</th>
                    <th className="py-3 px-4">NISN</th>
                    <th className="py-3 px-4">Status Suara</th>
                    <th className="py-3 px-4">Waktu Pemilihan</th>
                    <th className="py-3 px-4 text-right">Aksi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {filteredTokens.length > 0 ? (
                    filteredTokens.map((t) => (
                      <tr key={t.id} className="hover:bg-slate-850/50 transition-colors">
                        <td className="py-3 px-4 font-mono font-bold text-amber-400">
                          {t.token}
                        </td>
                        <td className="py-3 px-4 font-semibold text-white">{t.studentName}</td>
                        <td className="py-3 px-4 text-slate-300 font-semibold">{t.gradeClass}</td>
                        <td className="py-3 px-4 font-mono text-slate-400">{t.nisn}</td>
                        <td className="py-3 px-4">
                          {t.isUsed ? (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30">
                              <Lock className="w-3 h-3" /> Terkunci (Sudah Memilih)
                            </span>
                          ) : (
                            <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                              <Unlock className="w-3 h-3" /> Siap Digunakan
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-4 font-mono text-slate-400 text-[11px]">
                          {t.usedAt
                            ? new Date(t.usedAt).toLocaleTimeString('id-ID', {
                                hour: '2-digit',
                                minute: '2-digit',
                                second: '2-digit',
                              }) + ' WIB'
                            : '-'}
                        </td>
                        <td className="py-3 px-4 text-right space-x-2">
                          {t.isUsed && (
                            <button
                              onClick={() => handleToggleUnlock(t)}
                              title="Buka kembali kunci token jika siswa perlu memilih ulang"
                              className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-amber-400 text-[10px] font-bold transition-colors cursor-pointer"
                            >
                              Buka Kunci
                            </button>
                          )}
                          <button
                            onClick={() => handleDeleteToken(t.id, t.studentName)}
                            title="Hapus token dari DPT"
                            className="p-1 rounded bg-rose-950/60 hover:bg-rose-900 text-rose-400 transition-colors cursor-pointer"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </td>
                      </tr>
                    ))
                  ) : (
                    <tr>
                      <td colSpan={7} className="py-8 text-center text-slate-500">
                        {tokens.length === 0
                          ? 'DPT masih kosong. Silakan gunakan tombol Impor Siswa Sekaligus (Excel) di atas.'
                          : 'Tidak ada data siswa / token yang cocok dengan filter atau pencarian.'}
                      </td>
                    </tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </main>
      )}

      {/* TAB 2: CANDIDATE EDITING */}
      {activeTab === 'candidates' && (
        <main className="max-w-7xl mx-auto space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
              <div>
                <h3 className="text-lg font-black text-white flex items-center gap-2">
                  <UserCheck className="w-5 h-5 text-amber-400" />
                  Kandidat Paslon OSIS ({candidates.length} Paslon)
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Kelola nama pasangan calon, julukan kabinet (ALDES ONE, BHAKTI GEMILANG, PIONIR BERKARYA), visi, misi, program kerja, slogan, dan foto resmi. Anda dapat menambah atau mengurangi jumlah kandidat sesuai pemilihan tiap tahunnya.
                </p>
              </div>
              <button
                type="button"
                onClick={openAddCandidateModal}
                className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black text-xs flex items-center gap-1.5 shadow-lg cursor-pointer shrink-0 transition-all hover:scale-[1.02]"
              >
                <Plus className="w-4 h-4" />
                <span>Tambah Paslon Baru</span>
              </button>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {candidates.map((c) => (
                <div
                  key={c.id}
                  className="bg-slate-950 border border-slate-800 rounded-2xl p-5 space-y-4 flex flex-col justify-between"
                >
                  <div className="space-y-3">
                    <div className="flex items-center justify-between gap-2">
                      <span className="w-9 h-9 rounded-xl bg-amber-400 text-slate-950 font-black font-mono flex items-center justify-center text-base shadow">
                        {c.number}
                      </span>
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => setEditingCandidate({ ...c })}
                          className="px-3 py-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs flex items-center gap-1 cursor-pointer shadow"
                        >
                          <Edit3 className="w-3.5 h-3.5" /> Edit Data
                        </button>
                        <button
                          onClick={() => handleDeleteCandidate(c)}
                          className="p-1.5 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 text-rose-400 border border-rose-500/30 text-xs font-bold flex items-center gap-1 cursor-pointer"
                          title={`Hapus Paslon ${c.number}`}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>


                    <div>
                      <h4 className="text-sm font-black text-white">{c.title}</h4>
                      <p className="text-xs text-slate-300 font-semibold mt-0.5">
                        Ketua: <span className="text-amber-400">{c.leaderName}</span>
                      </p>
                      <p className="text-xs text-slate-300 font-semibold">
                        Wakil: <span className="text-amber-400">{c.coLeaderName}</span>
                      </p>
                    </div>

                    <div className="w-full aspect-[3/4] rounded-xl overflow-hidden bg-slate-900 border border-slate-800 shadow">
                      <img
                        src={c.photoUrl}
                        alt={c.title}
                        className="w-full h-full object-cover object-top"
                      />
                    </div>

                    <div className="space-y-1.5 text-xs text-slate-300">
                      <div>
                        <span className="text-[10px] uppercase font-bold text-slate-500 block">
                          Visi:
                        </span>
                        <p className="line-clamp-2 text-slate-300 italic">{c.vision}</p>
                      </div>
                      <div>
                        <span className="text-[10px] uppercase font-bold text-slate-500 block">
                          Misi ({c.mission.length} poin):
                        </span>
                        <ul className="list-disc list-inside text-slate-400 text-[11px] line-clamp-2">
                          {c.mission.map((m, i) => (
                            <li key={i}>{m}</li>
                          ))}
                        </ul>
                      </div>
                      <div>
                        <span className="text-[10px] uppercase font-bold text-slate-500 block">
                          Program Kerja ({c.programs.length}):
                        </span>
                        <p className="text-[11px] text-slate-400 font-semibold">
                          {c.programs.map((p) => p.title).join(' • ')}
                        </p>
                      </div>
                      <div>
                        <span className="text-[10px] uppercase font-bold text-slate-500 block">
                          Slogan:
                        </span>
                        <p className="text-[11px] text-amber-400 italic font-medium">
                          &ldquo;{c.slogans[0] || '-'}&rdquo;
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </main>
      )}

      {/* MODAL: EDIT CANDIDATE COMPLETE FORM */}
      {editingCandidate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-sm overflow-y-auto">
          <div className="bg-slate-900 border border-slate-700 text-white rounded-3xl p-6 sm:p-8 max-w-3xl w-full space-y-5 shadow-2xl my-6 max-h-[92vh] flex flex-col">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 shrink-0">
              <div className="flex items-center gap-2">
                <span className="w-8 h-8 rounded-lg bg-amber-400 text-slate-950 font-black font-mono flex items-center justify-center text-sm">
                  {editingCandidate.number}
                </span>
                <h3 className="text-base font-black text-white">
                  Edit Data Lengkap Paslon {editingCandidate.number}
                </h3>
              </div>
              <button
                onClick={() => setEditingCandidate(null)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={handleSaveCandidate}
              className="space-y-4 text-xs overflow-y-auto pr-1 flex-1"
            >
              {/* Title / Moniker Editing: PASLON 01 ALDES ONE, BHAKTI GEMILANG, PIONIR BERKARYA */}
              <div>
                <label className="block text-slate-300 font-bold mb-1">
                  Nama Paslon / Julukan Kabinet
                </label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: PASLON 01 - ALDES ONE / PASLON 02 - BHAKTI GEMILANG / PASLON 03 - PIONIR BERKARYA"
                  value={editingCandidate.title}
                  onChange={(e) =>
                    setEditingCandidate({ ...editingCandidate, title: e.target.value })
                  }
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl py-2 px-3 text-white font-bold text-sm focus:border-amber-400"
                />
                <span className="text-[10px] text-amber-400 block mt-1">
                  Nama / Julukan ini akan muncul di kartu bilik suara, grafik transparansi suara, dan Berita Acara.
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-400 font-bold mb-1">Nomor Urut Paslon</label>
                  <input
                    type="text"
                    required
                    value={editingCandidate.number}
                    onChange={(e) =>
                      setEditingCandidate({ ...editingCandidate, number: e.target.value })
                    }
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl py-2 px-3 text-white font-mono font-bold text-center"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-slate-400 font-bold mb-1">Tagline / Semboyan Utama</label>
                  <input
                    type="text"
                    value={editingCandidate.tagline || ''}
                    onChange={(e) =>
                      setEditingCandidate({ ...editingCandidate, tagline: e.target.value })
                    }
                    placeholder="Contoh: Satukan arah, mengukir sejarah."
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl py-2 px-3 text-white"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-bold mb-1">Foto Resmi Pasangan Calon</label>
                <div className="flex flex-col sm:flex-row gap-3 items-center bg-slate-950/80 p-3 rounded-2xl border border-slate-800">
                  <div className="w-16 h-20 rounded-xl overflow-hidden bg-slate-900 border border-slate-700 shrink-0">
                    <img
                      src={editingCandidate.photoUrl}
                      alt="Preview"
                      className="w-full h-full object-cover object-top"
                    />
                  </div>
                  <div className="flex-1 w-full space-y-2">
                    <input
                      type="text"
                      value={editingCandidate.photoUrl}
                      onChange={(e) =>
                        setEditingCandidate({ ...editingCandidate, photoUrl: e.target.value })
                      }
                      placeholder="Masukkan URL foto atau unggah langsung dari file..."
                      className="w-full bg-slate-900 border border-slate-700 rounded-xl py-1.5 px-3 text-white text-[11px] font-mono"
                    />
                    <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-indigo-600/30 hover:bg-indigo-600/50 text-indigo-300 border border-indigo-500/40 text-xs font-bold cursor-pointer transition-colors">
                      <Upload className="w-3.5 h-3.5 text-indigo-400" />
                      <span>Unggah Foto dari Perangkat</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) handlePhotoUploadForEditing(file);
                        }}
                      />
                    </label>
                  </div>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-bold mb-1">Nama Calon Ketua</label>
                  <input
                    type="text"
                    required
                    value={editingCandidate.leaderName}
                    onChange={(e) =>
                      setEditingCandidate({ ...editingCandidate, leaderName: e.target.value })
                    }
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl py-2 px-3 text-white font-semibold"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-bold mb-1">
                    Nama Calon Wakil Ketua
                  </label>
                  <input
                    type="text"
                    required
                    value={editingCandidate.coLeaderName}
                    onChange={(e) =>
                      setEditingCandidate({ ...editingCandidate, coLeaderName: e.target.value })
                    }
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl py-2 px-3 text-white font-semibold"
                  />
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-bold mb-1">
                  Visi Pasangan Calon
                </label>

                <textarea
                  rows={3}
                  required
                  value={editingCandidate.vision}
                  onChange={(e) =>
                    setEditingCandidate({ ...editingCandidate, vision: e.target.value })
                  }
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-white"
                />
              </div>

              {/* Misi List */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-slate-400 font-bold">Poin-Poin Misi:</label>
                  <button
                    type="button"
                    onClick={() =>
                      setEditingCandidate({
                        ...editingCandidate,
                        mission: [...editingCandidate.mission, ''],
                      })
                    }
                    className="text-amber-400 hover:underline font-bold text-[11px] flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" /> Tambah Poin Misi
                  </button>
                </div>
                {editingCandidate.mission.map((m, idx) => (
                  <div key={idx} className="flex gap-2 items-center">
                    <span className="text-slate-500 font-mono text-[11px] w-5 text-right">
                      {idx + 1}.
                    </span>
                    <input
                      type="text"
                      value={m}
                      onChange={(e) => {
                        const newMission = [...editingCandidate.mission];
                        newMission[idx] = e.target.value;
                        setEditingCandidate({ ...editingCandidate, mission: newMission });
                      }}
                      className="flex-1 bg-slate-950 border border-slate-700 rounded-xl py-1.5 px-3 text-white"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        const newMission = editingCandidate.mission.filter((_, i) => i !== idx);
                        setEditingCandidate({ ...editingCandidate, mission: newMission });
                      }}
                      className="p-1.5 text-rose-400 hover:bg-slate-800 rounded-lg cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>

              {/* Program Kerja List */}
              <div className="space-y-3 pt-2">
                <div className="flex items-center justify-between">
                  <label className="text-slate-400 font-bold">Program Kerja Unggulan:</label>
                  <button
                    type="button"
                    onClick={() =>
                      setEditingCandidate({
                        ...editingCandidate,
                        programs: [
                          ...editingCandidate.programs,
                          { title: '', description: '' },
                        ],
                      })
                    }
                    className="text-amber-400 hover:underline font-bold text-[11px] flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" /> Tambah Program Kerja
                  </button>
                </div>
                {editingCandidate.programs.map((p, idx) => (
                  <div
                    key={idx}
                    className="p-3 bg-slate-950 border border-slate-800 rounded-2xl space-y-2 relative"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-amber-400 text-[11px]">Program {idx + 1}</span>
                      <button
                        type="button"
                        onClick={() => {
                          const newProgs = editingCandidate.programs.filter((_, i) => i !== idx);
                          setEditingCandidate({ ...editingCandidate, programs: newProgs });
                        }}
                        className="text-rose-400 hover:text-rose-300 p-1 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <input
                      type="text"
                      placeholder="Judul / Nama Program (Contoh: CAKRAWALA)"
                      value={p.title}
                      onChange={(e) => {
                        const newProgs = [...editingCandidate.programs];
                        newProgs[idx].title = e.target.value;
                        setEditingCandidate({ ...editingCandidate, programs: newProgs });
                      }}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg py-1.5 px-3 text-white font-semibold"
                    />
                    <textarea
                      rows={2}
                      placeholder="Deskripsi singkat kegiatan program"
                      value={p.description}
                      onChange={(e) => {
                        const newProgs = [...editingCandidate.programs];
                        newProgs[idx].description = e.target.value;
                        setEditingCandidate({ ...editingCandidate, programs: newProgs });
                      }}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white text-[11px]"
                    />
                  </div>
                ))}
              </div>

              {/* Slogans */}
              <div className="space-y-2 pt-2">
                <label className="block text-slate-400 font-bold">
                  Slogan & Jargon Perjuangan:
                </label>
                <textarea
                  rows={2}
                  value={editingCandidate.slogans.join('\n')}
                  onChange={(e) => {
                    const lines = e.target.value.split('\n').filter((l) => l.trim().length > 0);
                    setEditingCandidate({ ...editingCandidate, slogans: lines });
                  }}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-white font-sans text-xs italic"
                />
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-800 shrink-0">
                <button
                  type="button"
                  onClick={() => setEditingCandidate(null)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-bold cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black flex items-center gap-1.5 shadow cursor-pointer"
                >
                  <Save className="w-4 h-4" /> Simpan Seluruh Perubahan Paslon
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* MODAL: TAMBAH PASLON BARU (DYNAMIC CANDIDATE ADDITION) */}
      {isAddingCandidate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-sm overflow-y-auto">
          <div className="bg-slate-900 border border-slate-700 text-white rounded-3xl p-6 sm:p-8 max-w-3xl w-full space-y-5 shadow-2xl my-6 max-h-[92vh] flex flex-col">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 shrink-0">
              <div className="flex items-center gap-2">
                <span className="w-8 h-8 rounded-lg bg-emerald-500 text-slate-950 font-black font-mono flex items-center justify-center text-sm">
                  +
                </span>
                <div>
                  <h3 className="text-base font-black text-white">
                    Tambah Pasangan Calon (Paslon) Baru
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    Daftarkan nomor urut, julukan kabinet, kandidat ketua & wakil, visi misi, serta foto.
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setIsAddingCandidate(false)}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form
              onSubmit={handleCreateCandidate}
              className="space-y-4 text-xs overflow-y-auto pr-1 flex-1"
            >
              {/* Moniker / Title */}
              <div>
                <label className="block text-slate-300 font-bold mb-1">
                  Nama Paslon / Julukan Kabinet
                </label>
                <input
                  type="text"
                  required
                  placeholder="Contoh: PASLON 04 - KARYA NYATA / GENERASI EMAS"
                  value={newCandidateTitle}
                  onChange={(e) => setNewCandidateTitle(e.target.value)}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl py-2 px-3 text-white font-bold text-sm focus:border-emerald-400"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                <div>
                  <label className="block text-slate-400 font-bold mb-1">Nomor Urut Paslon</label>
                  <input
                    type="text"
                    required
                    value={newCandidateNumber}
                    onChange={(e) => setNewCandidateNumber(e.target.value)}
                    placeholder="04"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl py-2 px-3 text-white font-mono font-bold text-center"
                  />
                </div>
                <div className="sm:col-span-2">
                  <label className="block text-slate-400 font-bold mb-1">Tagline / Semboyan Utama</label>
                  <input
                    type="text"
                    value={newCandidateTagline}
                    onChange={(e) => setNewCandidateTagline(e.target.value)}
                    placeholder="Contoh: Berani melangkah, wujudkan aksi nyata."
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl py-2 px-3 text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-bold mb-1">Nama Calon Ketua</label>
                  <input
                    type="text"
                    required
                    value={newCandidateLeader}
                    onChange={(e) => setNewCandidateLeader(e.target.value)}
                    placeholder="Nama lengkap calon ketua"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl py-2 px-3 text-white font-semibold"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-bold mb-1">
                    Nama Calon Wakil Ketua
                  </label>
                  <input
                    type="text"
                    required
                    value={newCandidateCoLeader}
                    onChange={(e) => setNewCandidateCoLeader(e.target.value)}
                    placeholder="Nama lengkap calon wakil"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl py-2 px-3 text-white font-semibold"
                  />
                </div>
              </div>

              {/* Theme Color & Photo */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-bold mb-1">Warna Aksen Kartu</label>
                  <select
                    value={newCandidateColor}
                    onChange={(e) => setNewCandidateColor(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl py-2 px-3 text-white font-bold cursor-pointer"
                  >
                    <option value="purple">Ungu (Purple)</option>
                    <option value="rose">Merah Muda (Rose)</option>
                    <option value="teal">Toska (Teal)</option>
                    <option value="blue">Biru (Blue)</option>
                    <option value="amber">Kuning Emas (Amber)</option>
                    <option value="emerald">Hijau (Emerald)</option>
                    <option value="cyan">Sian (Cyan)</option>
                  </select>
                </div>
                <div>
                  <label className="block text-slate-400 font-bold mb-1">Foto Resmi Paslon</label>
                  <div className="flex gap-2 items-center">
                    <label className="flex-1 inline-flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold cursor-pointer border border-slate-700">
                      <Upload className="w-3.5 h-3.5 text-emerald-400" />
                      <span>Unggah Foto Paslon</span>
                      <input
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) handlePhotoUploadForNew(file);
                        }}
                      />
                    </label>
                    {newCandidatePhotoUrl && (
                      <div className="w-9 h-9 rounded-lg overflow-hidden bg-slate-950 border border-slate-700 shrink-0">
                        <img
                          src={newCandidatePhotoUrl}
                          alt="Preview"
                          className="w-full h-full object-cover object-top"
                        />
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-bold mb-1">
                  Visi Pasangan Calon
                </label>
                <textarea
                  rows={2}
                  required
                  value={newCandidateVision}
                  onChange={(e) => setNewCandidateVision(e.target.value)}
                  placeholder="Tuliskan visi paslon..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-white"
                />
              </div>

              {/* Misi List */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-slate-400 font-bold">Poin-Poin Misi:</label>
                  <button
                    type="button"
                    onClick={() => setNewCandidateMissions([...newCandidateMissions, ''])}
                    className="text-emerald-400 hover:underline font-bold text-[11px] flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" /> Tambah Poin Misi
                  </button>
                </div>
                {newCandidateMissions.map((m, idx) => (
                  <div key={idx} className="flex gap-2 items-center">
                    <span className="text-slate-500 font-mono text-[11px] w-5 text-right">
                      {idx + 1}.
                    </span>
                    <input
                      type="text"
                      value={m}
                      onChange={(e) => {
                        const arr = [...newCandidateMissions];
                        arr[idx] = e.target.value;
                        setNewCandidateMissions(arr);
                      }}
                      placeholder={`Poin misi ke-${idx + 1}`}
                      className="flex-1 bg-slate-950 border border-slate-700 rounded-xl py-1.5 px-3 text-white"
                    />
                    <button
                      type="button"
                      onClick={() => {
                        const arr = newCandidateMissions.filter((_, i) => i !== idx);
                        setNewCandidateMissions(arr);
                      }}
                      className="p-1.5 text-rose-400 hover:bg-slate-800 rounded-lg cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
              </div>

              {/* Program Kerja List */}
              <div className="space-y-3 pt-2">
                <div className="flex items-center justify-between">
                  <label className="text-slate-400 font-bold">Program Kerja Unggulan:</label>
                  <button
                    type="button"
                    onClick={() =>
                      setNewCandidatePrograms([
                        ...newCandidatePrograms,
                        { title: '', description: '' },
                      ])
                    }
                    className="text-emerald-400 hover:underline font-bold text-[11px] flex items-center gap-1 cursor-pointer"
                  >
                    <Plus className="w-3.5 h-3.5" /> Tambah Program Kerja
                  </button>
                </div>
                {newCandidatePrograms.map((p, idx) => (
                  <div
                    key={idx}
                    className="p-3 bg-slate-950 border border-slate-800 rounded-2xl space-y-2 relative"
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-bold text-emerald-400 text-[11px]">Program {idx + 1}</span>
                      <button
                        type="button"
                        onClick={() => {
                          const arr = newCandidatePrograms.filter((_, i) => i !== idx);
                          setNewCandidatePrograms(arr);
                        }}
                        className="text-rose-400 hover:text-rose-300 p-1 cursor-pointer"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                    <input
                      type="text"
                      placeholder="Judul Program (Contoh: AKSI NYATA SISWA)"
                      value={p.title}
                      onChange={(e) => {
                        const arr = [...newCandidatePrograms];
                        arr[idx].title = e.target.value;
                        setNewCandidatePrograms(arr);
                      }}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg py-1.5 px-3 text-white font-semibold"
                    />
                    <textarea
                      rows={2}
                      placeholder="Deskripsi kegiatan program kerja"
                      value={p.description}
                      onChange={(e) => {
                        const arr = [...newCandidatePrograms];
                        arr[idx].description = e.target.value;
                        setNewCandidatePrograms(arr);
                      }}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg p-2 text-white text-[11px]"
                    />
                  </div>
                ))}
              </div>

              {/* Slogans */}
              <div className="space-y-2 pt-2">
                <label className="block text-slate-400 font-bold">
                  Slogan & Jargon Perjuangan:
                </label>
                <textarea
                  rows={2}
                  value={newCandidateSlogans.join('\n')}
                  onChange={(e) => {
                    const lines = e.target.value.split('\n');
                    setNewCandidateSlogans(lines);
                  }}
                  placeholder="Ketik slogan atau jargon paslon (satu baris per slogan)..."
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl p-3 text-white font-sans text-xs italic"
                />
              </div>

              <div className="pt-3 flex justify-end gap-2 border-t border-slate-800 shrink-0">
                <button
                  type="button"
                  onClick={() => setIsAddingCandidate(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-bold cursor-pointer"
                >
                  Batal
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-black flex items-center gap-1.5 shadow cursor-pointer"
                >
                  <Plus className="w-4 h-4" /> Daftarkan Paslon Baru
                </button>
              </div>
            </form>
          </div>
        </div>
      )}


      {/* TAB 3: SETTINGS & ANNUAL REUSABILITY */}
      {activeTab === 'settings' && (
        <main className="max-w-4xl mx-auto space-y-6">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 space-y-6">
            <div className="flex items-center justify-between border-b border-slate-800 pb-4">
              <div>
                <h3 className="text-lg font-black text-white flex items-center gap-2">
                  <Calendar className="w-5 h-5 text-amber-400" />
                  Pengaturan Identitas & Penggunaan Tiap Tahun
                </h3>
                <p className="text-xs text-slate-400 mt-1">
                  Ubah nama sekolah, alamat, pejabat penandatangan, atau buka periode pemilihan baru tahun depan tanpa perlu mengubah kode sumber.
                </p>
              </div>
              <button
                onClick={() => setIsNewPeriodModalOpen(true)}
                className="px-4 py-2 rounded-xl bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 text-slate-950 font-black text-xs shadow-lg flex items-center gap-1.5 cursor-pointer"
              >
                <Sparkles className="w-4 h-4" />
                <span>Buka Periode Pemilihan Baru</span>
              </button>
            </div>

            <form onSubmit={handleSaveSettings} className="space-y-4 text-xs">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-400 font-bold mb-1">Nama Sekolah</label>
                  <input
                    type="text"
                    value={editSchoolName}
                    onChange={(e) => setEditSchoolName(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl py-2 px-3 text-white font-bold"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-bold mb-1">
                    Alamat Sekolah (Kop Surat)
                  </label>
                  <input
                    type="text"
                    value={editSchoolAddress}
                    onChange={(e) => setEditSchoolAddress(e.target.value)}
                    placeholder="Jl. Mayor Zen Lr. Iwari No. 50 RT. 34"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl py-2 px-3 text-white font-medium"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-slate-400 font-bold mb-1">
                    Periode Pemilihan Aktif
                  </label>
                  <input
                    type="text"
                    value={editPeriod}
                    onChange={(e) => setEditPeriod(e.target.value)}
                    placeholder="Contoh: Periode 2026/2027"
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl py-2 px-3 text-white font-bold"
                  />
                </div>
                <div>
                  <label className="block text-slate-400 font-bold mb-1">
                    PIN Admin Panitia (Rahasia)
                  </label>
                  <input
                    type="text"
                    value={editPin}
                    onChange={(e) => setEditPin(e.target.value)}
                    className="w-full bg-slate-950 border border-slate-700 rounded-xl py-2 px-3 text-white font-mono"
                  />
                </div>
              </div>

              {/* Pejabat Penandatangan Berita Acara (NIP removed as requested) */}
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-3">
                <span className="font-bold text-amber-400 text-xs block uppercase tracking-wider">
                  Pejabat Penandatangan Berita Acara:
                </span>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-400 font-semibold mb-1">
                      Nama Pembina OSIS
                    </label>
                    <input
                      type="text"
                      value={editPembina}
                      onChange={(e) => setEditPembina(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg py-2 px-3 text-white font-medium"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-400 font-semibold mb-1">
                      Nama Kepala Sekolah
                    </label>
                    <input
                      type="text"
                      value={editPrincipal}
                      onChange={(e) => setEditPrincipal(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg py-2 px-3 text-white font-medium"
                    />
                  </div>
                </div>
              </div>

              <button
                type="submit"
                className="py-2.5 px-5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-bold text-xs transition-colors cursor-pointer flex items-center gap-2 shadow"
              >
                <Save className="w-4 h-4" />
                <span>Simpan Seluruh Pengaturan</span>
              </button>
            </form>

            {/* Status switcher */}
            <div className="p-4 rounded-2xl bg-slate-950 border border-slate-800 space-y-3">
              <span className="text-xs text-slate-400 uppercase font-bold block">
                Status Pemilihan Sekarang:
              </span>
              <div className="flex flex-wrap gap-3">
                <button
                  onClick={() => {
                    storageService.saveSettings({ ...settings, status: 'active' });
                    setSettings({ ...settings, status: 'active' });
                    notificationService.notify(
                      'Status Pemilihan Diperbarui',
                      'Bilik Suara kini status: AKTIF (Terbuka untuk siswa).',
                      'success'
                    );
                  }}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    settings.status === 'active'
                      ? 'bg-emerald-500 text-slate-950 font-black ring-2 ring-emerald-400'
                      : 'bg-slate-800 text-slate-300'
                  }`}
                >
                  🟢 Aktif (Bilik Suara Terbuka)
                </button>
                <button
                  onClick={() => {
                    storageService.saveSettings({ ...settings, status: 'paused' });
                    setSettings({ ...settings, status: 'paused' });
                    notificationService.notify(
                      'Status Pemilihan Diperbarui',
                      'Bilik Suara kini status: DIJEDA SEMENTARA.',
                      'warning'
                    );
                  }}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    settings.status === 'paused'
                      ? 'bg-amber-500 text-slate-950 font-black ring-2 ring-amber-400'
                      : 'bg-slate-800 text-slate-300'
                  }`}
                >
                  🟡 Dijeda Sementara
                </button>
                <button
                  onClick={() => {
                    storageService.saveSettings({ ...settings, status: 'closed' });
                    setSettings({ ...settings, status: 'closed' });
                    notificationService.notify(
                      'Status Pemilihan Diperbarui',
                      'Bilik Suara kini status: DITUTUP (Pemilihan Berakhir).',
                      'info'
                    );
                  }}
                  className={`px-4 py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                    settings.status === 'closed'
                      ? 'bg-rose-500 text-white font-black ring-2 ring-rose-400'
                      : 'bg-slate-800 text-slate-300'
                  }`}
                >
                  🔴 Ditutup (Pemilu Berakhir)
                </button>
              </div>
            </div>

            {/* Danger Zone */}
            <div className="p-5 rounded-2xl bg-rose-950/40 border border-rose-800/60 space-y-4">
              <div className="flex items-center gap-2 text-rose-400 font-black text-sm">
                <AlertTriangle className="w-5 h-5" />
                <span>Zona Bahaya (Reset Data)</span>
              </div>

              <div className="flex flex-col sm:flex-row gap-3">
                <button
                  onClick={handleResetVotes}
                  className="py-2.5 px-4 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  <RefreshCw className="w-4 h-4" />
                  <span>Reset Semua Suara (Mulai Ulang Pemungutan)</span>
                </button>

                <button
                  onClick={handleFactoryReset}
                  className="py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  <Trash2 className="w-4 h-4" />
                  <span>Reset Pabrik (Kembali ke Awal)</span>
                </button>
              </div>
            </div>
          </div>
        </main>
      )}

      {/* MODAL: EXCEL / CSV BULK IMPORT */}
      {isExcelModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/85 backdrop-blur-sm overflow-y-auto">
          <div className="bg-slate-900 border border-slate-700 text-white rounded-3xl p-6 sm:p-8 max-w-2xl w-full space-y-4 shadow-2xl my-6">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-black text-white flex items-center gap-2">
                <FileSpreadsheet className="w-5 h-5 text-emerald-400" />
                Impor Data Siswa Sekaligus (Excel / CSV)
              </h3>
              <button
                onClick={() => {
                  setIsExcelModalOpen(false);
                  setExcelParsedData([]);
                }}
                className="text-slate-400 hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="space-y-4 text-xs">
              {/* Option 1: File Upload */}
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-slate-300 font-bold">
                    Pilih File Excel (.xlsx, .xls) atau .csv:
                  </label>
                  <button
                    onClick={handleDownloadExcelTemplate}
                    className="text-amber-400 hover:underline font-bold text-[11px] flex items-center gap-1 cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" /> Unduh Template Format Excel
                  </button>
                </div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".xlsx, .xls, .csv"
                  onChange={handleFileUpload}
                  className="block w-full text-xs text-slate-400 file:mr-3 file:py-2 file:px-4 file:rounded-xl file:border-0 file:text-xs file:font-bold file:bg-emerald-600 file:text-white hover:file:bg-emerald-500 cursor-pointer"
                />
                {excelFileName && (
                  <p className="text-emerald-400 font-bold text-[11px] flex items-center gap-1">
                    <CheckCircle2 className="w-3.5 h-3.5" /> File terpilih: {excelFileName}
                  </p>
                )}
              </div>

              {/* Option 2: Paste Rows from Excel */}
              <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl space-y-2">
                <div className="flex items-center justify-between">
                  <label className="text-slate-300 font-bold">
                    Atau Salin & Tempel Baris dari Spreadsheet:
                  </label>
                  <span className="text-[10px] text-slate-400">Kolom: Nama | Kelas | NISN | Token (Opsional)</span>
                </div>
                <textarea
                  rows={4}
                  placeholder="Tempel baris yang disalin dari Excel di sini..."
                  value={pasteExcelText}
                  onChange={(e) => setPasteExcelText(e.target.value)}
                  className="w-full bg-slate-900 border border-slate-700 rounded-xl p-2.5 text-white font-mono text-[11px]"
                />
                <button
                  type="button"
                  onClick={handleParsePastedExcel}
                  className="py-1.5 px-3 rounded-lg bg-slate-800 hover:bg-slate-700 text-amber-400 font-bold text-xs cursor-pointer"
                >
                  Proses Teks Salinan
                </button>
              </div>

              {/* Preview of Parsed Data */}
              {excelParsedData.length > 0 ? (
                <div className="space-y-2">
                  <div className="flex items-center justify-between text-xs font-bold text-emerald-400">
                    <span>Terdeteksi {excelParsedData.length} siswa siap diimpor:</span>
                  </div>
                  <div className="max-h-40 overflow-y-auto rounded-xl border border-slate-800 bg-slate-950 p-2 space-y-1 font-mono text-[11px]">
                    {excelParsedData.slice(0, 10).map((row, idx) => (
                      <div key={idx} className="flex justify-between text-slate-300 border-b border-slate-900 pb-0.5">
                        <span className="font-sans font-semibold text-white">{row.studentName}</span>
                        <span>{row.gradeClass}</span>
                        <span className="text-slate-400">{row.nisn}</span>
                        <span className="text-amber-400">{row.token || '(Auto Token)'}</span>
                      </div>
                    ))}
                    {excelParsedData.length > 10 && (
                      <p className="text-center text-[10px] text-slate-500 pt-1">
                        ...dan {excelParsedData.length - 10} siswa lainnya
                      </p>
                    )}
                  </div>
                </div>
              ) : (
                <div className="p-4 rounded-xl border border-dashed border-slate-800 text-center text-slate-500 text-xs">
                  Belum ada data dipilih. Silakan unggah file Excel Anda di atas.
                </div>
              )}
            </div>

            <div className="pt-2 flex justify-end gap-2 border-t border-slate-800">
              <button
                onClick={() => {
                  setIsExcelModalOpen(false);
                  setExcelParsedData([]);
                }}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-bold text-xs cursor-pointer"
              >
                Batal
              </button>
              <button
                onClick={handleConfirmImport}
                disabled={excelParsedData.length === 0}
                className="px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-black text-xs shadow cursor-pointer flex items-center gap-1.5"
              >
                <CheckCircle2 className="w-4 h-4" />
                <span>Simpan & Masukkan {excelParsedData.length} Siswa ke DPT</span>
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL: START NEW PERIOD NEXT YEAR */}
      {isNewPeriodModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm">
          <div className="bg-slate-900 border border-slate-700 text-white rounded-3xl p-6 max-w-md w-full space-y-4 shadow-2xl">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="text-base font-black text-white flex items-center gap-2">
                <Sparkles className="w-5 h-5 text-amber-400" />
                Buka Periode Pemilihan Tahun Depan
              </h3>
              <button
                onClick={() => setIsNewPeriodModalOpen(false)}
                className="text-slate-400 hover:text-white text-xs font-bold"
              >
                Batal
              </button>
            </div>

            <p className="text-xs text-slate-300 leading-relaxed">
              Fitur ini menyetel tahun ajaran baru, mengosongkan suara lama, dan membuka sistem bilik suara baru untuk pemilihan OSIS periode mendatang.
            </p>

            <div className="space-y-2 text-xs">
              <label className="block text-slate-400 font-bold">Label Periode Baru:</label>
              <input
                type="text"
                value={newPeriodYear}
                onChange={(e) => setNewPeriodYear(e.target.value)}
                placeholder="Contoh: Periode 2027/2028"
                className="w-full bg-slate-950 border border-slate-700 rounded-xl py-2 px-3 text-white font-bold text-sm"
              />
            </div>

            <div className="pt-2 flex justify-end gap-2">
              <button
                onClick={() => setIsNewPeriodModalOpen(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-bold cursor-pointer"
              >
                Batal
              </button>
              <button
                onClick={handleStartNewYear}
                className="px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 text-xs font-black shadow cursor-pointer"
              >
                Konfirmasi & Mulai Periode Baru
              </button>
            </div>
          </div>
        </div>
      )}

      {/* PRINT SLIP MODAL: FILTER PER KELAS & FILTER YANG BELUM MEMILIH */}
      {isPrintSlipOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-sm overflow-y-auto">
          <div className="bg-white text-slate-900 rounded-3xl p-6 max-w-4xl w-full space-y-4 shadow-2xl max-h-[92vh] flex flex-col">
            <div className="no-print flex flex-col gap-3 border-b pb-4 shrink-0">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h3 className="text-base font-black text-slate-900">
                    Cetak & Unduh Slip Token Pemilih
                  </h3>
                  <p className="text-xs text-slate-500">
                    Filter token per kelas atau cetak khusus siswa yang belum menggunakan hak suara.
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => handleDownloadSlipsPdf(slipsToPrint)}
                    disabled={isGeneratingPdfSlips || slipsToPrint.length === 0}
                    className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow"
                  >
                    <FileDown className="w-4 h-4" />
                    <span>
                      {isGeneratingPdfSlips
                        ? 'Membuat PDF...'
                        : `Unduh Slip PDF (${slipsToPrint.length} Siswa)`}
                    </span>
                  </button>
                  <button
                    onClick={() => setIsPrintSlipOpen(false)}
                    className="px-4 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 font-bold text-xs cursor-pointer"
                  >
                    Tutup
                  </button>

                </div>
              </div>

              {/* Filter Controls: Kelas & Status Pemilih */}
              <div className="p-3 bg-slate-100 border border-slate-300 rounded-2xl flex flex-wrap items-center gap-3 text-xs">
                <div className="flex items-center gap-1.5">
                  <span className="font-bold text-slate-700">Pilih Kelas:</span>
                  <select
                    value={slipClassFilter}
                    onChange={(e) => setSlipClassFilter(e.target.value)}
                    className="bg-white border border-slate-300 font-bold text-slate-900 rounded-lg py-1.5 px-3 cursor-pointer shadow-xs"
                  >
                    <option value="all">Semua Kelas ({tokens.length} Siswa)</option>
                    {allAvailableClasses.map((cls) => {
                      const countCls = tokens.filter((t) => t.gradeClass === cls).length;
                      return (
                        <option key={cls} value={cls}>
                          Kelas {cls} ({countCls} Siswa)
                        </option>
                      );
                    })}
                  </select>
                </div>

                <div className="flex items-center gap-1.5">
                  <span className="font-bold text-slate-700">Status Hak Suara:</span>
                  <select
                    value={slipStatusFilter}
                    onChange={(e) => setSlipStatusFilter(e.target.value as any)}
                    className="bg-white border border-slate-300 font-bold text-slate-900 rounded-lg py-1.5 px-3 cursor-pointer shadow-xs"
                  >
                    <option value="unused">Hanya Yang BELUM Memilih</option>
                    <option value="all">Semua Siswa (Sudah & Belum)</option>
                    <option value="used">Hanya Yang SUDAH Memilih</option>
                  </select>
                </div>

                <div className="ml-auto text-[11px] font-semibold text-slate-600 bg-white px-3 py-1.5 rounded-lg border border-slate-200">
                  Menampilkan <strong className="text-indigo-600">{slipsToPrint.length}</strong> kartu slip token
                </div>
              </div>
            </div>

            {/* Printable Slips Grid */}
            <div id="slips-printable-grid" className="overflow-y-auto p-2 grid grid-cols-2 sm:grid-cols-3 gap-3 print-only">
              {slipsToPrint.map((t) => (
                <div
                  key={t.id}
                  className="border-2 border-dashed border-slate-400 p-3.5 rounded-xl bg-white space-y-2 text-center text-slate-900"
                >
                  <div className="flex items-center justify-center gap-1.5 pb-1 border-b border-slate-200">
                    <img src={OSIS_LOGO} alt="OSIS" className="w-5 h-5 object-contain" />
                    <span className="text-[10px] font-black uppercase tracking-wider text-slate-700">
                      {settings.schoolName}
                    </span>
                  </div>
                  <div className="text-xs font-black text-slate-950 truncate">
                    {t.studentName}
                  </div>
                  <div className="text-[11px] font-semibold text-slate-600">
                    {t.gradeClass} &bull; NISN: {t.nisn}
                  </div>
                  <div className="bg-slate-900 text-amber-400 font-mono font-black text-base py-1 px-3 rounded-lg tracking-widest shadow-xs">
                    {t.token}
                  </div>
                  <div className="text-[9px] text-slate-500 pt-0.5">
                    Surat Suara Digital OSIS {settings.electionPeriod}
                  </div>
                </div>
              ))}
              {slipsToPrint.length === 0 && (
                <div className="col-span-3 py-12 text-center text-slate-400 text-xs">
                  Tidak ada data siswa untuk filter kelas/status ini.
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* BERITA ACARA MODAL */}
      <BeritaAcaraModal
        isOpen={isBeritaAcaraOpen}
        onClose={() => setIsBeritaAcaraOpen(false)}
        settings={settings}
        stats={storageService.getStats()}
        candidates={candidates}
      />
    </div>
  );
};

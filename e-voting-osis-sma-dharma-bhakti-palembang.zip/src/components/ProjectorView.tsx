import React, { useEffect, useState } from 'react';
import { Candidate, ElectionStats } from '../types/election';
import { storageService } from '../services/storage';
import { OSIS_LOGO } from '../data/initialData';
import {
  Maximize,
  Minimize,
  X,
  Award,
  Vote,
  Sparkles,
  TrendingUp,
  Users,
  CheckCircle2,
} from 'lucide-react';

interface ProjectorViewProps {
  candidates: Candidate[];
  onClose: () => void;
}

export const ProjectorView: React.FC<ProjectorViewProps> = ({
  candidates,
  onClose,
}) => {
  const [stats, setStats] = useState<ElectionStats>(storageService.getStats());
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());
  const settings = storageService.getSettings();

  useEffect(() => {
    const refresh = () => setStats(storageService.getStats());
    const unsub = storageService.subscribe(refresh);

    const clock = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => {
      unsub();
      clearInterval(clock);
    };
  }, []);

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen().catch(() => {});
      setIsFullscreen(true);
    } else {
      document.exitFullscreen().catch(() => {});
      setIsFullscreen(false);
    }
  };

  const totalVotes = stats.totalVoted;
  const getPercent = (count: number) => {
    if (totalVotes === 0) return 0;
    return Math.round((count / totalVotes) * 1000) / 10;
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950 text-white flex flex-col justify-between p-6 sm:p-10 select-none overflow-y-auto">
      {/* Top Header */}
      <header className="flex items-center justify-between border-b border-slate-800 pb-6 shrink-0">
        <div className="flex items-center gap-4">
          <div className="p-2 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl">
            <img
              src={OSIS_LOGO}
              alt="Logo OSIS"
              className="w-14 h-14 object-contain drop-shadow"
            />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-black uppercase bg-red-600 text-white tracking-widest animate-pulse">
                <span className="w-2 h-2 rounded-full bg-white" />
                LIVE SCREEN
              </span>
              <span className="text-xs text-amber-300 font-bold uppercase tracking-wider">
                {settings.schoolName} &bull; {settings.electionPeriod}
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black tracking-tight text-white mt-1">
              PAPAN TRANSPARANSI HASIL PERHITUNGAN SUARA
            </h1>
          </div>
        </div>

        <div className="flex items-center gap-4">
          <div className="text-right font-mono text-sm hidden md:block">
            <div className="text-slate-400 text-xs">Waktu Server Pemilihan</div>
            <div className="text-lg font-black text-amber-400">
              {currentTime.toLocaleTimeString('id-ID')} WIB
            </div>
          </div>

          <button
            onClick={toggleFullscreen}
            className="p-3 rounded-2xl bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
            title="Toggle Layar Penuh"
          >
            {isFullscreen ? <Minimize className="w-5 h-5" /> : <Maximize className="w-5 h-5" />}
          </button>

          <button
            onClick={onClose}
            className="p-3 rounded-2xl bg-rose-600/80 hover:bg-rose-500 text-white transition-colors"
            title="Tutup Mode Layar Proyektor"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
      </header>

      {/* Middle: Candidate Columns & Big Bars */}
      <main
        className={`my-auto py-6 grid ${
          candidates.length === 2
            ? 'grid-cols-1 md:grid-cols-2 max-w-5xl mx-auto'
            : candidates.length === 4
            ? 'grid-cols-1 sm:grid-cols-2 lg:grid-cols-4'
            : 'grid-cols-1 md:grid-cols-3'
        } gap-6 lg:gap-8 items-stretch w-full`}
      >
        {candidates.map((candidate, idx) => {
          const count = stats.candidateCounts[candidate.number] || 0;
          const percent = getPercent(count);

          const PALETTES = [
            { badge: 'bg-blue-600 text-white', bar: 'from-blue-600 to-sky-400', border: 'border-blue-500/40' },
            { badge: 'bg-amber-500 text-slate-950', bar: 'from-amber-500 to-yellow-300', border: 'border-amber-500/40' },
            { badge: 'bg-emerald-600 text-white', bar: 'from-emerald-600 to-teal-300', border: 'border-emerald-500/40' },
            { badge: 'bg-purple-600 text-white', bar: 'from-purple-600 to-fuchsia-400', border: 'border-purple-500/40' },
            { badge: 'bg-rose-600 text-white', bar: 'from-rose-600 to-pink-400', border: 'border-rose-500/40' },
            { badge: 'bg-teal-600 text-white', bar: 'from-teal-600 to-cyan-400', border: 'border-teal-500/40' },
          ];
          const theme = PALETTES[idx % PALETTES.length];

          return (
            <div
              key={candidate.id}
              className={`bg-slate-900/90 rounded-3xl p-6 border-2 ${theme.border} flex flex-col justify-between shadow-2xl relative overflow-hidden`}
            >

              {/* Header */}
              <div>
                <div className="flex items-center justify-between mb-4">
                  <div
                    className={`w-16 h-16 rounded-2xl ${theme.badge} flex items-center justify-center font-black text-3xl shadow-lg`}
                  >
                    {candidate.number}
                  </div>
                  <div className="text-right">
                    <span className="text-xs uppercase font-extrabold tracking-widest text-slate-400">
                      PASLON {candidate.number}
                    </span>
                    <h3 className="text-xl font-black text-white">{candidate.title}</h3>
                  </div>
                </div>

                {/* Candidate Photo (Full face visible with object-top and aspect-3/4) */}
                <div className="relative aspect-[3/4] max-h-72 w-full mx-auto rounded-2xl overflow-hidden border-2 border-slate-700 bg-slate-950 mb-5 shadow-lg">
                  <img
                    src={candidate.photoUrl}
                    alt={candidate.title}
                    className="w-full h-full object-cover object-top"
                  />
                  <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-slate-950 via-slate-950/80 to-transparent p-3 text-center">
                    <p className="text-xs font-bold text-white">
                      {candidate.leaderName} &bull; {candidate.coLeaderName}
                    </p>
                  </div>
                </div>
              </div>

              {/* Vote Score Big Display */}
              <div className="space-y-4">
                <div className="bg-slate-950/90 rounded-2xl p-4 border border-slate-800 text-center">
                  <div className="text-5xl sm:text-6xl font-black font-mono tracking-tight text-white">
                    {percent}%
                  </div>
                  <div className="text-base sm:text-lg font-bold text-amber-400 font-mono mt-1">
                    {count} Suara Terkumpul
                  </div>
                </div>

                {/* Vertical/Horizontal Bar */}
                <div className="w-full h-5 bg-slate-950 rounded-full overflow-hidden border border-slate-800 p-0.5">
                  <div
                    className={`h-full rounded-full bg-gradient-to-r ${theme.bar} transition-all duration-700 ease-out`}
                    style={{ width: `${Math.max(percent, percent > 0 ? 3 : 0)}%` }}
                  />
                </div>
              </div>
            </div>
          );
        })}
      </main>

      {/* Bottom Key Metrics Bar */}
      <footer className="bg-slate-900 border border-slate-800 rounded-2xl p-4 sm:p-5 flex flex-wrap items-center justify-around gap-4 shrink-0">
        <div className="flex items-center gap-3">
          <Users className="w-6 h-6 text-blue-400" />
          <div>
            <span className="text-xs text-slate-400 uppercase font-bold">Total DPT</span>
            <div className="text-xl font-black text-white font-mono">{stats.totalDpt} Siswa</div>
          </div>
        </div>

        <div className="h-8 w-px bg-slate-800 hidden sm:block" />

        <div className="flex items-center gap-3">
          <CheckCircle2 className="w-6 h-6 text-emerald-400" />
          <div>
            <span className="text-xs text-slate-400 uppercase font-bold">Total Suara Masuk</span>
            <div className="text-xl font-black text-emerald-400 font-mono">
              {stats.totalVoted} Suara
            </div>
          </div>
        </div>

        <div className="h-8 w-px bg-slate-800 hidden sm:block" />

        <div className="flex items-center gap-3">
          <TrendingUp className="w-6 h-6 text-amber-400" />
          <div>
            <span className="text-xs text-slate-400 uppercase font-bold">Partisipasi Pemilih</span>
            <div className="text-xl font-black text-amber-400 font-mono">
              {stats.participationPercentage}%
            </div>
          </div>
        </div>

        <div className="h-8 w-px bg-slate-800 hidden sm:block" />

        <div className="h-8 w-px bg-slate-800 hidden sm:block" />

        <div className="text-xs font-bold text-slate-300 uppercase tracking-wider bg-slate-950 px-3 py-1.5 rounded-xl border border-slate-800">
          TIM IT SMA DB
        </div>
      </footer>
    </div>
  );
};

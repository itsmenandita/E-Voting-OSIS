import React, { useEffect, useState } from 'react';
import confetti from 'canvas-confetti';
import { VoterToken } from '../types/election';
import { OSIS_LOGO } from '../data/initialData';
import {
  CheckCircle2,
  Lock,
  ArrowRight,
  ShieldCheck,
  School,
  QrCode,
  Calendar,
  Clock,
  Sparkles,
} from 'lucide-react';

interface SuccessReceiptProps {
  voter: VoterToken;
  receiptCode: string;
  onFinishRedirect: () => void;
  autoRedirectSeconds?: number;
}

export const SuccessReceipt: React.FC<SuccessReceiptProps> = ({
  voter,
  receiptCode,
  onFinishRedirect,
  autoRedirectSeconds = 5,
}) => {
  const [secondsLeft, setSecondsLeft] = useState(autoRedirectSeconds);

  // Play audio chime & confetti effect
  useEffect(() => {
    // Confetti
    try {
      confetti({
        particleCount: 80,
        spread: 70,
        origin: { y: 0.6 },
        colors: ['#10b981', '#f59e0b', '#3b82f6', '#ec4899'],
      });
    } catch {
      // ignore
    }

    // Audio chime using Web Audio API
    try {
      const AudioContextClass = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioContextClass) {
        const ctx = new AudioContextClass();
        const now = ctx.currentTime;
        const playTone = (freq: number, start: number, duration: number) => {
          const osc = ctx.createOscillator();
          const gain = ctx.createGain();
          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, now + start);
          gain.gain.setValueAtTime(0.001, now + start);
          gain.gain.exponentialRampToValueAtTime(0.15, now + start + 0.05);
          gain.gain.exponentialRampToValueAtTime(0.0001, now + start + duration);
          osc.connect(gain);
          gain.connect(ctx.destination);
          osc.start(now + start);
          osc.stop(now + start + duration);
        };
        playTone(523.25, 0, 0.25); // C5
        playTone(659.25, 0.15, 0.25); // E5
        playTone(783.99, 0.3, 0.35); // G5
        playTone(1046.5, 0.45, 0.5); // C6
      }
    } catch {
      // Audio context may be restricted by browser policy
    }
  }, []);

  // Countdown timer
  useEffect(() => {
    const timer = setInterval(() => {
      setSecondsLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          onFinishRedirect();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [onFinishRedirect]);

  const progressPercent = ((autoRedirectSeconds - secondsLeft) / autoRedirectSeconds) * 100;

  const nowFormatted = new Date().toLocaleDateString('id-ID', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  const timeFormatted = new Date().toLocaleTimeString('id-ID', {
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  });

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between p-4 sm:p-6 relative overflow-hidden">
      {/* Decorative gradient glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Top message */}
      <header className="max-w-xl mx-auto w-full text-center pt-4 z-10">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 text-xs font-bold mb-2">
          <Sparkles className="w-4 h-4 text-emerald-400" />
          <span>PENCATATAN SUARA BERHASIL</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white">
          Terima Kasih Atas Partisipasi Anda!
        </h1>
        <p className="text-xs sm:text-sm text-slate-300 mt-1">
          Suara Anda telah sah tersimpan dalam sistem pemungutan suara digital.
        </p>
      </header>

      {/* Digital Receipt Card */}
      <main className="max-w-md mx-auto w-full my-auto py-4 z-10">
        <div className="bg-slate-900 border-2 border-emerald-500/50 rounded-3xl p-6 sm:p-7 shadow-2xl relative overflow-hidden space-y-5">
          {/* Watermark OSIS */}
          <div className="absolute -right-8 -bottom-8 w-40 h-40 bg-emerald-500/5 rounded-full pointer-events-none border border-emerald-500/10" />

          {/* Card Header */}
          <div className="flex items-center justify-between border-b border-slate-800 pb-4">
            <div className="flex items-center gap-2.5">
              <div className="p-1.5 rounded-xl bg-slate-950 border border-slate-800">
                <img
                  src={OSIS_LOGO}
                  alt="Logo OSIS"
                  className="w-8 h-8 object-contain"
                />
              </div>
              <div>
                <h3 className="text-xs font-extrabold tracking-wide text-white">
                  SMA DHARMA BHAKTI PALEMBANG
                </h3>
                <p className="text-[10px] text-amber-300 font-bold uppercase">
                  Bukti Pencoblosan Sah (Digital Receipt)
                </p>
              </div>
            </div>
            <div className="w-10 h-10 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center border border-emerald-500/30">
              <CheckCircle2 className="w-6 h-6" />
            </div>
          </div>

          {/* Voter Details */}
          <div className="space-y-3 bg-slate-950/70 p-4 rounded-2xl border border-slate-800 text-xs">
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Nama Pemilih:</span>
              <strong className="text-white text-sm">{voter.studentName}</strong>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Kelas / Rombel:</span>
              <span className="text-slate-200 font-semibold">{voter.gradeClass}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">NISN:</span>
              <span className="font-mono text-slate-300">{voter.nisn}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-slate-400">Nomor Token:</span>
              <span className="font-mono text-amber-400 font-bold">{voter.token}</span>
            </div>
            <div className="flex justify-between items-center pt-2 border-t border-slate-800/80">
              <span className="text-slate-400">ID Transaksi / Bukti:</span>
              <span className="font-mono text-emerald-400 font-bold tracking-wider">
                {receiptCode}
              </span>
            </div>
            <div className="flex justify-between items-center text-[11px] text-slate-400">
              <span className="flex items-center gap-1">
                <Calendar className="w-3 h-3" /> {nowFormatted}
              </span>
              <span className="flex items-center gap-1 font-mono">
                <Clock className="w-3 h-3" /> {timeFormatted} WIB
              </span>
            </div>
          </div>

          {/* Locked Badge (Anti Suara Ganda) */}
          <div className="p-3.5 rounded-2xl bg-rose-950/60 border border-rose-600/40 text-rose-200 flex items-start gap-3">
            <div className="w-8 h-8 rounded-lg bg-rose-500/20 text-rose-400 flex items-center justify-center shrink-0 border border-rose-500/30 mt-0.5">
              <Lock className="w-4 h-4" />
            </div>
            <div className="space-y-0.5 text-xs">
              <strong className="font-extrabold text-rose-300 uppercase block">
                Akses Token Telah Terkunci
              </strong>
              <p className="text-rose-200/90 leading-relaxed text-[11px]">
                Token ini tidak dapat digunakan lagi. Sistem mengunci hak pilih Anda guna menjamin integritas pemilihan dan mencegah terjadinya suara ganda.
              </p>
            </div>
          </div>

          {/* Auto Redirect Countdown */}
          <div className="space-y-2 pt-1 text-center">
            <div className="flex items-center justify-between text-xs text-slate-300">
              <span>Bilik otomatis siap untuk siswa berikutnya dalam:</span>
              <span className="font-bold text-amber-400 text-sm font-mono">
                {secondsLeft}s
              </span>
            </div>
            {/* Progress bar */}
            <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-amber-500 to-emerald-400 transition-all duration-1000 ease-linear rounded-full"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>

          {/* Immediate Button */}
          <button
            onClick={onFinishRedirect}
            className="w-full py-3.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white font-black text-sm shadow-lg hover:shadow-indigo-500/30 transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-98"
          >
            <span>Selesai & Ganti Pemilih Sekarang</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </main>

      {/* Footer: TIM IT SMA DB */}
      <footer className="max-w-xl mx-auto w-full text-center py-2 z-10 border-t border-slate-800/80">
        <p className="text-xs font-bold text-slate-400 tracking-wider uppercase">
          TIM IT SMA DB
        </p>
      </footer>
    </div>
  );
};

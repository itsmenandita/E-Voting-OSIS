import React, { useEffect, useState } from 'react';
import { AppNotification, notificationService } from '../services/notification';
import { CheckCircle2, Info, AlertTriangle, X, Bell } from 'lucide-react';

export const NotificationToastContainer: React.FC = () => {
  const [notifications, setNotifications] = useState<AppNotification[]>([]);

  useEffect(() => {
    const unsubscribe = notificationService.subscribe((item) => {
      setNotifications((prev) => [item, ...prev.slice(0, 4)]);
      // Auto dismiss after 4 seconds
      setTimeout(() => {
        setNotifications((current) => current.filter((n) => n.id !== item.id));
      }, 4000);
    });

    return () => unsubscribe();
  }, []);

  if (notifications.length === 0) return null;

  return (
    <div className="fixed top-4 right-4 z-[9999] flex flex-col gap-2.5 max-w-sm w-full pointer-events-none px-3">
      {notifications.map((n) => (
        <div
          key={n.id}
          className={`pointer-events-auto rounded-2xl p-3.5 shadow-2xl border backdrop-blur-md flex items-start gap-3 transition-all duration-300 animate-in slide-in-from-top-4 fade-in ${
            n.type === 'success'
              ? 'bg-slate-900/95 border-emerald-500/40 text-white shadow-emerald-950/40'
              : n.type === 'warning'
              ? 'bg-slate-900/95 border-amber-500/40 text-white shadow-amber-950/40'
              : 'bg-slate-900/95 border-indigo-500/40 text-white shadow-indigo-950/40'
          }`}
        >
          <div
            className={`p-2 rounded-xl shrink-0 ${
              n.type === 'success'
                ? 'bg-emerald-500/20 text-emerald-400'
                : n.type === 'warning'
                ? 'bg-amber-500/20 text-amber-400'
                : 'bg-indigo-500/20 text-indigo-400'
            }`}
          >
            {n.type === 'success' ? (
              <CheckCircle2 className="w-4 h-4" />
            ) : n.type === 'warning' ? (
              <AlertTriangle className="w-4 h-4" />
            ) : (
              <Bell className="w-4 h-4" />
            )}
          </div>

          <div className="flex-1 min-w-0 pr-1">
            <h4 className="text-xs font-black tracking-wide text-white flex items-center gap-1.5">
              <span>{n.title}</span>
            </h4>
            <p className="text-[11px] text-slate-300 mt-0.5 leading-relaxed font-medium">
              {n.message}
            </p>
          </div>

          <button
            onClick={() =>
              setNotifications((current) => current.filter((item) => item.id !== n.id))
            }
            className="text-slate-400 hover:text-white p-1 rounded-lg shrink-0 cursor-pointer"
            aria-label="Tutup notifikasi"
          >
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      ))}
    </div>
  );
};

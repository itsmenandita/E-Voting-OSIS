import React, { useState } from 'react';
import { VoterToken } from '../types/election';
import { storageService } from '../services/storage';
import { OSIS_LOGO } from '../data/initialData';
import {
  KeyRound,
  Lock,
  CheckCircle2,
  AlertTriangle,
  ArrowRight,
  ShieldCheck,
  UserCheck,
} from 'lucide-react';

interface TokenScreenProps {
  onTokenVerified: (voter: VoterToken) => void;
  onOpenQuickCount: () => void;
  onOpenAdmin: () => void;
}

export const TokenScreen: React.FC<TokenScreenProps> = ({
  onTokenVerified,
  onOpenQuickCount,
  onOpenAdmin,
}) => {
  const [inputToken, setInputToken] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [errorType, setErrorType] = useState<string | null>(null);
  const [verifiedVoter, setVerifiedVoter] = useState<VoterToken | null>(null);
  const [isVerifying, setIsVerifying] = useState(false);

  const settings = storageService.getSettings();

  const handleVerify = () => {
    setErrorMsg(null);
    setErrorType(null);
    setVerifiedVoter(null);

    const clean = inputToken.trim();
    if (!clean) {
      setErrorMsg('Harap masukkan kode token pemilihan Anda.');
      return;
    }

    setIsVerifying(true);
    setTimeout(() => {
      setIsVerifying(false);
      const res = storageService.verifyToken(clean);
      if (res.valid && res.voter) {
        setVerifiedVoter(res.voter);
      } else {
        setErrorType(res.errorType || 'unknown');
        setErrorMsg(res.errorMessage || 'Token tidak valid.');
        if (res.voter) {
          setVerifiedVoter(res.voter);
        }
      }
    }, 200);
  };

  const handleProceedToVote = () => {
    if (verifiedVoter && !verifiedVoter.isUsed) {
      onTokenVerified(verifiedVoter);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col justify-between p-4 sm:p-6 select-none">
      {/* Top Bar */}
      <header className="max-w-4xl mx-auto w-full flex items-center justify-between pb-4 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <img
            src={OSIS_LOGO}
            alt="Logo OSIS SMA"
            className="w-10 h-10 object-contain drop-shadow"
          />
          <div>
            <h1 className="text-sm sm:text-base font-black tracking-wide text-white">
              {settings.schoolName || 'SMA DHARMA BHAKTI PALEMBANG'}
            </h1>
            <p className="text-[11px] text-amber-400 font-bold tracking-wider">
              E-VOTING OSIS &bull; {settings.electionPeriod || 'Periode 2026/2027'}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onOpenQuickCount}
            className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-xs font-bold text-slate-200 transition-colors border border-slate-800"
          >
            <span>Hasil Suara</span>
          </button>
          <button
            onClick={onOpenAdmin}
            className="px-3 py-1.5 rounded-xl bg-slate-900/50 hover:bg-slate-800 text-xs font-semibold text-slate-400 hover:text-slate-200 transition-colors border border-slate-800/60"
          >
            Panel Panitia
          </button>
        </div>
      </header>

      {/* Main Container */}
      <main className="max-w-lg mx-auto w-full my-auto py-6">
        <div className="bg-slate-900 border border-slate-800 rounded-3xl p-6 sm:p-8 shadow-2xl space-y-6">
          {/* Logo OSIS added right above "BILIK SUARA DIGITAL ELEKTRONIK" */}
          <div className="text-center space-y-3">
            <div className="flex justify-center">
              <div className="p-2 rounded-2xl bg-slate-950 border border-slate-800 inline-block shadow-lg">
                <img
                  src={OSIS_LOGO}
                  alt="Logo Komisi Pemilihan OSIS"
                  className="w-20 h-20 sm:w-24 sm:h-24 object-contain mx-auto"
                />
              </div>
            </div>

            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-500/10 text-blue-400 border border-blue-500/20 text-xs font-black tracking-wide">
              <ShieldCheck className="w-4 h-4 text-blue-400" />
              <span>BILIK SUARA DIGITAL ELEKTRONIK</span>
            </div>

            <h2 className="text-2xl sm:text-3xl font-black text-white tracking-tight">
              Masukkan Token Pemilih
            </h2>
            <p className="text-xs sm:text-sm text-slate-400 max-w-sm mx-auto">
              Silakan ketikkan kode token resmi dari panitia untuk membuka surat suara digital Anda.
            </p>
          </div>

          {/* Form Input */}
          <div className="space-y-4">
            <div className="relative">
              <label className="block text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                Kode Token Siswa:
              </label>
              <div className="relative flex items-center">
                <KeyRound className="w-5 h-5 absolute left-4 text-slate-500 pointer-events-none" />
                <input
                  type="text"
                  value={inputToken}
                  onChange={(e) => {
                    setInputToken(e.target.value.toUpperCase());
                    setErrorMsg(null);
                    setVerifiedVoter(null);
                  }}
                  onKeyDown={(e) => e.key === 'Enter' && handleVerify()}
                  placeholder="Contoh: DBP-7821"
                  className="w-full bg-slate-950 border-2 border-slate-800 focus:border-amber-400 focus:ring-4 focus:ring-amber-400/10 rounded-2xl py-3.5 pl-12 pr-28 text-lg font-mono font-black tracking-widest text-white placeholder:text-slate-600 transition-all uppercase"
                  autoFocus
                />
                <button
                  onClick={handleVerify}
                  disabled={isVerifying}
                  className="absolute right-2 px-4 py-2 rounded-xl bg-amber-500 hover:bg-amber-400 text-slate-950 font-black text-xs shadow-md transition-all active:scale-95 disabled:opacity-50 cursor-pointer"
                >
                  {isVerifying ? 'Cek...' : 'Periksa'}
                </button>
              </div>
            </div>

            {/* ERROR STATE: ALREADY USED (LOCKED ACCESS) */}
            {errorType === 'already_used' && (
              <div className="p-4 rounded-2xl bg-rose-950/80 border-2 border-rose-500/70 text-rose-200 space-y-3 animate-fade-in shadow-lg">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-xl bg-rose-500/20 text-rose-400 flex items-center justify-center shrink-0 border border-rose-500/40">
                    <Lock className="w-5 h-5" />
                  </div>
                  <div className="space-y-1">
                    <h3 className="font-extrabold text-rose-300 text-sm sm:text-base flex items-center gap-1.5">
                      <span>AKSES TERKUNCI (SUARA SUDAH MASUK)</span>
                    </h3>
                    <p className="text-xs text-rose-200 leading-relaxed">
                      {errorMsg}
                    </p>
                  </div>
                </div>

                <div className="p-3 bg-black/40 rounded-xl text-xs space-y-1 font-mono border border-rose-900/50">
                  <div className="flex justify-between text-rose-300">
                    <span>Status Hak Pilih:</span>
                    <strong className="text-rose-400">HANYA 1 KALI (SELESAI)</strong>
                  </div>
                  <div className="flex justify-between text-slate-300">
                    <span>Pencegahan:</span>
                    <span>Anti Suara Ganda Aktif</span>
                  </div>
                </div>

                <p className="text-[11px] text-slate-400 text-center italic">
                  Token ini telah hangus dan tidak dapat dipakai kembali oleh siapapun. Silakan persilakan siswa berikutnya.
                </p>
              </div>
            )}

            {/* ERROR STATE: NOT FOUND / INACTIVE */}
            {errorMsg && errorType !== 'already_used' && (
              <div className="p-4 rounded-2xl bg-amber-950/60 border border-amber-500/60 text-amber-200 flex items-start gap-3 animate-fade-in">
                <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
                <div className="text-xs space-y-1">
                  <strong className="font-bold block text-amber-300">Perhatian:</strong>
                  <p>{errorMsg}</p>
                </div>
              </div>
            )}

            {/* SUCCESS STATE: VALID VOTER CONFIRMED */}
            {verifiedVoter && !verifiedVoter.isUsed && (
              <div className="p-5 rounded-2xl bg-emerald-950/70 border-2 border-emerald-500 text-emerald-100 space-y-4 animate-scale-up shadow-xl">
                <div className="flex items-center gap-3 pb-3 border-b border-emerald-500/30">
                  <div className="w-10 h-10 rounded-full bg-emerald-500 text-slate-950 flex items-center justify-center font-bold">
                    <UserCheck className="w-6 h-6" />
                  </div>
                  <div>
                    <span className="text-[11px] font-extrabold uppercase tracking-wider text-emerald-400 flex items-center gap-1">
                      <CheckCircle2 className="w-3.5 h-3.5" /> Data DPT Terverifikasi Sah
                    </span>
                    <h3 className="text-base sm:text-lg font-black text-white">
                      {verifiedVoter.studentName}
                    </h3>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 text-xs bg-slate-950/60 p-3 rounded-xl border border-emerald-900/40">
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">Kelas</span>
                    <span className="font-bold text-white text-sm">{verifiedVoter.gradeClass}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[10px] uppercase font-bold">NISN</span>
                    <span className="font-mono text-emerald-300">{verifiedVoter.nisn}</span>
                  </div>
                </div>

                <div className="text-xs text-emerald-300/90 leading-relaxed bg-emerald-900/30 p-2.5 rounded-lg border border-emerald-700/30">
                  Perhatian: Anda memiliki hak <strong>1 suara</strong>. Setelah Anda memilih di bilik suara, token ini akan otomatis terkunci.
                </div>

                <button
                  onClick={handleProceedToVote}
                  className="w-full py-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-black text-base shadow-lg hover:shadow-emerald-500/30 transition-all flex items-center justify-center gap-2 group active:scale-98 cursor-pointer"
                >
                  <span>Buka Surat Suara & Coblos Sekarang</span>
                  <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Footer Info: Replaced with TIM IT SMA DB */}
      <footer className="max-w-4xl mx-auto w-full text-center py-3 border-t border-slate-800/80">
        <p className="text-xs font-bold text-slate-400 tracking-wider uppercase">
          TIM IT SMA DB
        </p>
      </footer>
    </div>
  );
};

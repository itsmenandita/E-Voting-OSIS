import React, { useState } from 'react';
import jsPDF from 'jspdf';
import { Candidate, ElectionSettings, ElectionStats } from '../types/election';
import { OSIS_LOGO } from '../data/initialData';
import { notificationService } from '../services/notification';
import { Download, X, FileText, CheckCircle2 } from 'lucide-react';

interface BeritaAcaraModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: ElectionSettings;
  stats: ElectionStats;
  candidates: Candidate[];
}

export const BeritaAcaraModal: React.FC<BeritaAcaraModalProps> = ({
  isOpen,
  onClose,
  settings,
  stats,
  candidates,
}) => {
  const [isGeneratingPdf, setIsGeneratingPdf] = useState(false);

  if (!isOpen) return null;

  const now = new Date();
  const fullDayFormatted = now.toLocaleDateString('id-ID', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  });

  const sortedCandidates = [...candidates].sort((a, b) => {
    const countA = stats.candidateCounts[a.number] || 0;
    const countB = stats.candidateCounts[b.number] || 0;
    return countB - countA;
  });

  const winner = stats.totalVoted > 0 ? sortedCandidates[0] : null;
  const getPercent = (count: number) => {
    if (stats.totalVoted === 0) return 0;
    return Math.round((count / stats.totalVoted) * 1000) / 10;
  };

  const pembinaName = settings.pembinaName || 'Ahmad Syukri, S.Pd.';
  const principalName = settings.principalName || 'Dra. Hj. Nuraini, M.Pd.';

  // Helper to load logo to dataURL for fallback vector jsPDF
  const loadLogoBase64 = (): Promise<string | null> => {
    return new Promise((resolve) => {
      const img = new Image();
      img.crossOrigin = 'Anonymous';
      img.onload = () => {
        try {
          const canvas = document.createElement('canvas');
          canvas.width = img.width;
          canvas.height = img.height;
          const ctx = canvas.getContext('2d');
          if (ctx) {
            ctx.drawImage(img, 0, 0);
            resolve(canvas.toDataURL('image/png'));
          } else {
            resolve(null);
          }
        } catch {
          resolve(null);
        }
      };
      img.onerror = () => resolve(null);
      img.src = OSIS_LOGO;
      setTimeout(() => resolve(null), 800);
    });
  };

  // MASTERPIECE VECTOR PDF GENERATOR: 100% IDENTICAL TO PREVIEW, CRISP & ROBUST
  const handleDownloadPdf = async () => {
    setIsGeneratingPdf(true);
    const filename = `BERITA_ACARA_PEMILIHAN_OSIS_${settings.electionPeriod.replace(
      /[^a-zA-Z0-9]/g,
      '_'
    )}.pdf`;

    try {
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4',
      });

      const logoData = await loadLogoBase64();
      const leftMargin = 18;
      const rightMargin = 192;
      const contentWidth = rightMargin - leftMargin; // 174 mm
      const centerX = leftMargin + contentWidth / 2; // 105 mm
      let currentY = 16;

      // 1. KOP SURAT (Header with Logo & School Identity)
      if (logoData) {
        try {
          pdf.addImage(logoData, 'PNG', leftMargin, currentY, 21, 21);
        } catch {
          // ignore
        }
      }

      // KPU OSIS Header text
      pdf.setFont('helvetica', 'bold');
      pdf.setFontSize(9.5);
      pdf.setTextColor(30, 41, 59); // slate-800
      pdf.text('KOMISI PEMILIHAN OSIS (KPU OSIS)', centerX + 4, currentY + 3.5, { align: 'center' });

      pdf.setFontSize(14.5);
      pdf.setTextColor(15, 23, 42); // slate-950
      pdf.text(settings.schoolName.toUpperCase(), centerX + 4, currentY + 10, { align: 'center' });

      pdf.setFont('helvetica', 'normal');
      pdf.setFontSize(8.5);
      pdf.setTextColor(71, 85, 105); // slate-600
      pdf.text(
        settings.schoolAddress || 'Jl. Mayor Zen Lr. Iwari No. 50 RT. 34',
        centerX + 4,
        currentY + 15.5,
        { align: 'center' }
      );

      currentY += 23;

      // Double Line Separator
      pdf.setDrawColor(15, 23, 42);
      pdf.setLineWidth(0.75);
      pdf.line(leftMargin, currentY, rightMargin, currentY);
      pdf.setLineWidth(0.25);
      pdf.line(leftMargin, currentY + 1, rightMargin, currentY + 1);

      currentY += 7.5;

      // 2. DOCUMENT TITLE & BLANK NOMOR
      pdf.setFont('helvetica', 'bold');
      pdf.setFontSize(11);
      pdf.setTextColor(15, 23, 42);
      pdf.text('BERITA ACARA PEMUNGUTAN & PENGHITUNGAN SUARA', centerX, currentY, { align: 'center' });
      pdf.setLineWidth(0.35);
      const titleWidth = pdf.getTextWidth('BERITA ACARA PEMUNGUTAN & PENGHITUNGAN SUARA');
      pdf.line(centerX - titleWidth / 2, currentY + 1, centerX + titleWidth / 2, currentY + 1);

      currentY += 5.5;
      pdf.setFont('helvetica', 'normal');
      pdf.setFontSize(8.5);
      pdf.setTextColor(71, 85, 105);
      pdf.text('Nomor : ....................................................', centerX, currentY, {
        align: 'center',
      });

      currentY += 6.5;

      // 3. OPENING STATEMENT
      const openingText = `Pada hari ini, ${fullDayFormatted}, bertempat di bilik suara digital ${settings.schoolName}, telah dilaksanakan pemungutan dan penghitungan suara secara langsung, umum, bebas, rahasia, jujur, dan adil dalam rangka Pemilihan Ketua dan Wakil Ketua OSIS ${settings.electionPeriod}.`;
      pdf.setFont('helvetica', 'normal');
      pdf.setFontSize(8);
      pdf.setTextColor(30, 41, 59);
      const splitOpening = pdf.splitTextToSize(openingText, contentWidth);
      pdf.text(splitOpening, leftMargin, currentY);

      currentY += splitOpening.length * 3.8 + 4;

      // 4. SECTION A: REKAPITULASI PEMILIH DAN PENGGUNAAN HAK SUARA
      pdf.setFont('helvetica', 'bold');
      pdf.setFontSize(8.5);
      pdf.setTextColor(15, 23, 42);
      pdf.text('A. REKAPITULASI PEMILIH DAN PENGGUNAAN HAK SUARA', leftMargin, currentY);
      currentY += 3.5;

      // Table A Column Widths: No (14mm), Uraian (120mm), Jumlah (40mm) = 174mm
      const colA1 = 14;
      const colA2 = 120;
      const colA3 = 40;
      const xA1 = leftMargin;
      const xA2 = xA1 + colA1;
      const xA3 = xA2 + colA2;

      // Header Row A
      const headerHeightA = 6.5;
      pdf.setFillColor(241, 245, 249); // slate-100
      pdf.setDrawColor(203, 213, 225); // slate-300
      pdf.setLineWidth(0.25);

      pdf.rect(xA1, currentY, colA1, headerHeightA, 'FD');
      pdf.rect(xA2, currentY, colA2, headerHeightA, 'FD');
      pdf.rect(xA3, currentY, colA3, headerHeightA, 'FD');

      pdf.setFont('helvetica', 'bold');
      pdf.setFontSize(8);
      pdf.setTextColor(51, 65, 85);
      pdf.text('No', xA1 + colA1 / 2, currentY + 4.3, { align: 'center' });
      pdf.text('Uraian Data Pemilihan', xA2 + 3, currentY + 4.3);
      pdf.text('Jumlah', xA3 + colA3 - 3, currentY + 4.3, { align: 'right' });
      currentY += headerHeightA;

      // Data Rows A
      const rowsA = [
        { no: '1', label: 'Jumlah Pemilih Terdaftar dalam DPT', value: `${stats.totalDpt} Siswa`, color: [15, 23, 42], isBold: true },
        { no: '2', label: 'Jumlah Siswa Menggunakan Hak Suara (Suara Sah)', value: `${stats.totalVoted} Suara`, color: [4, 120, 87], isBold: true },
        { no: '3', label: 'Jumlah Siswa Belum / Tidak Menggunakan Hak Suara', value: `${stats.totalPending} Siswa`, color: [71, 85, 105], isBold: true },
        { no: '4', label: 'Tingkat Partisipasi Pemilih Siswa', value: `${stats.participationPercentage}%`, color: [67, 56, 202], isBold: true, isSummary: true },
      ];

      const rowHeightA = 6;
      rowsA.forEach((r) => {
        if (r.isSummary) {
          pdf.setFillColor(248, 250, 252);
          pdf.rect(xA1, currentY, colA1, rowHeightA, 'FD');
          pdf.rect(xA2, currentY, colA2, rowHeightA, 'FD');
          pdf.rect(xA3, currentY, colA3, rowHeightA, 'FD');
        } else {
          pdf.setFillColor(255, 255, 255);
          pdf.rect(xA1, currentY, colA1, rowHeightA, 'FD');
          pdf.rect(xA2, currentY, colA2, rowHeightA, 'FD');
          pdf.rect(xA3, currentY, colA3, rowHeightA, 'FD');
        }

        pdf.setFont('helvetica', r.isSummary ? 'bold' : 'normal');
        pdf.setFontSize(8);
        pdf.setTextColor(30, 41, 59);
        pdf.text(r.no, xA1 + colA1 / 2, currentY + 4.1, { align: 'center' });
        pdf.text(r.label, xA2 + 3, currentY + 4.1);

        pdf.setFont('helvetica', 'bold');
        pdf.setTextColor(r.color[0], r.color[1], r.color[2]);
        pdf.text(r.value, xA3 + colA3 - 3, currentY + 4.1, { align: 'right' });

        currentY += rowHeightA;
      });

      currentY += 5;

      // 5. SECTION B: HASIL PEROLEHAN SUARA PASANGAN CALON
      pdf.setFont('helvetica', 'bold');
      pdf.setFontSize(8.5);
      pdf.setTextColor(15, 23, 42);
      pdf.text('B. HASIL PEROLEHAN SUARA PASANGAN CALON', leftMargin, currentY);
      currentY += 3.5;

      // Table B Columns: Nomor (16mm), Nama & Paslon (102mm), Suara (32mm), Persentase (24mm) = 174mm
      const colB1 = 16;
      const colB2 = 102;
      const colB3 = 32;
      const colB4 = 24;
      const xB1 = leftMargin;
      const xB2 = xB1 + colB1;
      const xB3 = xB2 + colB2;
      const xB4 = xB3 + colB3;

      // Header Row B
      const headerHeightB = 6.5;
      pdf.setFillColor(241, 245, 249);
      pdf.setDrawColor(203, 213, 225);
      pdf.setLineWidth(0.25);

      pdf.rect(xB1, currentY, colB1, headerHeightB, 'FD');
      pdf.rect(xB2, currentY, colB2, headerHeightB, 'FD');
      pdf.rect(xB3, currentY, colB3, headerHeightB, 'FD');
      pdf.rect(xB4, currentY, colB4, headerHeightB, 'FD');

      pdf.setFont('helvetica', 'bold');
      pdf.setFontSize(8);
      pdf.setTextColor(51, 65, 85);
      pdf.text('Nomor', xB1 + colB1 / 2, currentY + 4.3, { align: 'center' });
      pdf.text('Nama Paslon & Kandidat', xB2 + 3, currentY + 4.3);
      pdf.text('Perolehan Suara', xB3 + colB3 - 3, currentY + 4.3, { align: 'right' });
      pdf.text('Persentase', xB4 + colB4 - 3, currentY + 4.3, { align: 'right' });
      currentY += headerHeightB;

      // Candidate Rows B
      const rowHeightB = 10.5;
      candidates.forEach((c) => {
        const count = stats.candidateCounts[c.number] || 0;
        const percent = getPercent(count);
        const isWinner = winner && winner.id === c.id;

        if (isWinner) {
          pdf.setFillColor(254, 243, 199); // amber-100 highlight matching preview!
        } else {
          pdf.setFillColor(255, 255, 255);
        }

        // Draw crisp cell borders for every column
        pdf.rect(xB1, currentY, colB1, rowHeightB, 'FD');
        pdf.rect(xB2, currentY, colB2, rowHeightB, 'FD');
        pdf.rect(xB3, currentY, colB3, rowHeightB, 'FD');
        pdf.rect(xB4, currentY, colB4, rowHeightB, 'FD');

        // Column 1: Candidate Number (Centered & Bold)
        pdf.setFont('helvetica', 'bold');
        pdf.setFontSize(11);
        pdf.setTextColor(15, 23, 42);
        pdf.text(c.number, xB1 + colB1 / 2, currentY + 6.8, { align: 'center' });

        // Column 2: Candidate Title & Leader/Co-leader Subtitle
        pdf.setFont('helvetica', 'bold');
        pdf.setFontSize(8.5);
        pdf.setTextColor(15, 23, 42);
        pdf.text(c.title, xB2 + 3, currentY + 4.5);

        pdf.setFont('helvetica', 'normal');
        pdf.setFontSize(7.2);
        pdf.setTextColor(71, 85, 105);
        pdf.text(
          `Ketua: ${c.leaderName}  •  Wakil: ${c.coLeaderName}`,
          xB2 + 3,
          currentY + 8.4
        );

        // Column 3: Suara
        pdf.setFont('helvetica', 'bold');
        pdf.setFontSize(8.5);
        pdf.setTextColor(15, 23, 42);
        pdf.text(`${count} Suara`, xB3 + colB3 - 3, currentY + 6.5, { align: 'right' });

        // Column 4: Persentase (Indigo)
        pdf.setFont('helvetica', 'bold');
        pdf.setFontSize(9);
        pdf.setTextColor(67, 56, 202);
        pdf.text(`${percent}%`, xB4 + colB4 - 3, currentY + 6.5, { align: 'right' });

        currentY += rowHeightB;
      });

      currentY += 4.5;

      // 6. SECTION C: PENETAPAN PEMENANG (Matching Box Preview)
      const boxHeightC = 14;
      pdf.setFillColor(248, 250, 252); // slate-50
      pdf.setDrawColor(203, 213, 225); // slate-300
      pdf.setLineWidth(0.25);
      pdf.roundedRect(leftMargin, currentY, contentWidth, boxHeightC, 2, 2, 'FD');

      pdf.setFont('helvetica', 'bold');
      pdf.setFontSize(8);
      pdf.setTextColor(15, 23, 42);
      pdf.text('C. PENETAPAN KANDIDAT TERPILIH', leftMargin + 3.5, currentY + 4);

      pdf.setFont('helvetica', 'normal');
      pdf.setFontSize(7.5);
      pdf.setTextColor(30, 41, 59);
      const winnerText = `Berdasarkan hasil perolehan suara sah terbanyak, ditetapkan bahwa Pasangan Calon Nomor Urut ${
        winner?.number || '01'
      } (${winner?.title || 'Kandidat Terpilih'}) dengan Ketua ${
        winner?.leaderName
      } dan Wakil Ketua ${
        winner?.coLeaderName
      } sebagai KETUA DAN WAKIL KETUA OSIS TERPILIH ${settings.schoolName} ${
        settings.electionPeriod
      }.`;
      const splitWinner = pdf.splitTextToSize(winnerText, contentWidth - 7);
      pdf.text(splitWinner, leftMargin + 3.5, currentY + 8);

      currentY += boxHeightC + 8;

      // 7. SIGNATURES: PEMBINA OSIS (LEFT) & KEPALA SEKOLAH (RIGHT)
      // Exactly 2 equal columns: Left Center = 61.5 mm, Right Center = 148.5 mm
      const colLeftCenter = leftMargin + (contentWidth / 4); // 18 + 43.5 = 61.5 mm
      const colRightCenter = rightMargin - (contentWidth / 4); // 192 - 43.5 = 148.5 mm

      // Title line
      pdf.setFont('helvetica', 'bold');
      pdf.setFontSize(8.5);
      pdf.setTextColor(30, 41, 59);
      pdf.text('Pembina OSIS,', colLeftCenter, currentY, { align: 'center' });
      pdf.text('Mengetahui, Kepala Sekolah', colRightCenter, currentY, { align: 'center' });

      // Clean signature gap (20 mm)
      const lineY = currentY + 20;
      const signatureLineWidth = 52; // 52 mm formal line width

      // Solid Signature Lines (Border-T style matching preview)
      pdf.setDrawColor(15, 23, 42);
      pdf.setLineWidth(0.35);
      pdf.line(
        colLeftCenter - signatureLineWidth / 2,
        lineY,
        colLeftCenter + signatureLineWidth / 2,
        lineY
      );
      pdf.line(
        colRightCenter - signatureLineWidth / 2,
        lineY,
        colRightCenter + signatureLineWidth / 2,
        lineY
      );

      // Printed Names Under Line (Bold & Centered)
      const nameY = lineY + 4.5;
      pdf.setFont('helvetica', 'bold');
      pdf.setFontSize(9.5);
      pdf.setTextColor(15, 23, 42);
      pdf.text(pembinaName, colLeftCenter, nameY, { align: 'center' });
      pdf.text(principalName, colRightCenter, nameY, { align: 'center' });

      // Save PDF Directly
      pdf.save(filename);

      notificationService.notify(
        'Berita Acara Berhasil Diunduh (PDF)',
        `Dokumen PDF resmi telah berhasil diunduh dengan tata letak rapi dan persis seperti preview.`,
        'success'
      );
    } catch (err) {
      console.error('PDF Generation Error:', err);
      notificationService.notify(
        'Gagal Mengunduh Dokumen',
        'Terjadi kendala saat memproses dokumen PDF.',
        'warning'
      );
    } finally {
      setIsGeneratingPdf(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85 backdrop-blur-sm overflow-y-auto">
      <div className="relative w-full max-w-4xl bg-white text-slate-900 rounded-3xl shadow-2xl border border-slate-200 overflow-hidden my-6 max-h-[94vh] flex flex-col">
        {/* Top Control Bar: Only PDF Download & Close */}
        <div className="p-4 bg-slate-900 text-white flex flex-wrap items-center justify-between gap-3 border-b border-slate-800 shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-1.5 rounded-lg bg-amber-400 text-slate-950">
              <FileText className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-sm font-black text-white">
                Berita Acara Resmi Hasil Pemilihan OSIS
              </h3>
              <p className="text-xs text-slate-400">
                Dokumen yuridis sah penghitungan suara
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleDownloadPdf}
              disabled={isGeneratingPdf}
              className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold text-xs flex items-center gap-2 transition-all cursor-pointer shadow-md hover:scale-[1.02] active:scale-[0.98]"
            >
              <Download className="w-4 h-4" />
              <span>{isGeneratingPdf ? 'Membuat PDF...' : 'Unduh Berita Acara (PDF)'}</span>
            </button>

            <button
              onClick={onClose}
              className="p-1.5 rounded-full hover:bg-slate-800 text-slate-400 hover:text-white transition-colors cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Scrollable Printable Document Area */}
        <div className="p-4 sm:p-8 overflow-y-auto overflow-x-auto bg-slate-200/70 flex justify-center items-start">
          <div className="shadow-2xl rounded-sm border border-slate-300 bg-white my-2">
            <div
              id="berita-acara-doc"
              className="w-[780px] min-w-[780px] bg-white p-10 sm:p-12 text-slate-900 font-sans leading-relaxed space-y-5"
              style={{ boxSizing: 'border-box' }}
            >
              {/* Kop Surat:
                  - Alamat: Jl. Mayor Zen Lr. Iwari No. 50 RT. 34
                  - Hapus: email, akreditasi, laman e-voting, segel KPU
              */}
              <div className="flex items-center justify-center border-b-4 border-double border-slate-900 pb-3 text-center relative">
                <img
                  src={OSIS_LOGO}
                  alt="Logo OSIS"
                  crossOrigin="anonymous"
                  className="w-20 h-20 object-contain absolute left-0 top-0 shrink-0"
                />
                <div className="px-16 space-y-1">
                  <h4 className="text-xs font-bold tracking-widest uppercase text-slate-800">
                    KOMISI PEMILIHAN OSIS (KPU OSIS)
                  </h4>
                  <h2 className="text-xl sm:text-2xl font-black uppercase tracking-tight text-slate-950">
                    {settings.schoolName}
                  </h2>
                  <p className="text-xs text-slate-700 font-medium">
                    {settings.schoolAddress || 'Jl. Mayor Zen Lr. Iwari No. 50 RT. 34'}
                  </p>
                </div>
              </div>

              {/* Document Title & Blank Number */}
              <div className="text-center pt-1 space-y-1">
                <h3 className="text-base sm:text-lg font-black uppercase tracking-wide underline underline-offset-4 text-slate-950">
                  BERITA ACARA PEMUNGUTAN &amp; PENGHITUNGAN SUARA
                </h3>
                <p className="text-xs font-medium text-slate-700">
                  Nomor : ....................................................
                </p>
              </div>

              {/* Opening Statement */}
              <p className="text-xs text-justify indent-8 text-slate-800 leading-relaxed">
                Pada hari ini, <strong className="text-slate-950">{fullDayFormatted}</strong>, bertempat di bilik suara digital <strong>{settings.schoolName}</strong>, telah dilaksanakan pemungutan dan penghitungan suara secara langsung, umum, bebas, rahasia, jujur, dan adil dalam rangka <strong>Pemilihan Ketua dan Wakil Ketua OSIS {settings.electionPeriod}</strong>.
              </p>

              {/* Section A: Voter Statistics Table */}
              <div className="space-y-1.5">
                <h4 className="text-xs font-black uppercase tracking-wider text-slate-900">
                  A. REKAPITULASI PEMILIH DAN PENGGUNAAN HAK SUARA
                </h4>
                <table className="w-full text-xs border border-slate-300 divide-y divide-slate-300 text-left">
                  <thead className="bg-slate-100 font-bold text-slate-700">
                    <tr>
                      <th className="p-2 border-r border-slate-300 w-12 text-center">No</th>
                      <th className="p-2 border-r border-slate-300">Uraian Data Pemilihan</th>
                      <th className="p-2 text-right">Jumlah</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    <tr>
                      <td className="p-2 border-r border-slate-300 text-center font-mono">1</td>
                      <td className="p-2 border-r border-slate-300">Jumlah Pemilih Terdaftar dalam DPT</td>
                      <td className="p-2 text-right font-bold font-mono">{stats.totalDpt} Siswa</td>
                    </tr>
                    <tr>
                      <td className="p-2 border-r border-slate-300 text-center font-mono">2</td>
                      <td className="p-2 border-r border-slate-300">Jumlah Siswa Menggunakan Hak Suara (Suara Sah)</td>
                      <td className="p-2 text-right font-bold font-mono text-emerald-700">{stats.totalVoted} Suara</td>
                    </tr>
                    <tr>
                      <td className="p-2 border-r border-slate-300 text-center font-mono">3</td>
                      <td className="p-2 border-r border-slate-300">Jumlah Siswa Belum / Tidak Menggunakan Hak Suara</td>
                      <td className="p-2 text-right font-bold font-mono text-slate-600">{stats.totalPending} Siswa</td>
                    </tr>
                    <tr className="bg-slate-50 font-bold">
                      <td className="p-2 border-r border-slate-300 text-center font-mono">4</td>
                      <td className="p-2 border-r border-slate-300">Tingkat Partisipasi Pemilih Siswa</td>
                      <td className="p-2 text-right font-black font-mono text-indigo-700">{stats.participationPercentage}%</td>
                    </tr>
                  </tbody>
                </table>
              </div>

              {/* Section B: Results Table */}
              <div className="space-y-1.5">
                <h4 className="text-xs font-black uppercase tracking-wider text-slate-900">
                  B. HASIL PEROLEHAN SUARA PASANGAN CALON
                </h4>
                <table className="w-full text-xs border border-slate-300 divide-y divide-slate-300 text-left">
                  <thead className="bg-slate-100 font-bold text-slate-700">
                    <tr>
                      <th className="p-2 border-r border-slate-300 w-16 text-center">Nomor</th>
                      <th className="p-2 border-r border-slate-300">Nama Paslon &amp; Kandidat</th>
                      <th className="p-2 border-r border-slate-300 text-right w-28">Perolehan Suara</th>
                      <th className="p-2 text-right w-24">Persentase</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-200">
                    {candidates.map((c) => {
                      const count = stats.candidateCounts[c.number] || 0;
                      const percent = getPercent(count);
                      const isTop = winner && winner.id === c.id;

                      return (
                        <tr key={c.id} className={isTop ? 'bg-amber-100/60 font-semibold' : ''}>
                          <td className="p-2 border-r border-slate-300 text-center font-mono font-bold text-sm">
                            {c.number}
                          </td>
                          <td className="p-2 border-r border-slate-300">
                            <div className="font-bold text-slate-900">{c.title}</div>
                            <div className="text-[11px] text-slate-600">
                              Ketua: <strong>{c.leaderName}</strong> &bull; Wakil: <strong>{c.coLeaderName}</strong>
                            </div>
                          </td>
                          <td className="p-2 border-r border-slate-300 text-right font-mono font-bold">
                            {count} Suara
                          </td>
                          <td className="p-2 text-right font-mono font-bold text-indigo-700">
                            {percent}%
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Section C: Determination of Winner */}
              <div className="p-3.5 bg-slate-50 border border-slate-300 rounded-lg space-y-1 text-xs">
                <h4 className="font-black text-slate-950 uppercase">
                  C. PENETAPAN KANDIDAT TERPILIH
                </h4>
                <p className="text-slate-800 leading-relaxed">
                  Berdasarkan hasil perolehan suara sah terbanyak, ditetapkan bahwa Pasangan Calon Nomor Urut <strong>{winner?.number || '01'} ({winner?.title || 'Kandidat Terpilih'})</strong> dengan Ketua <strong>{winner?.leaderName}</strong> dan Wakil Ketua <strong>{winner?.coLeaderName}</strong> sebagai <strong>KETUA DAN WAKIL KETUA OSIS TERPILIH {settings.schoolName} {settings.electionPeriod}</strong>.
                </p>
              </div>

              {/* Signatures: ONLY Pembina OSIS and Kepala Sekolah.
                  NIP, "tanda tangan" text, and date line REMOVED as requested.
              */}
              <div className="pt-4 text-xs space-y-4">
                <div className="grid grid-cols-2 gap-12 text-center pt-2">
                  {/* Pembina OSIS */}
                  <div className="flex flex-col items-center">
                    <p className="text-xs text-slate-800 font-bold">Pembina OSIS,</p>
                    <div className="h-16" />
                    <div className="w-52 border-t-2 border-slate-900 pt-1.5">
                      <p className="font-bold text-slate-950 text-sm">
                        {pembinaName}
                      </p>
                    </div>
                  </div>

                  {/* Mengetahui, Kepala Sekolah */}
                  <div className="flex flex-col items-center">
                    <p className="text-xs text-slate-800 font-bold">Mengetahui, Kepala Sekolah</p>
                    <div className="h-16" />
                    <div className="w-52 border-t-2 border-slate-900 pt-1.5">
                      <p className="font-bold text-slate-950 text-sm">
                        {principalName}
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

import React from 'react';
import { Candidate } from '../types/election';
import { X, CheckCircle2, Award, BookOpen, Quote, Sparkles } from 'lucide-react';

interface CandidateModalProps {
  candidate: Candidate | null;
  isOpen: boolean;
  onClose: () => void;
  onSelectCandidate?: (candidate: Candidate) => void;
}

export const CandidateModal: React.FC<CandidateModalProps> = ({
  candidate,
  isOpen,
  onClose,
  onSelectCandidate,
}) => {
  if (!isOpen || !candidate) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-fade-in overflow-y-auto">
      <div
        className="relative w-full max-w-2xl bg-white dark:bg-slate-900 rounded-2xl shadow-2xl border border-slate-200 dark:border-slate-800 overflow-hidden my-8 max-h-[90vh] flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header Banner */}
        <div className="relative bg-gradient-to-r from-slate-900 via-indigo-950 to-slate-900 p-6 text-white shrink-0">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
            aria-label="Tutup modal"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-amber-400 text-slate-950 font-black text-3xl flex items-center justify-center shadow-lg border-2 border-white/20 shrink-0">
              {candidate.number}
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-white/20 text-white">
                  Kandidat Paslon {candidate.number}
                </span>
                <span className="text-xs text-amber-300 font-semibold flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5" /> SMA DHARMA BHAKTI PALEMBANG
                </span>
              </div>
              <h2 className="text-2xl font-extrabold tracking-tight mt-1 text-white">
                {candidate.title}
              </h2>
              <p className="text-slate-300 text-sm">
                Ketua: <strong className="text-white">{candidate.leaderName}</strong> &bull; Wakil: <strong className="text-white">{candidate.coLeaderName}</strong>
              </p>
            </div>
          </div>
        </div>

        {/* Scrollable Content */}
        <div className="p-6 overflow-y-auto space-y-6 text-slate-700 dark:text-slate-200">
          {/* Top section: Photo + Tagline */}
          <div className="grid grid-cols-1 md:grid-cols-12 gap-5 items-center bg-slate-50 dark:bg-slate-800/50 p-4 rounded-xl border border-slate-100 dark:border-slate-800">
            <div className="md:col-span-4 flex justify-center">
              <div className="relative w-40 h-52 rounded-xl overflow-hidden shadow-md border-2 border-slate-200 dark:border-slate-700">
                <img
                  src={candidate.photoUrl}
                  alt={candidate.title}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-2 left-2 px-2 py-0.5 rounded bg-black/60 text-white text-[11px] font-bold backdrop-blur-xs">
                  Paslon {candidate.number}
                </div>
              </div>
            </div>
            <div className="md:col-span-8 space-y-3">
              <div className="flex items-start gap-2 bg-amber-50 dark:bg-amber-950/30 p-3 rounded-lg border border-amber-200/60 dark:border-amber-800/50">
                <Quote className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                <p className="text-sm font-medium text-amber-900 dark:text-amber-200 italic">
                  "{candidate.tagline}"
                </p>
              </div>

              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1.5">
                  Slogan & Jargon Perjuangan:
                </h4>
                <div className="space-y-1">
                  {candidate.slogans.map((slogan, idx) => (
                    <div key={idx} className="flex items-center gap-2 text-xs font-medium text-slate-600 dark:text-slate-300">
                      <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 shrink-0" />
                      <span>{slogan}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* VISI */}
          <div>
            <div className="flex items-center gap-2 text-indigo-600 dark:text-indigo-400 font-bold text-base mb-2">
              <Award className="w-5 h-5" />
              <h3>VISI UTAMA</h3>
            </div>
            <div className="p-4 rounded-xl bg-indigo-50/60 dark:bg-indigo-950/20 border border-indigo-100 dark:border-indigo-900/40 text-slate-800 dark:text-slate-200 text-sm leading-relaxed font-medium">
              {candidate.vision}
            </div>
          </div>

          {/* MISI */}
          <div>
            <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400 font-bold text-base mb-2">
              <CheckCircle2 className="w-5 h-5" />
              <h3>MISI KANDIDAT</h3>
            </div>
            <div className="space-y-2">
              {candidate.mission.map((item, index) => (
                <div
                  key={index}
                  className="flex items-start gap-3 p-3 rounded-xl bg-slate-50 dark:bg-slate-800/40 border border-slate-100 dark:border-slate-800 text-sm leading-relaxed"
                >
                  <span className="w-6 h-6 rounded-full bg-emerald-100 text-emerald-700 dark:bg-emerald-900/50 dark:text-emerald-300 font-bold text-xs flex items-center justify-center shrink-0 mt-0.5">
                    {index + 1}
                  </span>
                  <p className="text-slate-700 dark:text-slate-300">{item}</p>
                </div>
              ))}
            </div>
          </div>

          {/* PROGRAM KERJA UNGGULAN */}
          <div>
            <div className="flex items-center gap-2 text-amber-600 dark:text-amber-400 font-bold text-base mb-2">
              <BookOpen className="w-5 h-5" />
              <h3>PROGRAM KERJA UNGGULAN</h3>
            </div>
            <div className="grid grid-cols-1 gap-3">
              {candidate.programs.map((prog, index) => (
                <div
                  key={index}
                  className="p-4 rounded-xl bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 shadow-xs"
                >
                  <h4 className="font-bold text-sm text-slate-900 dark:text-white flex items-center gap-2">
                    <span className="w-2 h-2 rounded-full bg-amber-500" />
                    {prog.title}
                  </h4>
                  <p className="text-xs text-slate-600 dark:text-slate-300 mt-1.5 leading-relaxed">
                    {prog.description}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-4 bg-slate-50 dark:bg-slate-850 border-t border-slate-200 dark:border-slate-800 flex items-center justify-between gap-3 shrink-0">
          <button
            onClick={onClose}
            className="px-4 py-2.5 rounded-xl border border-slate-300 dark:border-slate-700 text-slate-700 dark:text-slate-300 font-semibold text-sm hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            Tutup
          </button>

          {onSelectCandidate && (
            <button
              onClick={() => {
                onClose();
                onSelectCandidate(candidate);
              }}
              className="px-6 py-2.5 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm shadow-md hover:shadow-indigo-500/25 transition-all flex items-center gap-2"
            >
              <span>Pilih Paslon {candidate.number}</span>
              <span className="text-xs bg-white/20 px-2 py-0.5 rounded-full">Coblos</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
};

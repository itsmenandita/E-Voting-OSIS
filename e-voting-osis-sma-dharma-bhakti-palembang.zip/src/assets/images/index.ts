import paslon1Photo from './paslon_satu_photo_1793509701605.jpg';
import paslon2Photo from './paslon_dua_photo_1793509701318.jpg';
import paslon3Photo from './paslon_tiga_photo_1793509700634.jpg';

export { paslon1Photo, paslon2Photo, paslon3Photo };

/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Candidate, VoterToken } from './types/election';
import { storageService } from './services/storage';
import { TokenScreen } from './components/TokenScreen';
import { VotingBooth } from './components/VotingBooth';
import { SuccessReceipt } from './components/SuccessReceipt';
import { QuickCountDashboard } from './components/QuickCountDashboard';
import { ProjectorView } from './components/ProjectorView';
import { AdminPanel } from './components/AdminPanel';
import { soundService } from './services/sound';
import { NotificationToastContainer } from './components/NotificationToast';
import { notificationService } from './services/notification';

type ViewMode = 'token' | 'booth' | 'success' | 'quick_count' | 'projector' | 'admin';

export default function App() {
  const [viewMode, setViewMode] = useState<ViewMode>('token');
  const [activeVoter, setActiveVoter] = useState<VoterToken | null>(null);
  const [latestReceipt, setLatestReceipt] = useState<{
    voter: VoterToken;
    receiptCode: string;
  } | null>(null);
  const [candidates, setCandidates] = useState<Candidate[]>(storageService.getCandidates());

  // Reload candidates on change
  const reloadCandidates = () => {
    setCandidates(storageService.getCandidates());
  };

  useEffect(() => {
    const unsub = storageService.subscribe(reloadCandidates);
    return () => unsub();
  }, []);

  // Voter enters valid token
  const handleTokenVerified = (voter: VoterToken) => {
    setActiveVoter(voter);
    setViewMode('booth');
  };

  // Student casts vote in booth
  const handleVoteCast = (candidateNumber: string) => {
    if (!activeVoter) return;

    const res = storageService.castVote(activeVoter.token, candidateNumber);
    if (res.success) {
      soundService.playVoteSuccess();
      notificationService.notify(
        'Suara Berhasil Dicatat',
        `Hak pilih atas nama ${res.voter.studentName} (${res.voter.gradeClass}) telah berhasil tersimpan secara rahasia.`,
        'success'
      );
      setLatestReceipt({
        voter: res.voter,
        receiptCode: res.receiptCode,
      });
      setViewMode('success');
    } else {
      alert(res.error || 'Terjadi kesalahan saat memproses suara.');
      setViewMode('token');
      setActiveVoter(null);
    }
  };

  // After vote, redirect back to token screen for next student
  const handleFinishRedirect = () => {
    setActiveVoter(null);
    setLatestReceipt(null);
    setViewMode('token');
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans selection:bg-amber-400 selection:text-slate-950">
      <NotificationToastContainer />
      {viewMode === 'token' && (
        <TokenScreen
          onTokenVerified={handleTokenVerified}
          onOpenQuickCount={() => setViewMode('quick_count')}
          onOpenAdmin={() => setViewMode('admin')}
        />
      )}

      {viewMode === 'booth' && activeVoter && (
        <VotingBooth
          voter={activeVoter}
          candidates={candidates}
          onVoteCast={handleVoteCast}
          onCancelVote={() => {
            setActiveVoter(null);
            setViewMode('token');
          }}
        />
      )}

      {viewMode === 'success' && latestReceipt && (
        <SuccessReceipt
          voter={latestReceipt.voter}
          receiptCode={latestReceipt.receiptCode}
          onFinishRedirect={handleFinishRedirect}
          autoRedirectSeconds={storageService.getSettings().autoRedirectSeconds || 5}
        />
      )}

      {viewMode === 'quick_count' && (
        <QuickCountDashboard
          candidates={candidates}
          onBackToBooth={() => setViewMode('token')}
          onOpenProjector={() => setViewMode('projector')}
        />
      )}

      {viewMode === 'projector' && (
        <ProjectorView
          candidates={candidates}
          onClose={() => setViewMode('quick_count')}
        />
      )}

      {viewMode === 'admin' && (
        <AdminPanel
          candidates={candidates}
          onBackToBooth={() => setViewMode('token')}
          onCandidatesUpdated={reloadCandidates}
        />
      )}
    </div>
  );
}

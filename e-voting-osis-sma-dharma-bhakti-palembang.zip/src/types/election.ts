export interface ProgramKerjaItem {
  title: string;
  description: string;
}


export interface Candidate {
  id: string;
  number: string;
  title: string;
  leaderName: string;
  coLeaderName: string;
  color: {
    primary: string;
    bgLight: string;
    badgeBg: string;
    border: string;
    accent: string;
  };
  photoUrl: string;
  vision: string;
  mission: string[];
  programs: ProgramKerjaItem[];
  slogans: string[];
  tagline: string;
}

export interface VoterToken {
  id: string;
  token: string;
  studentName: string;
  nisn: string;
  gradeClass: string;
  isUsed: boolean;
  usedAt?: string;
  votedCandidateId?: string;
  receiptId?: string;
}

export interface ElectionSettings {
  schoolName: string;
  schoolAddress: string;
  subTitle: string;
  electionPeriod: string;
  academicYear: string;
  status: 'active' | 'paused' | 'closed';
  autoRedirectSeconds: number;
  adminPin: string;
  principalName: string;
  principalNip: string;
  pembinaName: string;
  pembinaNip: string;
}

export interface VoteAuditLog {
  id: string;
  timestamp: string;
  gradeClass: string;
  candidateNumber: string;
  receiptCode: string;
}

export interface ElectionStats {
  totalDpt: number;
  totalVoted: number;
  totalPending: number;
  participationPercentage: number;
  candidateCounts: Record<string, number>;
}


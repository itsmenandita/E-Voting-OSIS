import { Candidate, ElectionSettings, VoterToken } from '../types/election';

export const OSIS_LOGO = '/assets/aistudio/logo_osis_sma_0abdbba0.png';

export const INITIAL_CANDIDATES: Candidate[] = [
  {
    id: '01',
    number: '01',
    title: 'PASLON 01 - ALDES ONE',
    leaderName: 'Muhammad Alfarizsy',
    coLeaderName: 'Deska Putri Auliyani',
    color: {
      primary: 'blue',
      bgLight: 'bg-blue-50/80 dark:bg-blue-950/20',
      badgeBg: 'bg-blue-600',
      border: 'border-blue-500',
      accent: '#2563eb',
    },
    photoUrl: '/assets/aistudio/Paslon_01_0f5b91a7.jpeg',
    tagline: 'Satukan mimpi dengan aspirasimu. Ready to serve and be the best!',
    vision:
      'Mewujudkan OSIS yang aktif, kreatif, terbuka, dan mampu menjadi wadah bagi siswa/i untuk mengembangkan potensi diri, prestasi, dan membangun karya guna menyampaikan aspirasi serta menciptakan lingkungan sekolah yang lebih kompak dan harmonis.',
    mission: [
      'Membangun hubungan harmonis secara komunikatif dan kolaboratif serta kegiatan yang meningkatkan kekompakan dan kebersamaan siswa.',
      'Menyediakan wadah aspirasi guna mengoptimalkan siswa/i untuk menyampaikan saran, ide maupun kritik secara kritis dan bermutu.',
      'Mendukung Siswa/i secara apresiatif dengan mampu mengembangkan potensi diri baik dalam bidang akademik maupun non-akademik secara inovatif.',
      'Mewujudkan sekolah yang bersih, nyaman, dan asri dengan meningkatkan kesadaran serta tanggung jawab Siswa/i akan kebersihan lingkungan sekolah.',
    ],
    programs: [
      {
        title: 'Kotak Aspirasi / Bullying',
        description:
          'Menjalankan program dengan mendengarkan aspirasi siswa/i seperti keluhan, keinginan, dan saran serta kritik dalam setiap kegiatan untuk menciptakan lingkungan sekolah yang aman dan suportif.',
      },
      {
        title: 'Creative Achievement Wall Magazine',
        description:
          'Program majalah dinding interaktif yang menggabungkan kreativitas seni siswa dan ruang apresiasi resmi bagi siswa/i yang berprestasi akademik maupun non-akademik.',
      },
      {
        title: 'Bakti Interaktif',
        description:
          'Program komunikasi dua arah yang menghubungkan interaksi dan penjelasan terbuka antara OSIS, siswa, dan sekolah yang disampaikan dengan tulus, santai, dan fleksibel.',
      },
      {
        title: 'Green School Movement',
        description:
          'Dijalankan setiap 1 bulan sekali dengan tujuan meningkatkan kesadaran siswa/i akan kebersihan lingkungan sekolah, merawat, melestarikan, dan membangun budaya disiplin serta tanggung jawab lingkungan.',
      },
    ],
    slogans: [
      'Satukan mimpi dengan aspirasimu',
      'Satu langkah kecil menjadi perubahan yang luar biasa',
      'Bersama ALDES ONE Ready to serve and be the best',
    ],
  },
  {
    id: '02',
    number: '02',
    title: 'PASLON 02 - BHAKTI GEMILANG',
    leaderName: 'Muhammad Doris',
    coLeaderName: 'Zahra Anugrah Syahputri',
    color: {
      primary: 'amber',
      bgLight: 'bg-amber-50/80 dark:bg-amber-950/20',
      badgeBg: 'bg-amber-500',
      border: 'border-amber-500',
      accent: '#f59e0b',
    },
    photoUrl: '/assets/aistudio/Paslon_02_23684eaf.jpeg',
    tagline: 'Mari Tentukan Pilihanmu, Ingati Nomornya, Coblos 02! Satukan Arah, Mengukir Sejarah.',
    vision:
      'Membangun siswa-siswi yang berintegritas, peduli, dan berani bergerak untuk mengabdi, berkarya, serta memberikan dampak yang positif bagi lingkungan sekolah.',
    mission: [
      'B — Bersama: Membangun kebersamaan dan kekeluargaan yang erat antar sesama warga sekolah.',
      'H — Harmonis: Menciptakan lingkungan sekolah yang nyaman, aman, toleran, dan senantiasa positif.',
      'A — Aktif: Mendorong dan memfasilitasi seluruh siswa agar aktif berorganisasi serta berkontribusi nyata.',
      'K — Kreatif: Mengadakan kegiatan-kegiatan OSIS yang segar, inovatif, dan memberikan manfaat jangka panjang.',
      'T — Tangguh: Membentuk mentalitas siswa yang berkarakter disiplin, pantang menyerah, dan bertanggung jawab.',
      'I — Inspiratif: Menjadi teladan penggerak perubahan positif dan pelopor kemajuan di sekolah.',
    ],
    programs: [
      {
        title: 'CAKRAWALA (Cakap, Kreatif, dan Berwawasan Luas)',
        description:
          'Program seminar edukatif dan pelatihan berkala tentang kepemimpinan (leadership), literasi digital terapan, serta kemampuan public speaking untuk seluruh siswa.',
      },
      {
        title: 'NUSANTARA (Nuansa Solidaritas dan Persatuan Antarsiswa)',
        description:
          'Kegiatan pemersatu untuk mempererat kebersamaan melalui acara antarkelas (class meeting tematik), interaksi harmonis siswa dan guru, serta kolaborasi persahabatan antar sekolah.',
      },
      {
        title: 'AKSARA (Aksi Kreatif Siswa Bersuara)',
        description:
          'Wadah apresiasi dan ekspresi bagi siswa untuk menampilkan suara dan bakat kalian melalui cara yang kreatif dan inovatif seperti fotografi, desain grafis, sastra tulisan, tari, musik, dan karya seni lainnya.',
      },
    ],
    slogans: [
      'Mari Tentukan Pilihanmu, ingati Nomornya, Coblos 02.',
      'Bersama Paslon 02 Kita Beraksi, Satukan Arah, Mengukir sejarah.',
    ],
  },
  {
    id: '03',
    number: '03',
    title: 'PASLON 03 - PIONIR BERKARYA',
    leaderName: 'M. Zakiyuddiin',
    coLeaderName: 'Zuhriyah Jumaika',
    color: {
      primary: 'emerald',
      bgLight: 'bg-emerald-50/80 dark:bg-emerald-950/20',
      badgeBg: 'bg-emerald-600',
      border: 'border-emerald-500',
      accent: '#10b981',
    },
    photoUrl: '/assets/aistudio/Paslon_03_7c2e2102.jpeg',
    tagline: 'Satu langkah, satu suara, satu tujuan. Jangan mau jadi yang ketiga, mending pilih 03!',
    vision:
      'Mewujudkan OSIS SMA Dharma Bhakti Palembang sebagai wadah bagi seluruh siswa/i untuk berkembang dan pionir yang kritis inovatif dan aspiratif serta menjadikan siswa/i SMA Dharma Bhakti Palembang menjadi siswa/i yang disiplin dan berakhlak mulia.',
    mission: [
      'Meningkatkan keimanan kedisiplinan dan tanggung jawab siswa melalui kegiatan keagamaan, penegakan tata tertib, dan pemeliharaan lingkungan sekolah.',
      'Menumbuhkan partisipasi aktif dan kekompakan siswa dalam setiap agenda serta kegiatan sekolah.',
      'Mengembangkan potensi bakat serta kreativitas siswa melalui perlombaan akademik dan non-akademik berjenjang.',
      'Mengembangkan rasa peduli lingkungan yang membentuk karakter warga sekolah yang cerdas, santun, dan solid.',
    ],
    programs: [
      {
        title: '1. Literasi Tanpa Boring',
        description:
          'Menghidupkan gairah membaca dan perpustakaan sekolah dengan membuat Mading kreatif tiga dimensi, book-talk santai, dan pojok baca instagrammable.',
      },
      {
        title: '2. Speak Up Bersama',
        description:
          'Menyampaikan ide, aspirasi, dan saran secara terbuka melalui kotak saran digital (Google Form terintegrasi) serta kotak fisik transparan di setiap lorong kelas.',
      },
      {
        title: '3. Jiwa Kebersamaan',
        description:
          'Tujuannya untuk mempererat kekompakan, solidaritas tanpa sekat kelas, dan kerja sama nyata antara siswa/i dengan pengurus OSIS.',
      },
      {
        title: '4. Bijak Bermedia',
        description:
          'Membangun dan mengajak siswa bijak dalam memanfaatkan teknologi informasi secara kreatif, inovatif, dan berdaya guna—bukan sekadar sarana hiburan pasif.',
      },
    ],
    slogans: [
      'JANGAN MAU JADI YANG KETIGA MENDING PILIH 03',
      'BERSAMA BERGERAK, BERSAMA BERKARYA',
      'Satu langkah, satu suara, satu tujuan 03 hadir membawah perubahan bersama bergerak, bersama berkarya',
    ],
  },
];

export const INITIAL_SETTINGS: ElectionSettings = {
  schoolName: 'SMA DHARMA BHAKTI PALEMBANG',
  schoolAddress: 'Jl. Mayor Zen Lr. Iwari No. 50 RT. 34',
  subTitle: 'Komisi Pemilihan OSIS (KPU OSIS)',
  electionPeriod: 'Periode 2026/2027',
  academicYear: '2026/2027',
  status: 'active',
  autoRedirectSeconds: 5,
  adminPin: 'adminosis',
  principalName: 'Dra. Hj. Nuraini, M.Pd.',
  principalNip: '19680315 199303 2 004',
  pembinaName: 'Ahmad Syukri, S.Pd.',
  pembinaNip: '19850422 200902 1 003',
};

export const INITIAL_TOKENS: VoterToken[] = [
  {
    id: 'tok-1',
    token: 'DBP-7821',
    studentName: 'Ahmad Fauzan',
    nisn: '0081293811',
    gradeClass: 'XII MIPA 1',
    isUsed: false,
  },
  {
    id: 'tok-2',
    token: 'DBP-3490',
    studentName: 'Nabila Putri Maharani',
    nisn: '0081293812',
    gradeClass: 'XII MIPA 2',
    isUsed: false,
  },
  {
    id: 'tok-3',
    token: 'DBP-5182',
    studentName: 'Rizky Pratama Wijaya',
    nisn: '0081293813',
    gradeClass: 'XII IPS 1',
    isUsed: false,
  },
  {
    id: 'tok-4',
    token: 'DBP-9023',
    studentName: 'Clarissa Amanda Safitri',
    nisn: '0081293814',
    gradeClass: 'XI MIPA 1',
    isUsed: false,
  },
  {
    id: 'tok-5',
    token: 'DBP-1144',
    studentName: 'Muhammad Daffa Rayhan',
    nisn: '0081293815',
    gradeClass: 'XI MIPA 2',
    isUsed: false,
  },
  {
    id: 'tok-6',
    token: 'DBP-6721',
    studentName: 'Zaskia Aurelia Ramadhani',
    nisn: '0081293816',
    gradeClass: 'XI IPS 1',
    isUsed: false,
  },
  {
    id: 'tok-7',
    token: 'DBP-8832',
    studentName: 'Fathan Al-Ghifari',
    nisn: '0081293817',
    gradeClass: 'X-1',
    isUsed: false,
  },
  {
    id: 'tok-8',
    token: 'DBP-4419',
    studentName: 'Siti Sarah Azzahra',
    nisn: '0081293818',
    gradeClass: 'X-2',
    isUsed: false,
  },
  {
    id: 'tok-9',
    token: 'DBP-2309',
    studentName: 'Bagus Setiawan',
    nisn: '0081293819',
    gradeClass: 'X-3',
    isUsed: false,
  },
  {
    id: 'tok-10',
    token: 'DBP-9951',
    studentName: 'Kezia Angeline',
    nisn: '0081293820',
    gradeClass: 'XII IPS 2',
    isUsed: false,
  },
];
